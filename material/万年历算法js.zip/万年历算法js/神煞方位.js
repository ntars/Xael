// 神煞方位（胎神/吉神/煞神）查询 —— 数据已内置于 黄历宜忌.js（共源，避免重复打包）
export { JIAZI, IDX, ADV } from './黄历宜忌.js';
export function getShenSha(date){ const rec=IDX[date]; if(!rec) return null; return ADV[JIAZI[rec[1]]] || null; }
