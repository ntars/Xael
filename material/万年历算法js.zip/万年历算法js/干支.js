// 干支（天干地支） —— 算法模块（自包含，不依赖任何外部库）
// 验证：日干支以万年历 APK saa.db IndexTable.gz 全量对拍 14610 天（2010–2049）100% 一致
// 原理（大白话）：干支是 60 一循环。先算「某公历日距纪元的总天数」，取模 60 即干支序号，
//       再锚定到 APK 实测的 2010-01-01=辛亥(序号47) 作基准，保证与 APP 完全同口径。

const GAN = '甲乙丙丁戊己庚辛壬癸'.split('');   // 10 天干
const ZHI = '子丑寅卯辰巳午未申酉戌亥'.split(''); // 12 地支

// 序号 → 干支名（0=甲子 … 59=癸亥）
export function jiazi(n) {
  n = ((n % 60) + 60) % 60;
  return GAN[n % 10] + ZHI[n % 12];
}

// 公历 (y,m,d) → 距 1970-01-01 的天数（Howard Hinnant 标准算法，全年正确含闰年）
export function daysFromCivil(y, m, d) {
  y -= m <= 2 ? 1 : 0;
  const era = (y >= 0 ? y : y - 399) / 400 | 0;
  const yoe = y - era * 400;
  const doy = Math.floor((153 * (m > 2 ? m - 3 : m + 9) + 2) / 5) + d - 1;
  const doe = yoe * 365 + Math.floor(yoe / 4) - Math.floor(yoe / 100) + doy;
  return era * 146097 + doe - 719468;
}

// 基准：APP 实测 2010-01-01 日干支 = 辛亥(47)
const K = ((47 - daysFromCivil(2010, 1, 1)) % 60 + 60) % 60;

// 日干支（最常用，已 100% 验证）
export function dayGanZhi(y, m, d) {
  return jiazi((daysFromCivil(y, m, d) + K) % 60);
}

// 年干支（春节后口径简化：取当年立春后年柱；精确立春切换略）
export function yearGanZhi(y) {
  return jiazi((y - 4) % 60);
}

// 月干支（寅月为岁首；月支固定，月干由年干推算）
export function monthGanZhi(y, m) {
  const yG = (y - 4) % 10;                 // 年天干序号
  const monthIndex = ((m + 9) % 12) - 1; // 寅(2月)=0 ... 子(12月/11月?)=... 简化
  const zhi = (1 + (m + 1) % 12) % 12;     // 月支：正月寅(2)…十二月丑(12)
  const gan = (yG * 2 + (zhi - 2) + 10) % 10;
  return GAN[gan] + ZHI[zhi];
}

// 时干支（时辰地支固定，时干由日干推算）
export function hourGanZhi(y, m, d, hour, minute = 0) {
  const dG = dayGanZhi(y, m, d);
  const dGan = GAN.indexOf(dG[0]);
  const zhi = (Math.floor((hour + 1) / 2) % 12 + 12) % 12; // 子时23-1, 丑1-3...
  const gan = ((dGan % 5) * 2 + Math.floor((hour + 1) / 2)) % 10;
  return GAN[gan] + ZHI[zhi];
}

export const GANZHI = { GAN, ZHI };
