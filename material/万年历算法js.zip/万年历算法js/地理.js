// 地理词库 —— 数据模块
// 来源：APK assets/databases/location.7z→location.db（3711 条）
// 字段：city 市/区名 | district 区县 | prov 省 | py 拼音
export const GEO = [
{
"city": "北京",
"district": "北京市",
"prov": "北京市",
"py": "beijing"
},
{
"city": "东城",
"district": "北京市",
"prov": "北京市",
"py": "dongcheng"
},
{
"city": "西城",
"district": "北京市",
"prov": "北京市",
"py": "xicheng"
},
{
"city": "朝阳",
"district": "北京市",
"prov": "北京市",
"py": "chaoyang"
},
{
"city": "丰台",
"district": "北京市",
"prov": "北京市",
"py": "fengtai"
},
{
"city": "石景山",
"district": "北京市",
"prov": "北京市",
"py": "shijingshan"
},
{
"city": "海淀",
"district": "北京市",
"prov": "北京市",
"py": "haidian"
},
{
"city": "门头沟",
"district": "北京市",
"prov": "北京市",
"py": "mentougou"
},
{
"city": "房山",
"district": "北京市",
"prov": "北京市",
"py": "fangshan"
},
{
"city": "通州",
"district": "北京市",
"prov": "北京市",
"py": "tongzhou"
},
{
"city": "顺义",
"district": "北京市",
"prov": "北京市",
"py": "shunyi"
},
{
"city": "昌平",
"district": "北京市",
"prov": "北京市",
"py": "changping"
},
{
"city": "大兴",
"district": "北京市",
"prov": "北京市",
"py": "daxing"
},
{
"city": "怀柔",
"district": "北京市",
"prov": "北京市",
"py": "huairou"
},
{
"city": "平谷",
"district": "北京市",
"prov": "北京市",
"py": "pinggu"
},
{
"city": "密云",
"district": "北京市",
"prov": "北京市",
"py": "miyun"
},
{
"city": "延庆",
"district": "北京市",
"prov": "北京市",
"py": "yanqing"
},
{
"city": "天津",
"district": "天津市",
"prov": "天津市",
"py": "tianjin"
},
{
"city": "和平区",
"district": "天津市",
"prov": "天津市",
"py": "hepingqu"
},
{
"city": "河东区",
"district": "天津市",
"prov": "天津市",
"py": "hedongqu"
},
{
"city": "河西区",
"district": "天津市",
"prov": "天津市",
"py": "hexiqu"
},
{
"city": "南开区",
"district": "天津市",
"prov": "天津市",
"py": "nankaiqu"
},
{
"city": "河北区",
"district": "天津市",
"prov": "天津市",
"py": "hebeiqu"
},
{
"city": "红桥区",
"district": "天津市",
"prov": "天津市",
"py": "hongqiaoqu"
},
{
"city": "东丽区",
"district": "天津市",
"prov": "天津市",
"py": "dongliqu"
},
{
"city": "西青区",
"district": "天津市",
"prov": "天津市",
"py": "xiqingqu"
},
{
"city": "津南区",
"district": "天津市",
"prov": "天津市",
"py": "jinnanqu"
},
{
"city": "北辰区",
"district": "天津市",
"prov": "天津市",
"py": "beichenqu"
},
{
"city": "武清区",
"district": "天津市",
"prov": "天津市",
"py": "wuqingqu"
},
{
"city": "宝坻区",
"district": "天津市",
"prov": "天津市",
"py": "baodiqu"
},
{
"city": "滨海新区",
"district": "天津市",
"prov": "天津市",
"py": "binhaixinqu"
},
{
"city": "宁河区",
"district": "天津市",
"prov": "天津市",
"py": "ninghequ"
},
{
"city": "静海区",
"district": "天津市",
"prov": "天津市",
"py": "jinghaiqu"
},
{
"city": "蓟州区",
"district": "天津市",
"prov": "天津市",
"py": "jizhouqu"
},
{
"city": "石家庄",
"district": "石家庄市",
"prov": "河北省",
"py": "shijiazhuang"
},
{
"city": "长安区",
"district": "石家庄市",
"prov": "河北省",
"py": "changanqu"
},
{
"city": "桥西区",
"district": "石家庄市",
"prov": "河北省",
"py": "qiaoxiqu"
},
{
"city": "新华区",
"district": "石家庄市",
"prov": "河北省",
"py": "xinhuaqu"
},
{
"city": "井陉矿区",
"district": "石家庄市",
"prov": "河北省",
"py": "jingxingkuangqu"
},
{
"city": "裕华",
"district": "石家庄市",
"prov": "河北省",
"py": "yuhua"
},
{
"city": "藁城",
"district": "石家庄市",
"prov": "河北省",
"py": "gaocheng"
},
{
"city": "鹿泉",
"district": "石家庄市",
"prov": "河北省",
"py": "luquan"
},
{
"city": "栾城",
"district": "石家庄市",
"prov": "河北省",
"py": "luancheng"
},
{
"city": "井陉",
"district": "石家庄市",
"prov": "河北省",
"py": "jingxing"
},
{
"city": "正定",
"district": "石家庄市",
"prov": "河北省",
"py": "zhengding"
},
{
"city": "行唐",
"district": "石家庄市",
"prov": "河北省",
"py": "xingtang"
},
{
"city": "灵寿",
"district": "石家庄市",
"prov": "河北省",
"py": "lingshou"
},
{
"city": "高邑",
"district": "石家庄市",
"prov": "河北省",
"py": "gaoyi"
},
{
"city": "深泽",
"district": "石家庄市",
"prov": "河北省",
"py": "shenze"
},
{
"city": "赞皇",
"district": "石家庄市",
"prov": "河北省",
"py": "zanhuang"
},
{
"city": "无极",
"district": "石家庄市",
"prov": "河北省",
"py": "wuji"
},
{
"city": "平山",
"district": "石家庄市",
"prov": "河北省",
"py": "pingshan"
},
{
"city": "元氏",
"district": "石家庄市",
"prov": "河北省",
"py": "yuanshi"
},
{
"city": "赵县",
"district": "石家庄市",
"prov": "河北省",
"py": "zhaoxian"
},
{
"city": "辛集",
"district": "石家庄市",
"prov": "河北省",
"py": "xinji"
},
{
"city": "晋州",
"district": "石家庄市",
"prov": "河北省",
"py": "jinzhou"
},
{
"city": "新乐",
"district": "石家庄市",
"prov": "河北省",
"py": "xinle"
},
{
"city": "唐山",
"district": "唐山市",
"prov": "河北省",
"py": "tangshan"
},
{
"city": "路南区",
"district": "唐山市",
"prov": "河北省",
"py": "lunanqu"
},
{
"city": "路北区",
"district": "唐山市",
"prov": "河北省",
"py": "lubeiqu"
},
{
"city": "古冶",
"district": "唐山市",
"prov": "河北省",
"py": "guye"
},
{
"city": "开平区",
"district": "唐山市",
"prov": "河北省",
"py": "kaipingqu"
},
{
"city": "丰南",
"district": "唐山市",
"prov": "河北省",
"py": "fengnan"
},
{
"city": "丰润",
"district": "唐山市",
"prov": "河北省",
"py": "fengrun"
},
{
"city": "曹妃甸",
"district": "唐山市",
"prov": "河北省",
"py": "caofeidian"
},
{
"city": "滦南",
"district": "唐山市",
"prov": "河北省",
"py": "luannan"
},
{
"city": "乐亭",
"district": "唐山市",
"prov": "河北省",
"py": "laoting"
},
{
"city": "迁西",
"district": "唐山市",
"prov": "河北省",
"py": "qianxi"
},
{
"city": "玉田",
"district": "唐山市",
"prov": "河北省",
"py": "yutian"
},
{
"city": "遵化",
"district": "唐山市",
"prov": "河北省",
"py": "zunhua"
},
{
"city": "迁安",
"district": "唐山市",
"prov": "河北省",
"py": "qianan"
},
{
"city": "滦州",
"district": "唐山市",
"prov": "河北省",
"py": "luanzhou"
},
{
"city": "秦皇岛",
"district": "秦皇岛市",
"prov": "河北省",
"py": "qinhuangdao"
},
{
"city": "海港区",
"district": "秦皇岛市",
"prov": "河北省",
"py": "haigangqu"
},
{
"city": "山海关",
"district": "秦皇岛市",
"prov": "河北省",
"py": "shanhaiguan"
},
{
"city": "北戴河",
"district": "秦皇岛市",
"prov": "河北省",
"py": "beidaihe"
},
{
"city": "抚宁",
"district": "秦皇岛市",
"prov": "河北省",
"py": "funing"
},
{
"city": "青龙",
"district": "秦皇岛市",
"prov": "河北省",
"py": "qinglong"
},
{
"city": "昌黎",
"district": "秦皇岛市",
"prov": "河北省",
"py": "changli"
},
{
"city": "卢龙",
"district": "秦皇岛市",
"prov": "河北省",
"py": "lulong"
},
{
"city": "邯郸",
"district": "邯郸市",
"prov": "河北省",
"py": "handan"
},
{
"city": "邯山区",
"district": "邯郸市",
"prov": "河北省",
"py": "hanshanqu"
},
{
"city": "丛台区",
"district": "邯郸市",
"prov": "河北省",
"py": "congtaiqu"
},
{
"city": "复兴区",
"district": "邯郸市",
"prov": "河北省",
"py": "fuxingqu"
},
{
"city": "峰峰",
"district": "邯郸市",
"prov": "河北省",
"py": "fengfeng"
},
{
"city": "肥乡",
"district": "邯郸市",
"prov": "河北省",
"py": "feixiang"
},
{
"city": "永年",
"district": "邯郸市",
"prov": "河北省",
"py": "yongnian"
},
{
"city": "临漳",
"district": "邯郸市",
"prov": "河北省",
"py": "linzhang"
},
{
"city": "成安",
"district": "邯郸市",
"prov": "河北省",
"py": "chengan"
},
{
"city": "大名",
"district": "邯郸市",
"prov": "河北省",
"py": "daming"
},
{
"city": "涉县",
"district": "邯郸市",
"prov": "河北省",
"py": "shexian"
},
{
"city": "磁县",
"district": "邯郸市",
"prov": "河北省",
"py": "cixian"
},
{
"city": "邱县",
"district": "邯郸市",
"prov": "河北省",
"py": "qiuxian"
},
{
"city": "鸡泽",
"district": "邯郸市",
"prov": "河北省",
"py": "jize"
},
{
"city": "广平",
"district": "邯郸市",
"prov": "河北省",
"py": "guangping"
},
{
"city": "馆陶",
"district": "邯郸市",
"prov": "河北省",
"py": "guantao"
},
{
"city": "魏县",
"district": "邯郸市",
"prov": "河北省",
"py": "weixian"
},
{
"city": "曲周",
"district": "邯郸市",
"prov": "河北省",
"py": "quzhou"
},
{
"city": "武安",
"district": "邯郸市",
"prov": "河北省",
"py": "wuan"
},
{
"city": "邢台",
"district": "邢台市",
"prov": "河北省",
"py": "xingtai"
},
{
"city": "桥东区",
"district": "邢台市",
"prov": "河北省",
"py": "qiaodongqu"
},
{
"city": "桥西区",
"district": "邢台市",
"prov": "河北省",
"py": "qiaoxiqu"
},
{
"city": "邢台县",
"district": "邢台市",
"prov": "河北省",
"py": "xingtaixian"
},
{
"city": "临城",
"district": "邢台市",
"prov": "河北省",
"py": "lincheng"
},
{
"city": "内丘",
"district": "邢台市",
"prov": "河北省",
"py": "neiqiu"
},
{
"city": "柏乡",
"district": "邢台市",
"prov": "河北省",
"py": "baixiang"
},
{
"city": "隆尧",
"district": "邢台市",
"prov": "河北省",
"py": "longyao"
},
{
"city": "任县",
"district": "邢台市",
"prov": "河北省",
"py": "renxian"
},
{
"city": "南和",
"district": "邢台市",
"prov": "河北省",
"py": "nanhe"
},
{
"city": "宁晋",
"district": "邢台市",
"prov": "河北省",
"py": "ningjin"
},
{
"city": "巨鹿",
"district": "邢台市",
"prov": "河北省",
"py": "julu"
},
{
"city": "新河",
"district": "邢台市",
"prov": "河北省",
"py": "xinhe"
},
{
"city": "广宗",
"district": "邢台市",
"prov": "河北省",
"py": "guangzong"
},
{
"city": "平乡",
"district": "邢台市",
"prov": "河北省",
"py": "pingxiang"
},
{
"city": "威县",
"district": "邢台市",
"prov": "河北省",
"py": "weixian"
},
{
"city": "清河",
"district": "邢台市",
"prov": "河北省",
"py": "qinghe"
},
{
"city": "临西",
"district": "邢台市",
"prov": "河北省",
"py": "linxi"
},
{
"city": "南宫",
"district": "邢台市",
"prov": "河北省",
"py": "nangong"
},
{
"city": "沙河",
"district": "邢台市",
"prov": "河北省",
"py": "shahe"
},
{
"city": "保定",
"district": "保定市",
"prov": "河北省",
"py": "baoding"
},
{
"city": "竞秀",
"district": "保定市",
"prov": "河北省",
"py": "jingxiu"
},
{
"city": "莲池",
"district": "保定市",
"prov": "河北省",
"py": "lianchi"
},
{
"city": "满城",
"district": "保定市",
"prov": "河北省",
"py": "mancheng"
},
{
"city": "清苑",
"district": "保定市",
"prov": "河北省",
"py": "qingyuan"
},
{
"city": "徐水",
"district": "保定市",
"prov": "河北省",
"py": "xushui"
},
{
"city": "涞水",
"district": "保定市",
"prov": "河北省",
"py": "laishui"
},
{
"city": "阜平",
"district": "保定市",
"prov": "河北省",
"py": "fuping"
},
{
"city": "定兴",
"district": "保定市",
"prov": "河北省",
"py": "dingxing"
},
{
"city": "唐县",
"district": "保定市",
"prov": "河北省",
"py": "tangxian"
},
{
"city": "高阳",
"district": "保定市",
"prov": "河北省",
"py": "gaoyang"
},
{
"city": "容城",
"district": "保定市",
"prov": "河北省",
"py": "rongcheng"
},
{
"city": "涞源",
"district": "保定市",
"prov": "河北省",
"py": "laiyuan"
},
{
"city": "望都",
"district": "保定市",
"prov": "河北省",
"py": "wangdu"
},
{
"city": "安新",
"district": "保定市",
"prov": "河北省",
"py": "anxin"
},
{
"city": "易县",
"district": "保定市",
"prov": "河北省",
"py": "yixian"
},
{
"city": "曲阳",
"district": "保定市",
"prov": "河北省",
"py": "quyang"
},
{
"city": "蠡县",
"district": "保定市",
"prov": "河北省",
"py": "lixian"
},
{
"city": "顺平",
"district": "保定市",
"prov": "河北省",
"py": "shunping"
},
{
"city": "博野",
"district": "保定市",
"prov": "河北省",
"py": "boye"
},
{
"city": "雄县",
"district": "保定市",
"prov": "河北省",
"py": "xiongxian"
},
{
"city": "涿州",
"district": "保定市",
"prov": "河北省",
"py": "zhuozhou"
},
{
"city": "定州",
"district": "保定市",
"prov": "河北省",
"py": "dingzhou"
},
{
"city": "安国",
"district": "保定市",
"prov": "河北省",
"py": "anguo"
},
{
"city": "高碑店",
"district": "保定市",
"prov": "河北省",
"py": "gaobeidian"
},
{
"city": "张家口",
"district": "张家口市",
"prov": "河北省",
"py": "zhangjiakou"
},
{
"city": "桥东区",
"district": "张家口市",
"prov": "河北省",
"py": "qiaodongqu"
},
{
"city": "桥西区",
"district": "张家口市",
"prov": "河北省",
"py": "qiaoxiqu"
},
{
"city": "宣化",
"district": "张家口市",
"prov": "河北省",
"py": "xuanhua"
},
{
"city": "下花园",
"district": "张家口市",
"prov": "河北省",
"py": "xiahuayuan"
},
{
"city": "万全",
"district": "张家口市",
"prov": "河北省",
"py": "wanquan"
},
{
"city": "崇礼",
"district": "张家口市",
"prov": "河北省",
"py": "chongli"
},
{
"city": "张北",
"district": "张家口市",
"prov": "河北省",
"py": "zhangbei"
},
{
"city": "康保",
"district": "张家口市",
"prov": "河北省",
"py": "kangbao"
},
{
"city": "沽源",
"district": "张家口市",
"prov": "河北省",
"py": "guyuan"
},
{
"city": "尚义",
"district": "张家口市",
"prov": "河北省",
"py": "shangyi"
},
{
"city": "蔚县",
"district": "张家口市",
"prov": "河北省",
"py": "yuxian"
},
{
"city": "阳原",
"district": "张家口市",
"prov": "河北省",
"py": "yangyuan"
},
{
"city": "怀安",
"district": "张家口市",
"prov": "河北省",
"py": "huaian"
},
{
"city": "怀来",
"district": "张家口市",
"prov": "河北省",
"py": "huailai"
},
{
"city": "涿鹿",
"district": "张家口市",
"prov": "河北省",
"py": "zhuolu"
},
{
"city": "赤城",
"district": "张家口市",
"prov": "河北省",
"py": "chicheng"
},
{
"city": "承德",
"district": "承德市",
"prov": "河北省",
"py": "chengde"
},
{
"city": "双桥",
"district": "承德市",
"prov": "河北省",
"py": "shuangqiao"
},
{
"city": "双滦",
"district": "承德市",
"prov": "河北省",
"py": "shuangluan"
},
{
"city": "鹰手营子",
"district": "承德市",
"prov": "河北省",
"py": "yingshouyingzi"
},
{
"city": "承德县",
"district": "承德市",
"prov": "河北省",
"py": "chengdexian"
},
{
"city": "兴隆",
"district": "承德市",
"prov": "河北省",
"py": "xinglong"
},
{
"city": "滦平",
"district": "承德市",
"prov": "河北省",
"py": "luanping"
},
{
"city": "隆化",
"district": "承德市",
"prov": "河北省",
"py": "longhua"
},
{
"city": "丰宁",
"district": "承德市",
"prov": "河北省",
"py": "fengning"
},
{
"city": "宽城",
"district": "承德市",
"prov": "河北省",
"py": "kuancheng"
},
{
"city": "围场",
"district": "承德市",
"prov": "河北省",
"py": "weichang"
},
{
"city": "平泉",
"district": "承德市",
"prov": "河北省",
"py": "pingquan"
},
{
"city": "沧州",
"district": "沧州市",
"prov": "河北省",
"py": "cangzhou"
},
{
"city": "新华区",
"district": "沧州市",
"prov": "河北省",
"py": "xinhuaqu"
},
{
"city": "运河",
"district": "沧州市",
"prov": "河北省",
"py": "yunhe"
},
{
"city": "沧县",
"district": "沧州市",
"prov": "河北省",
"py": "cangxian"
},
{
"city": "青县",
"district": "沧州市",
"prov": "河北省",
"py": "qingxian"
},
{
"city": "东光",
"district": "沧州市",
"prov": "河北省",
"py": "dongguang"
},
{
"city": "海兴",
"district": "沧州市",
"prov": "河北省",
"py": "haixing"
},
{
"city": "盐山",
"district": "沧州市",
"prov": "河北省",
"py": "yanshan"
},
{
"city": "肃宁",
"district": "沧州市",
"prov": "河北省",
"py": "suning"
},
{
"city": "南皮",
"district": "沧州市",
"prov": "河北省",
"py": "nanpi"
},
{
"city": "吴桥",
"district": "沧州市",
"prov": "河北省",
"py": "wuqiao"
},
{
"city": "献县",
"district": "沧州市",
"prov": "河北省",
"py": "xianxian"
},
{
"city": "孟村",
"district": "沧州市",
"prov": "河北省",
"py": "mengcun"
},
{
"city": "泊头",
"district": "沧州市",
"prov": "河北省",
"py": "botou"
},
{
"city": "任丘",
"district": "沧州市",
"prov": "河北省",
"py": "renqiu"
},
{
"city": "黄骅",
"district": "沧州市",
"prov": "河北省",
"py": "huanghua"
},
{
"city": "河间",
"district": "沧州市",
"prov": "河北省",
"py": "hejian"
},
{
"city": "廊坊",
"district": "廊坊市",
"prov": "河北省",
"py": "langfang"
},
{
"city": "安次",
"district": "廊坊市",
"prov": "河北省",
"py": "anci"
},
{
"city": "广阳",
"district": "廊坊市",
"prov": "河北省",
"py": "guangyang"
},
{
"city": "固安",
"district": "廊坊市",
"prov": "河北省",
"py": "guan"
},
{
"city": "永清",
"district": "廊坊市",
"prov": "河北省",
"py": "yongqing"
},
{
"city": "香河",
"district": "廊坊市",
"prov": "河北省",
"py": "xianghe"
},
{
"city": "大城",
"district": "廊坊市",
"prov": "河北省",
"py": "dacheng"
},
{
"city": "文安",
"district": "廊坊市",
"prov": "河北省",
"py": "wenan"
},
{
"city": "大厂",
"district": "廊坊市",
"prov": "河北省",
"py": "dachang"
},
{
"city": "霸州",
"district": "廊坊市",
"prov": "河北省",
"py": "bazhou"
},
{
"city": "三河",
"district": "廊坊市",
"prov": "河北省",
"py": "sanhe"
},
{
"city": "衡水",
"district": "衡水市",
"prov": "河北省",
"py": "hengshui"
},
{
"city": "桃城",
"district": "衡水市",
"prov": "河北省",
"py": "taocheng"
},
{
"city": "冀州",
"district": "衡水市",
"prov": "河北省",
"py": "jizhou"
},
{
"city": "枣强",
"district": "衡水市",
"prov": "河北省",
"py": "zaoqiang"
},
{
"city": "武邑",
"district": "衡水市",
"prov": "河北省",
"py": "wuyi"
},
{
"city": "武强",
"district": "衡水市",
"prov": "河北省",
"py": "wuqiang"
},
{
"city": "饶阳",
"district": "衡水市",
"prov": "河北省",
"py": "raoyang"
},
{
"city": "安平",
"district": "衡水市",
"prov": "河北省",
"py": "anping"
},
{
"city": "故城",
"district": "衡水市",
"prov": "河北省",
"py": "gucheng"
},
{
"city": "景县",
"district": "衡水市",
"prov": "河北省",
"py": "jingxian"
},
{
"city": "阜城",
"district": "衡水市",
"prov": "河北省",
"py": "fucheng"
},
{
"city": "深州",
"district": "衡水市",
"prov": "河北省",
"py": "shenzhou"
},
{
"city": "太原",
"district": "太原市",
"prov": "山西省",
"py": "taiyuan"
},
{
"city": "小店",
"district": "太原市",
"prov": "山西省",
"py": "xiaodian"
},
{
"city": "迎泽",
"district": "太原市",
"prov": "山西省",
"py": "yingze"
},
{
"city": "杏花岭",
"district": "太原市",
"prov": "山西省",
"py": "xinghualing"
},
{
"city": "尖草坪",
"district": "太原市",
"prov": "山西省",
"py": "jiancaoping"
},
{
"city": "万柏林",
"district": "太原市",
"prov": "山西省",
"py": "wanbailin"
},
{
"city": "晋源",
"district": "太原市",
"prov": "山西省",
"py": "jinyuan"
},
{
"city": "清徐",
"district": "太原市",
"prov": "山西省",
"py": "qingxu"
},
{
"city": "阳曲",
"district": "太原市",
"prov": "山西省",
"py": "yangqu"
},
{
"city": "娄烦",
"district": "太原市",
"prov": "山西省",
"py": "loufan"
},
{
"city": "古交",
"district": "太原市",
"prov": "山西省",
"py": "gujiao"
},
{
"city": "大同",
"district": "大同市",
"prov": "山西省",
"py": "datong"
},
{
"city": "新荣",
"district": "大同市",
"prov": "山西省",
"py": "xinrong"
},
{
"city": "平城",
"district": "大同市",
"prov": "山西省",
"py": "pingcheng"
},
{
"city": "云冈",
"district": "大同市",
"prov": "山西省",
"py": "yungang"
},
{
"city": "云州",
"district": "大同市",
"prov": "山西省",
"py": "yunzhou"
},
{
"city": "阳高",
"district": "大同市",
"prov": "山西省",
"py": "yanggao"
},
{
"city": "天镇",
"district": "大同市",
"prov": "山西省",
"py": "tianzhen"
},
{
"city": "广灵",
"district": "大同市",
"prov": "山西省",
"py": "guangling"
},
{
"city": "灵丘",
"district": "大同市",
"prov": "山西省",
"py": "lingqiu"
},
{
"city": "浑源",
"district": "大同市",
"prov": "山西省",
"py": "hunyuan"
},
{
"city": "左云",
"district": "大同市",
"prov": "山西省",
"py": "zuoyun"
},
{
"city": "阳泉",
"district": "阳泉市",
"prov": "山西省",
"py": "yangquan"
},
{
"city": "城区",
"district": "阳泉市",
"prov": "山西省",
"py": "chengqu"
},
{
"city": "矿区",
"district": "阳泉市",
"prov": "山西省",
"py": "kuangqu"
},
{
"city": "郊区",
"district": "阳泉市",
"prov": "山西省",
"py": "jiaoqu"
},
{
"city": "平定",
"district": "阳泉市",
"prov": "山西省",
"py": "pingding"
},
{
"city": "盂县",
"district": "阳泉市",
"prov": "山西省",
"py": "yuxian"
},
{
"city": "长治",
"district": "长治市",
"prov": "山西省",
"py": "changzhi"
},
{
"city": "潞州",
"district": "长治市",
"prov": "山西省",
"py": "luzhou"
},
{
"city": "上党",
"district": "长治市",
"prov": "山西省",
"py": "shangdang"
},
{
"city": "屯留",
"district": "长治市",
"prov": "山西省",
"py": "tunliu"
},
{
"city": "潞城",
"district": "长治市",
"prov": "山西省",
"py": "lucheng"
},
{
"city": "襄垣",
"district": "长治市",
"prov": "山西省",
"py": "xiangyuan"
},
{
"city": "平顺",
"district": "长治市",
"prov": "山西省",
"py": "pingshun"
},
{
"city": "黎城",
"district": "长治市",
"prov": "山西省",
"py": "licheng"
},
{
"city": "壶关",
"district": "长治市",
"prov": "山西省",
"py": "huguan"
},
{
"city": "长子",
"district": "长治市",
"prov": "山西省",
"py": "zhangzi"
},
{
"city": "武乡",
"district": "长治市",
"prov": "山西省",
"py": "wuxiang"
},
{
"city": "沁县",
"district": "长治市",
"prov": "山西省",
"py": "qinxian"
},
{
"city": "沁源",
"district": "长治市",
"prov": "山西省",
"py": "qinyuan"
},
{
"city": "晋城",
"district": "晋城市",
"prov": "山西省",
"py": "jincheng"
},
{
"city": "城区",
"district": "晋城市",
"prov": "山西省",
"py": "chengqu"
},
{
"city": "沁水",
"district": "晋城市",
"prov": "山西省",
"py": "qinshui"
},
{
"city": "阳城",
"district": "晋城市",
"prov": "山西省",
"py": "yangcheng"
},
{
"city": "陵川",
"district": "晋城市",
"prov": "山西省",
"py": "lingchuan"
},
{
"city": "泽州",
"district": "晋城市",
"prov": "山西省",
"py": "zezhou"
},
{
"city": "高平",
"district": "晋城市",
"prov": "山西省",
"py": "gaoping"
},
{
"city": "朔州",
"district": "朔州市",
"prov": "山西省",
"py": "shuozhou"
},
{
"city": "朔城",
"district": "朔州市",
"prov": "山西省",
"py": "shuocheng"
},
{
"city": "平鲁",
"district": "朔州市",
"prov": "山西省",
"py": "pinglu"
},
{
"city": "山阴",
"district": "朔州市",
"prov": "山西省",
"py": "shanyin"
},
{
"city": "应县",
"district": "朔州市",
"prov": "山西省",
"py": "yingxian"
},
{
"city": "右玉",
"district": "朔州市",
"prov": "山西省",
"py": "youyu"
},
{
"city": "怀仁",
"district": "朔州市",
"prov": "山西省",
"py": "huairen"
},
{
"city": "晋中",
"district": "晋中市",
"prov": "山西省",
"py": "jinzhong"
},
{
"city": "榆次",
"district": "晋中市",
"prov": "山西省",
"py": "yuci"
},
{
"city": "榆社",
"district": "晋中市",
"prov": "山西省",
"py": "yushe"
},
{
"city": "左权",
"district": "晋中市",
"prov": "山西省",
"py": "zuoquan"
},
{
"city": "和顺",
"district": "晋中市",
"prov": "山西省",
"py": "heshun"
},
{
"city": "昔阳",
"district": "晋中市",
"prov": "山西省",
"py": "xiyang"
},
{
"city": "寿阳",
"district": "晋中市",
"prov": "山西省",
"py": "shouyang"
},
{
"city": "太谷",
"district": "晋中市",
"prov": "山西省",
"py": "taigu"
},
{
"city": "祁县",
"district": "晋中市",
"prov": "山西省",
"py": "qixian"
},
{
"city": "平遥",
"district": "晋中市",
"prov": "山西省",
"py": "pingyao"
},
{
"city": "灵石",
"district": "晋中市",
"prov": "山西省",
"py": "lingshi"
},
{
"city": "介休",
"district": "晋中市",
"prov": "山西省",
"py": "jiexiu"
},
{
"city": "运城",
"district": "运城市",
"prov": "山西省",
"py": "yuncheng"
},
{
"city": "盐湖",
"district": "运城市",
"prov": "山西省",
"py": "yanhu"
},
{
"city": "临猗",
"district": "运城市",
"prov": "山西省",
"py": "linyi"
},
{
"city": "万荣",
"district": "运城市",
"prov": "山西省",
"py": "wanrong"
},
{
"city": "闻喜",
"district": "运城市",
"prov": "山西省",
"py": "wenxi"
},
{
"city": "稷山",
"district": "运城市",
"prov": "山西省",
"py": "jishan"
},
{
"city": "新绛",
"district": "运城市",
"prov": "山西省",
"py": "xinjiang"
},
{
"city": "绛县",
"district": "运城市",
"prov": "山西省",
"py": "jiangxian"
},
{
"city": "垣曲",
"district": "运城市",
"prov": "山西省",
"py": "yuanqu"
},
{
"city": "夏县",
"district": "运城市",
"prov": "山西省",
"py": "xiaxian"
},
{
"city": "平陆",
"district": "运城市",
"prov": "山西省",
"py": "pinglu"
},
{
"city": "芮城",
"district": "运城市",
"prov": "山西省",
"py": "ruicheng"
},
{
"city": "永济",
"district": "运城市",
"prov": "山西省",
"py": "yongji"
},
{
"city": "河津",
"district": "运城市",
"prov": "山西省",
"py": "hejin"
},
{
"city": "忻州",
"district": "忻州市",
"prov": "山西省",
"py": "xinzhou"
},
{
"city": "忻府",
"district": "忻州市",
"prov": "山西省",
"py": "xinfu"
},
{
"city": "定襄",
"district": "忻州市",
"prov": "山西省",
"py": "dingxiang"
},
{
"city": "五台",
"district": "忻州市",
"prov": "山西省",
"py": "wutai"
},
{
"city": "代县",
"district": "忻州市",
"prov": "山西省",
"py": "daixian"
},
{
"city": "繁峙",
"district": "忻州市",
"prov": "山西省",
"py": "fanshi"
},
{
"city": "宁武",
"district": "忻州市",
"prov": "山西省",
"py": "ningwu"
},
{
"city": "静乐",
"district": "忻州市",
"prov": "山西省",
"py": "jingle"
},
{
"city": "神池",
"district": "忻州市",
"prov": "山西省",
"py": "shenchi"
},
{
"city": "五寨",
"district": "忻州市",
"prov": "山西省",
"py": "wuzhai"
},
{
"city": "岢岚",
"district": "忻州市",
"prov": "山西省",
"py": "kelan"
},
{
"city": "河曲",
"district": "忻州市",
"prov": "山西省",
"py": "hequ"
},
{
"city": "保德",
"district": "忻州市",
"prov": "山西省",
"py": "baode"
},
{
"city": "偏关",
"district": "忻州市",
"prov": "山西省",
"py": "pianguan"
},
{
"city": "原平",
"district": "忻州市",
"prov": "山西省",
"py": "yuanping"
},
{
"city": "临汾",
"district": "临汾市",
"prov": "山西省",
"py": "linfen"
},
{
"city": "尧都",
"district": "临汾市",
"prov": "山西省",
"py": "yaodu"
},
{
"city": "曲沃",
"district": "临汾市",
"prov": "山西省",
"py": "quwo"
},
{
"city": "翼城",
"district": "临汾市",
"prov": "山西省",
"py": "yicheng"
},
{
"city": "襄汾",
"district": "临汾市",
"prov": "山西省",
"py": "xiangfen"
},
{
"city": "洪洞",
"district": "临汾市",
"prov": "山西省",
"py": "hongtong"
},
{
"city": "古县",
"district": "临汾市",
"prov": "山西省",
"py": "guxian"
},
{
"city": "安泽",
"district": "临汾市",
"prov": "山西省",
"py": "anze"
},
{
"city": "浮山",
"district": "临汾市",
"prov": "山西省",
"py": "fushan"
},
{
"city": "吉县",
"district": "临汾市",
"prov": "山西省",
"py": "jixian"
},
{
"city": "乡宁",
"district": "临汾市",
"prov": "山西省",
"py": "xiangning"
},
{
"city": "大宁",
"district": "临汾市",
"prov": "山西省",
"py": "daning"
},
{
"city": "隰县",
"district": "临汾市",
"prov": "山西省",
"py": "xixian"
},
{
"city": "永和",
"district": "临汾市",
"prov": "山西省",
"py": "yonghe"
},
{
"city": "蒲县",
"district": "临汾市",
"prov": "山西省",
"py": "puxian"
},
{
"city": "汾西",
"district": "临汾市",
"prov": "山西省",
"py": "fenxi"
},
{
"city": "侯马",
"district": "临汾市",
"prov": "山西省",
"py": "houma"
},
{
"city": "霍州",
"district": "临汾市",
"prov": "山西省",
"py": "huozhou"
},
{
"city": "吕梁",
"district": "吕梁市",
"prov": "山西省",
"py": "lvliang"
},
{
"city": "离石",
"district": "吕梁市",
"prov": "山西省",
"py": "lishi"
},
{
"city": "文水",
"district": "吕梁市",
"prov": "山西省",
"py": "wenshui"
},
{
"city": "交城",
"district": "吕梁市",
"prov": "山西省",
"py": "jiaocheng"
},
{
"city": "兴县",
"district": "吕梁市",
"prov": "山西省",
"py": "xingxian"
},
{
"city": "临县",
"district": "吕梁市",
"prov": "山西省",
"py": "linxian"
},
{
"city": "柳林",
"district": "吕梁市",
"prov": "山西省",
"py": "liulin"
},
{
"city": "石楼",
"district": "吕梁市",
"prov": "山西省",
"py": "shilou"
},
{
"city": "岚县",
"district": "吕梁市",
"prov": "山西省",
"py": "lanxian"
},
{
"city": "方山",
"district": "吕梁市",
"prov": "山西省",
"py": "fangshan"
},
{
"city": "中阳",
"district": "吕梁市",
"prov": "山西省",
"py": "zhongyang"
},
{
"city": "交口",
"district": "吕梁市",
"prov": "山西省",
"py": "jiaokou"
},
{
"city": "孝义",
"district": "吕梁市",
"prov": "山西省",
"py": "xiaoyi"
},
{
"city": "汾阳",
"district": "吕梁市",
"prov": "山西省",
"py": "fenyang"
},
{
"city": "呼和浩特",
"district": "呼和浩特市",
"prov": "内蒙古自治区",
"py": "huhehaote"
},
{
"city": "新城区",
"district": "呼和浩特市",
"prov": "内蒙古自治区",
"py": "xinchengqu"
},
{
"city": "回民区",
"district": "呼和浩特市",
"prov": "内蒙古自治区",
"py": "huiminqu"
},
{
"city": "玉泉区",
"district": "呼和浩特市",
"prov": "内蒙古自治区",
"py": "yuquanqu"
},
{
"city": "赛罕区",
"district": "呼和浩特市",
"prov": "内蒙古自治区",
"py": "saihanqu"
},
{
"city": "土左旗",
"district": "呼和浩特市",
"prov": "内蒙古自治区",
"py": "tuzuoqi"
},
{
"city": "托克托",
"district": "呼和浩特市",
"prov": "内蒙古自治区",
"py": "tuoketuo"
},
{
"city": "和林格尔",
"district": "呼和浩特市",
"prov": "内蒙古自治区",
"py": "helingeer"
},
{
"city": "清水河",
"district": "呼和浩特市",
"prov": "内蒙古自治区",
"py": "qingshuihe"
},
{
"city": "武川",
"district": "呼和浩特市",
"prov": "内蒙古自治区",
"py": "wuchuan"
},
{
"city": "包头",
"district": "包头市",
"prov": "内蒙古自治区",
"py": "baotou"
},
{
"city": "东河区",
"district": "包头市",
"prov": "内蒙古自治区",
"py": "donghequ"
},
{
"city": "昆都仑区",
"district": "包头市",
"prov": "内蒙古自治区",
"py": "kundulunqu"
},
{
"city": "青山区",
"district": "包头市",
"prov": "内蒙古自治区",
"py": "qingshanqu"
},
{
"city": "石拐区",
"district": "包头市",
"prov": "内蒙古自治区",
"py": "shiguaiqu"
},
{
"city": "白云鄂博",
"district": "包头市",
"prov": "内蒙古自治区",
"py": "baiyunebo"
},
{
"city": "九原区",
"district": "包头市",
"prov": "内蒙古自治区",
"py": "jiuyuanqu"
},
{
"city": "土右旗",
"district": "包头市",
"prov": "内蒙古自治区",
"py": "tuyouqi"
},
{
"city": "固阳",
"district": "包头市",
"prov": "内蒙古自治区",
"py": "guyang"
},
{
"city": "达茂旗",
"district": "包头市",
"prov": "内蒙古自治区",
"py": "damaoqi"
},
{
"city": "乌海",
"district": "乌海市",
"prov": "内蒙古自治区",
"py": "wuhai"
},
{
"city": "海勃湾区",
"district": "乌海市",
"prov": "内蒙古自治区",
"py": "haibowanqu"
},
{
"city": "海南区",
"district": "乌海市",
"prov": "内蒙古自治区",
"py": "hainanqu"
},
{
"city": "乌达",
"district": "乌海市",
"prov": "内蒙古自治区",
"py": "wuda"
},
{
"city": "赤峰",
"district": "赤峰市",
"prov": "内蒙古自治区",
"py": "chifeng"
},
{
"city": "红山",
"district": "赤峰市",
"prov": "内蒙古自治区",
"py": "hongshan"
},
{
"city": "元宝山",
"district": "赤峰市",
"prov": "内蒙古自治区",
"py": "yuanbaoshan"
},
{
"city": "松山",
"district": "赤峰市",
"prov": "内蒙古自治区",
"py": "songshan"
},
{
"city": "阿鲁旗",
"district": "赤峰市",
"prov": "内蒙古自治区",
"py": "aluqi"
},
{
"city": "巴林左旗",
"district": "赤峰市",
"prov": "内蒙古自治区",
"py": "balinzuoqi"
},
{
"city": "巴林右旗",
"district": "赤峰市",
"prov": "内蒙古自治区",
"py": "balinyouqi"
},
{
"city": "林西",
"district": "赤峰市",
"prov": "内蒙古自治区",
"py": "linxi"
},
{
"city": "克什克腾旗",
"district": "赤峰市",
"prov": "内蒙古自治区",
"py": "keshiketengqi"
},
{
"city": "翁牛特旗",
"district": "赤峰市",
"prov": "内蒙古自治区",
"py": "wengniuteqi"
},
{
"city": "喀喇沁旗",
"district": "赤峰市",
"prov": "内蒙古自治区",
"py": "kalaqinqi"
},
{
"city": "宁城",
"district": "赤峰市",
"prov": "内蒙古自治区",
"py": "ningcheng"
},
{
"city": "敖汉旗",
"district": "赤峰市",
"prov": "内蒙古自治区",
"py": "aohanqi"
},
{
"city": "通辽",
"district": "通辽市",
"prov": "内蒙古自治区",
"py": "tongliao"
},
{
"city": "科尔沁区",
"district": "通辽市",
"prov": "内蒙古自治区",
"py": "keerqinqu"
},
{
"city": "科左中旗",
"district": "通辽市",
"prov": "内蒙古自治区",
"py": "kezuozhongqi"
},
{
"city": "科左后旗",
"district": "通辽市",
"prov": "内蒙古自治区",
"py": "kezuohouqi"
},
{
"city": "开鲁",
"district": "通辽市",
"prov": "内蒙古自治区",
"py": "kailu"
},
{
"city": "库伦旗",
"district": "通辽市",
"prov": "内蒙古自治区",
"py": "kulunqi"
},
{
"city": "奈曼旗",
"district": "通辽市",
"prov": "内蒙古自治区",
"py": "naimanqi"
},
{
"city": "扎鲁特旗",
"district": "通辽市",
"prov": "内蒙古自治区",
"py": "zhaluteqi"
},
{
"city": "霍林郭勒",
"district": "通辽市",
"prov": "内蒙古自治区",
"py": "huolinguole"
},
{
"city": "鄂尔多斯",
"district": "鄂尔多斯市",
"prov": "内蒙古自治区",
"py": "eerduosi"
},
{
"city": "东胜",
"district": "鄂尔多斯市",
"prov": "内蒙古自治区",
"py": "dongsheng"
},
{
"city": "康巴什",
"district": "鄂尔多斯市",
"prov": "内蒙古自治区",
"py": "kangbashi"
},
{
"city": "达拉特旗",
"district": "鄂尔多斯市",
"prov": "内蒙古自治区",
"py": "dalateqi"
},
{
"city": "准格尔旗",
"district": "鄂尔多斯市",
"prov": "内蒙古自治区",
"py": "zhungeerqi"
},
{
"city": "鄂前旗",
"district": "鄂尔多斯市",
"prov": "内蒙古自治区",
"py": "eqianqi"
},
{
"city": "鄂托克旗",
"district": "鄂尔多斯市",
"prov": "内蒙古自治区",
"py": "etuokeqi"
},
{
"city": "杭锦旗",
"district": "鄂尔多斯市",
"prov": "内蒙古自治区",
"py": "hangjinqi"
},
{
"city": "乌审旗",
"district": "鄂尔多斯市",
"prov": "内蒙古自治区",
"py": "wushenqi"
},
{
"city": "伊金霍洛",
"district": "鄂尔多斯市",
"prov": "内蒙古自治区",
"py": "yijinhuoluo"
},
{
"city": "呼伦贝尔",
"district": "呼伦贝尔市",
"prov": "内蒙古自治区",
"py": "hulunbeier"
},
{
"city": "海拉尔",
"district": "呼伦贝尔市",
"prov": "内蒙古自治区",
"py": "hailaer"
},
{
"city": "扎赉诺尔",
"district": "呼伦贝尔市",
"prov": "内蒙古自治区",
"py": "zhalainuoer"
},
{
"city": "阿荣旗",
"district": "呼伦贝尔市",
"prov": "内蒙古自治区",
"py": "arongqi"
},
{
"city": "莫力达瓦",
"district": "呼伦贝尔市",
"prov": "内蒙古自治区",
"py": "molidawa"
},
{
"city": "鄂伦春旗",
"district": "呼伦贝尔市",
"prov": "内蒙古自治区",
"py": "elunchunqi"
},
{
"city": "鄂温克旗",
"district": "呼伦贝尔市",
"prov": "内蒙古自治区",
"py": "ewenkeqi"
},
{
"city": "陈旗",
"district": "呼伦贝尔市",
"prov": "内蒙古自治区",
"py": "chenqi"
},
{
"city": "新左旗",
"district": "呼伦贝尔市",
"prov": "内蒙古自治区",
"py": "xinzuoqi"
},
{
"city": "新右旗",
"district": "呼伦贝尔市",
"prov": "内蒙古自治区",
"py": "xinyouqi"
},
{
"city": "满洲里",
"district": "呼伦贝尔市",
"prov": "内蒙古自治区",
"py": "manzhouli"
},
{
"city": "牙克石",
"district": "呼伦贝尔市",
"prov": "内蒙古自治区",
"py": "yakeshi"
},
{
"city": "扎兰屯",
"district": "呼伦贝尔市",
"prov": "内蒙古自治区",
"py": "zhalantun"
},
{
"city": "额尔古纳",
"district": "呼伦贝尔市",
"prov": "内蒙古自治区",
"py": "eerguna"
},
{
"city": "根河",
"district": "呼伦贝尔市",
"prov": "内蒙古自治区",
"py": "genhe"
},
{
"city": "巴彦淖尔",
"district": "巴彦淖尔市",
"prov": "内蒙古自治区",
"py": "bayannaoer"
},
{
"city": "临河",
"district": "巴彦淖尔市",
"prov": "内蒙古自治区",
"py": "linhe"
},
{
"city": "五原",
"district": "巴彦淖尔市",
"prov": "内蒙古自治区",
"py": "wuyuan"
},
{
"city": "磴口",
"district": "巴彦淖尔市",
"prov": "内蒙古自治区",
"py": "dengkou"
},
{
"city": "乌前旗",
"district": "巴彦淖尔市",
"prov": "内蒙古自治区",
"py": "wuqianqi"
},
{
"city": "乌中旗",
"district": "巴彦淖尔市",
"prov": "内蒙古自治区",
"py": "wuzhongqi"
},
{
"city": "乌后旗",
"district": "巴彦淖尔市",
"prov": "内蒙古自治区",
"py": "wuhouqi"
},
{
"city": "杭锦后旗",
"district": "巴彦淖尔市",
"prov": "内蒙古自治区",
"py": "hangjinhouqi"
},
{
"city": "乌兰察布",
"district": "乌兰察布市",
"prov": "内蒙古自治区",
"py": "wulanchabu"
},
{
"city": "集宁",
"district": "乌兰察布市",
"prov": "内蒙古自治区",
"py": "jining"
},
{
"city": "卓资",
"district": "乌兰察布市",
"prov": "内蒙古自治区",
"py": "zhuozi"
},
{
"city": "化德",
"district": "乌兰察布市",
"prov": "内蒙古自治区",
"py": "huade"
},
{
"city": "商都",
"district": "乌兰察布市",
"prov": "内蒙古自治区",
"py": "shangdu"
},
{
"city": "兴和",
"district": "乌兰察布市",
"prov": "内蒙古自治区",
"py": "xinghe"
},
{
"city": "凉城",
"district": "乌兰察布市",
"prov": "内蒙古自治区",
"py": "liangcheng"
},
{
"city": "察右前旗",
"district": "乌兰察布市",
"prov": "内蒙古自治区",
"py": "chayouqianqi"
},
{
"city": "察右中旗",
"district": "乌兰察布市",
"prov": "内蒙古自治区",
"py": "chayouzhongqi"
},
{
"city": "察右后旗",
"district": "乌兰察布市",
"prov": "内蒙古自治区",
"py": "chayouhouqi"
},
{
"city": "四子王旗",
"district": "乌兰察布市",
"prov": "内蒙古自治区",
"py": "siziwangqi"
},
{
"city": "丰镇",
"district": "乌兰察布市",
"prov": "内蒙古自治区",
"py": "fengzhen"
},
{
"city": "兴安盟",
"district": "兴安盟",
"prov": "内蒙古自治区",
"py": "xinganmeng"
},
{
"city": "乌兰浩特",
"district": "兴安盟",
"prov": "内蒙古自治区",
"py": "wulanhaote"
},
{
"city": "阿尔山",
"district": "兴安盟",
"prov": "内蒙古自治区",
"py": "aershan"
},
{
"city": "科右前旗",
"district": "兴安盟",
"prov": "内蒙古自治区",
"py": "keyouqianqi"
},
{
"city": "科右中旗",
"district": "兴安盟",
"prov": "内蒙古自治区",
"py": "keyouzhongqi"
},
{
"city": "扎赉特旗",
"district": "兴安盟",
"prov": "内蒙古自治区",
"py": "zhalaiteqi"
},
{
"city": "突泉",
"district": "兴安盟",
"prov": "内蒙古自治区",
"py": "tuquan"
},
{
"city": "锡林郭勒",
"district": "锡林郭勒盟",
"prov": "内蒙古自治区",
"py": "xilinguole"
},
{
"city": "二连浩特",
"district": "锡林郭勒盟",
"prov": "内蒙古自治区",
"py": "erlianhaote"
},
{
"city": "锡林浩特",
"district": "锡林郭勒盟",
"prov": "内蒙古自治区",
"py": "xilinhaote"
},
{
"city": "阿巴嘎旗",
"district": "锡林郭勒盟",
"prov": "内蒙古自治区",
"py": "abagaqi"
},
{
"city": "苏左旗",
"district": "锡林郭勒盟",
"prov": "内蒙古自治区",
"py": "suzuoqi"
},
{
"city": "苏右旗",
"district": "锡林郭勒盟",
"prov": "内蒙古自治区",
"py": "suyouqi"
},
{
"city": "东乌旗",
"district": "锡林郭勒盟",
"prov": "内蒙古自治区",
"py": "dongwuqi"
},
{
"city": "西乌旗",
"district": "锡林郭勒盟",
"prov": "内蒙古自治区",
"py": "xiwuqi"
},
{
"city": "太仆寺旗",
"district": "锡林郭勒盟",
"prov": "内蒙古自治区",
"py": "taipusiqi"
},
{
"city": "镶黄旗",
"district": "锡林郭勒盟",
"prov": "内蒙古自治区",
"py": "xianghuangqi"
},
{
"city": "正镶白旗",
"district": "锡林郭勒盟",
"prov": "内蒙古自治区",
"py": "zhengxiangbaiqi"
},
{
"city": "正蓝旗",
"district": "锡林郭勒盟",
"prov": "内蒙古自治区",
"py": "zhenglanqi"
},
{
"city": "多伦",
"district": "锡林郭勒盟",
"prov": "内蒙古自治区",
"py": "duolun"
},
{
"city": "阿拉善",
"district": "阿拉善盟",
"prov": "内蒙古自治区",
"py": "alashan"
},
{
"city": "阿左旗",
"district": "阿拉善盟",
"prov": "内蒙古自治区",
"py": "azuoqi"
},
{
"city": "阿右旗",
"district": "阿拉善盟",
"prov": "内蒙古自治区",
"py": "ayouqi"
},
{
"city": "额济纳旗",
"district": "阿拉善盟",
"prov": "内蒙古自治区",
"py": "ejinaqi"
},
{
"city": "沈阳",
"district": "沈阳市",
"prov": "辽宁省",
"py": "shenyang"
},
{
"city": "和平区",
"district": "沈阳市",
"prov": "辽宁省",
"py": "hepingqu"
},
{
"city": "沈河区",
"district": "沈阳市",
"prov": "辽宁省",
"py": "shenhequ"
},
{
"city": "大东区",
"district": "沈阳市",
"prov": "辽宁省",
"py": "dadongqu"
},
{
"city": "皇姑区",
"district": "沈阳市",
"prov": "辽宁省",
"py": "huangguqu"
},
{
"city": "铁西区",
"district": "沈阳市",
"prov": "辽宁省",
"py": "tiexiqu"
},
{
"city": "苏家屯",
"district": "沈阳市",
"prov": "辽宁省",
"py": "sujiatun"
},
{
"city": "浑南",
"district": "沈阳市",
"prov": "辽宁省",
"py": "hunnan"
},
{
"city": "沈北新区",
"district": "沈阳市",
"prov": "辽宁省",
"py": "shenbeixinqu"
},
{
"city": "于洪区",
"district": "沈阳市",
"prov": "辽宁省",
"py": "yuhongqu"
},
{
"city": "辽中区",
"district": "沈阳市",
"prov": "辽宁省",
"py": "liaozhongqu"
},
{
"city": "康平",
"district": "沈阳市",
"prov": "辽宁省",
"py": "kangping"
},
{
"city": "法库",
"district": "沈阳市",
"prov": "辽宁省",
"py": "faku"
},
{
"city": "新民",
"district": "沈阳市",
"prov": "辽宁省",
"py": "xinmin"
},
{
"city": "大连",
"district": "大连市",
"prov": "辽宁省",
"py": "dalian"
},
{
"city": "中山区",
"district": "大连市",
"prov": "辽宁省",
"py": "zhongshanqu"
},
{
"city": "西岗区",
"district": "大连市",
"prov": "辽宁省",
"py": "xigangqu"
},
{
"city": "沙河口",
"district": "大连市",
"prov": "辽宁省",
"py": "shahekou"
},
{
"city": "甘井子",
"district": "大连市",
"prov": "辽宁省",
"py": "ganjingzi"
},
{
"city": "旅顺",
"district": "大连市",
"prov": "辽宁省",
"py": "lvshun"
},
{
"city": "金州",
"district": "大连市",
"prov": "辽宁省",
"py": "jinzhou"
},
{
"city": "普兰店",
"district": "大连市",
"prov": "辽宁省",
"py": "pulandian"
},
{
"city": "长海",
"district": "大连市",
"prov": "辽宁省",
"py": "changhai"
},
{
"city": "瓦房店",
"district": "大连市",
"prov": "辽宁省",
"py": "wafangdian"
},
{
"city": "庄河",
"district": "大连市",
"prov": "辽宁省",
"py": "zhuanghe"
},
{
"city": "鞍山",
"district": "鞍山市",
"prov": "辽宁省",
"py": "anshan"
},
{
"city": "铁东区",
"district": "鞍山市",
"prov": "辽宁省",
"py": "tiedongqu"
},
{
"city": "铁西区",
"district": "鞍山市",
"prov": "辽宁省",
"py": "tiexiqu"
},
{
"city": "立山",
"district": "鞍山市",
"prov": "辽宁省",
"py": "lishan"
},
{
"city": "千山",
"district": "鞍山市",
"prov": "辽宁省",
"py": "qianshan"
},
{
"city": "台安",
"district": "鞍山市",
"prov": "辽宁省",
"py": "taian"
},
{
"city": "岫岩",
"district": "鞍山市",
"prov": "辽宁省",
"py": "xiuyan"
},
{
"city": "海城",
"district": "鞍山市",
"prov": "辽宁省",
"py": "haicheng"
},
{
"city": "抚顺",
"district": "抚顺市",
"prov": "辽宁省",
"py": "fushun"
},
{
"city": "新抚区",
"district": "抚顺市",
"prov": "辽宁省",
"py": "xinfuqu"
},
{
"city": "东洲区",
"district": "抚顺市",
"prov": "辽宁省",
"py": "dongzhouqu"
},
{
"city": "望花区",
"district": "抚顺市",
"prov": "辽宁省",
"py": "wanghuaqu"
},
{
"city": "顺城区",
"district": "抚顺市",
"prov": "辽宁省",
"py": "shunchengqu"
},
{
"city": "抚顺县",
"district": "抚顺市",
"prov": "辽宁省",
"py": "fushunxian"
},
{
"city": "新宾",
"district": "抚顺市",
"prov": "辽宁省",
"py": "xinbin"
},
{
"city": "清原",
"district": "抚顺市",
"prov": "辽宁省",
"py": "qingyuan"
},
{
"city": "本溪",
"district": "本溪市",
"prov": "辽宁省",
"py": "benxi"
},
{
"city": "平山区",
"district": "本溪市",
"prov": "辽宁省",
"py": "pingshanqu"
},
{
"city": "溪湖",
"district": "本溪市",
"prov": "辽宁省",
"py": "xihu"
},
{
"city": "明山",
"district": "本溪市",
"prov": "辽宁省",
"py": "mingshan"
},
{
"city": "南芬",
"district": "本溪市",
"prov": "辽宁省",
"py": "nanfen"
},
{
"city": "本溪县",
"district": "本溪市",
"prov": "辽宁省",
"py": "benxixian"
},
{
"city": "桓仁",
"district": "本溪市",
"prov": "辽宁省",
"py": "huanren"
},
{
"city": "丹东",
"district": "丹东市",
"prov": "辽宁省",
"py": "dandong"
},
{
"city": "元宝",
"district": "丹东市",
"prov": "辽宁省",
"py": "yuanbao"
},
{
"city": "振兴",
"district": "丹东市",
"prov": "辽宁省",
"py": "zhenxing"
},
{
"city": "振安",
"district": "丹东市",
"prov": "辽宁省",
"py": "zhenan"
},
{
"city": "宽甸",
"district": "丹东市",
"prov": "辽宁省",
"py": "kuandian"
},
{
"city": "东港",
"district": "丹东市",
"prov": "辽宁省",
"py": "donggang"
},
{
"city": "凤城",
"district": "丹东市",
"prov": "辽宁省",
"py": "fengcheng"
},
{
"city": "锦州",
"district": "锦州市",
"prov": "辽宁省",
"py": "jinzhou"
},
{
"city": "古塔",
"district": "锦州市",
"prov": "辽宁省",
"py": "guta"
},
{
"city": "凌河",
"district": "锦州市",
"prov": "辽宁省",
"py": "linghe"
},
{
"city": "太和区",
"district": "锦州市",
"prov": "辽宁省",
"py": "taihequ"
},
{
"city": "黑山",
"district": "锦州市",
"prov": "辽宁省",
"py": "heishan"
},
{
"city": "义县",
"district": "锦州市",
"prov": "辽宁省",
"py": "yixian"
},
{
"city": "凌海",
"district": "锦州市",
"prov": "辽宁省",
"py": "linghai"
},
{
"city": "北镇",
"district": "锦州市",
"prov": "辽宁省",
"py": "beizhen"
},
{
"city": "营口",
"district": "营口市",
"prov": "辽宁省",
"py": "yingkou"
},
{
"city": "站前区",
"district": "营口市",
"prov": "辽宁省",
"py": "zhanqianqu"
},
{
"city": "西市区",
"district": "营口市",
"prov": "辽宁省",
"py": "xishiqu"
},
{
"city": "鲅鱼圈",
"district": "营口市",
"prov": "辽宁省",
"py": "bayuquan"
},
{
"city": "老边区",
"district": "营口市",
"prov": "辽宁省",
"py": "laobianqu"
},
{
"city": "盖州",
"district": "营口市",
"prov": "辽宁省",
"py": "gaizhou"
},
{
"city": "大石桥",
"district": "营口市",
"prov": "辽宁省",
"py": "dashiqiao"
},
{
"city": "阜新",
"district": "阜新市",
"prov": "辽宁省",
"py": "fuxin"
},
{
"city": "海州区",
"district": "阜新市",
"prov": "辽宁省",
"py": "haizhouqu"
},
{
"city": "新邱",
"district": "阜新市",
"prov": "辽宁省",
"py": "xinqiu"
},
{
"city": "太平",
"district": "阜新市",
"prov": "辽宁省",
"py": "taiping"
},
{
"city": "清河门",
"district": "阜新市",
"prov": "辽宁省",
"py": "qinghemen"
},
{
"city": "细河",
"district": "阜新市",
"prov": "辽宁省",
"py": "xihe"
},
{
"city": "阜新县",
"district": "阜新市",
"prov": "辽宁省",
"py": "fuxinxian"
},
{
"city": "彰武",
"district": "阜新市",
"prov": "辽宁省",
"py": "zhangwu"
},
{
"city": "辽阳",
"district": "辽阳市",
"prov": "辽宁省",
"py": "liaoyang"
},
{
"city": "白塔区",
"district": "辽阳市",
"prov": "辽宁省",
"py": "baitaqu"
},
{
"city": "文圣区",
"district": "辽阳市",
"prov": "辽宁省",
"py": "wenshengqu"
},
{
"city": "宏伟区",
"district": "辽阳市",
"prov": "辽宁省",
"py": "hongweiqu"
},
{
"city": "弓长岭",
"district": "辽阳市",
"prov": "辽宁省",
"py": "gongchangling"
},
{
"city": "太子河",
"district": "辽阳市",
"prov": "辽宁省",
"py": "taizihe"
},
{
"city": "辽阳县",
"district": "辽阳市",
"prov": "辽宁省",
"py": "liaoyangxian"
},
{
"city": "灯塔市",
"district": "辽阳市",
"prov": "辽宁省",
"py": "dengtashi"
},
{
"city": "盘锦",
"district": "盘锦市",
"prov": "辽宁省",
"py": "panjin"
},
{
"city": "双台子",
"district": "盘锦市",
"prov": "辽宁省",
"py": "shuangtaizi"
},
{
"city": "兴隆台",
"district": "盘锦市",
"prov": "辽宁省",
"py": "xinglongtai"
},
{
"city": "大洼",
"district": "盘锦市",
"prov": "辽宁省",
"py": "dawa"
},
{
"city": "盘山",
"district": "盘锦市",
"prov": "辽宁省",
"py": "panshan"
},
{
"city": "铁岭",
"district": "铁岭市",
"prov": "辽宁省",
"py": "tieling"
},
{
"city": "银州",
"district": "铁岭市",
"prov": "辽宁省",
"py": "yinzhou"
},
{
"city": "清河区",
"district": "铁岭市",
"prov": "辽宁省",
"py": "qinghequ"
},
{
"city": "铁岭县",
"district": "铁岭市",
"prov": "辽宁省",
"py": "tielingxian"
},
{
"city": "西丰",
"district": "铁岭市",
"prov": "辽宁省",
"py": "xifeng"
},
{
"city": "昌图",
"district": "铁岭市",
"prov": "辽宁省",
"py": "changtu"
},
{
"city": "调兵山",
"district": "铁岭市",
"prov": "辽宁省",
"py": "diaobingshan"
},
{
"city": "开原",
"district": "铁岭市",
"prov": "辽宁省",
"py": "kaiyuan"
},
{
"city": "朝阳",
"district": "朝阳市",
"prov": "辽宁省",
"py": "chaoyang"
},
{
"city": "双塔",
"district": "朝阳市",
"prov": "辽宁省",
"py": "shuangta"
},
{
"city": "龙城",
"district": "朝阳市",
"prov": "辽宁省",
"py": "longcheng"
},
{
"city": "朝阳县",
"district": "朝阳市",
"prov": "辽宁省",
"py": "chaoyangxian"
},
{
"city": "建平",
"district": "朝阳市",
"prov": "辽宁省",
"py": "jianping"
},
{
"city": "喀左",
"district": "朝阳市",
"prov": "辽宁省",
"py": "kazuo"
},
{
"city": "北票",
"district": "朝阳市",
"prov": "辽宁省",
"py": "beipiao"
},
{
"city": "凌源",
"district": "朝阳市",
"prov": "辽宁省",
"py": "lingyuan"
},
{
"city": "葫芦岛",
"district": "葫芦岛市",
"prov": "辽宁省",
"py": "huludao"
},
{
"city": "连山区",
"district": "葫芦岛市",
"prov": "辽宁省",
"py": "lianshanqu"
},
{
"city": "龙港",
"district": "葫芦岛市",
"prov": "辽宁省",
"py": "longgang"
},
{
"city": "南票",
"district": "葫芦岛市",
"prov": "辽宁省",
"py": "nanpiao"
},
{
"city": "绥中",
"district": "葫芦岛市",
"prov": "辽宁省",
"py": "suizhong"
},
{
"city": "建昌",
"district": "葫芦岛市",
"prov": "辽宁省",
"py": "jianchang"
},
{
"city": "兴城",
"district": "葫芦岛市",
"prov": "辽宁省",
"py": "xingcheng"
},
{
"city": "长春",
"district": "长春市",
"prov": "吉林省",
"py": "changchun"
},
{
"city": "南关",
"district": "长春市",
"prov": "吉林省",
"py": "nanguan"
},
{
"city": "宽城区",
"district": "长春市",
"prov": "吉林省",
"py": "kuanchengqu"
},
{
"city": "朝阳区",
"district": "长春市",
"prov": "吉林省",
"py": "chaoyangqu"
},
{
"city": "二道区",
"district": "长春市",
"prov": "吉林省",
"py": "erdaoqu"
},
{
"city": "绿园区",
"district": "长春市",
"prov": "吉林省",
"py": "lvyuanqu"
},
{
"city": "双阳",
"district": "长春市",
"prov": "吉林省",
"py": "shuangyang"
},
{
"city": "九台",
"district": "长春市",
"prov": "吉林省",
"py": "jiutai"
},
{
"city": "农安",
"district": "长春市",
"prov": "吉林省",
"py": "nongan"
},
{
"city": "榆树",
"district": "长春市",
"prov": "吉林省",
"py": "yushu"
},
{
"city": "德惠",
"district": "长春市",
"prov": "吉林省",
"py": "dehui"
},
{
"city": "吉林",
"district": "吉林市",
"prov": "吉林省",
"py": "jilin"
},
{
"city": "昌邑区",
"district": "吉林市",
"prov": "吉林省",
"py": "changyiqu"
},
{
"city": "龙潭",
"district": "吉林市",
"prov": "吉林省",
"py": "longtan"
},
{
"city": "船营",
"district": "吉林市",
"prov": "吉林省",
"py": "chuanying"
},
{
"city": "丰满",
"district": "吉林市",
"prov": "吉林省",
"py": "fengman"
},
{
"city": "永吉",
"district": "吉林市",
"prov": "吉林省",
"py": "yongji"
},
{
"city": "蛟河",
"district": "吉林市",
"prov": "吉林省",
"py": "jiaohe"
},
{
"city": "桦甸",
"district": "吉林市",
"prov": "吉林省",
"py": "huadian"
},
{
"city": "舒兰",
"district": "吉林市",
"prov": "吉林省",
"py": "shulan"
},
{
"city": "磐石",
"district": "吉林市",
"prov": "吉林省",
"py": "panshi"
},
{
"city": "四平",
"district": "四平市",
"prov": "吉林省",
"py": "siping"
},
{
"city": "铁西",
"district": "四平市",
"prov": "吉林省",
"py": "tiexi"
},
{
"city": "铁东",
"district": "四平市",
"prov": "吉林省",
"py": "tiedong"
},
{
"city": "梨树",
"district": "四平市",
"prov": "吉林省",
"py": "lishu"
},
{
"city": "伊通",
"district": "四平市",
"prov": "吉林省",
"py": "yitong"
},
{
"city": "公主岭",
"district": "四平市",
"prov": "吉林省",
"py": "gongzhuling"
},
{
"city": "双辽",
"district": "四平市",
"prov": "吉林省",
"py": "shuangliao"
},
{
"city": "辽源",
"district": "辽源市",
"prov": "吉林省",
"py": "liaoyuan"
},
{
"city": "龙山区",
"district": "辽源市",
"prov": "吉林省",
"py": "longshanqu"
},
{
"city": "西安区",
"district": "辽源市",
"prov": "吉林省",
"py": "xianqu"
},
{
"city": "东丰",
"district": "辽源市",
"prov": "吉林省",
"py": "dongfeng"
},
{
"city": "东辽",
"district": "辽源市",
"prov": "吉林省",
"py": "dongliao"
},
{
"city": "通化",
"district": "通化市",
"prov": "吉林省",
"py": "tonghua"
},
{
"city": "东昌区",
"district": "通化市",
"prov": "吉林省",
"py": "dongchangqu"
},
{
"city": "二道江",
"district": "通化市",
"prov": "吉林省",
"py": "erdaojiang"
},
{
"city": "通化县",
"district": "通化市",
"prov": "吉林省",
"py": "tonghuaxian"
},
{
"city": "辉南",
"district": "通化市",
"prov": "吉林省",
"py": "huinan"
},
{
"city": "柳河",
"district": "通化市",
"prov": "吉林省",
"py": "liuhe"
},
{
"city": "梅河口",
"district": "通化市",
"prov": "吉林省",
"py": "meihekou"
},
{
"city": "集安",
"district": "通化市",
"prov": "吉林省",
"py": "jian"
},
{
"city": "白山",
"district": "白山市",
"prov": "吉林省",
"py": "baishan"
},
{
"city": "浑江",
"district": "白山市",
"prov": "吉林省",
"py": "hunjiang"
},
{
"city": "江源",
"district": "白山市",
"prov": "吉林省",
"py": "jiangyuan"
},
{
"city": "抚松",
"district": "白山市",
"prov": "吉林省",
"py": "fusong"
},
{
"city": "靖宇",
"district": "白山市",
"prov": "吉林省",
"py": "jingyu"
},
{
"city": "长白",
"district": "白山市",
"prov": "吉林省",
"py": "changbai"
},
{
"city": "临江",
"district": "白山市",
"prov": "吉林省",
"py": "linjiang"
},
{
"city": "松原",
"district": "松原市",
"prov": "吉林省",
"py": "songyuan"
},
{
"city": "宁江",
"district": "松原市",
"prov": "吉林省",
"py": "ningjiang"
},
{
"city": "前郭",
"district": "松原市",
"prov": "吉林省",
"py": "qianguo"
},
{
"city": "长岭",
"district": "松原市",
"prov": "吉林省",
"py": "changling"
},
{
"city": "乾安",
"district": "松原市",
"prov": "吉林省",
"py": "qianan"
},
{
"city": "扶余",
"district": "松原市",
"prov": "吉林省",
"py": "fuyu"
},
{
"city": "白城",
"district": "白城市",
"prov": "吉林省",
"py": "baicheng"
},
{
"city": "洮北",
"district": "白城市",
"prov": "吉林省",
"py": "taobei"
},
{
"city": "镇赉",
"district": "白城市",
"prov": "吉林省",
"py": "zhenlai"
},
{
"city": "通榆",
"district": "白城市",
"prov": "吉林省",
"py": "tongyu"
},
{
"city": "洮南",
"district": "白城市",
"prov": "吉林省",
"py": "taonan"
},
{
"city": "大安",
"district": "白城市",
"prov": "吉林省",
"py": "daan"
},
{
"city": "延边",
"district": "延边朝鲜族自治州",
"prov": "吉林省",
"py": "yanbian"
},
{
"city": "延吉",
"district": "延边朝鲜族自治州",
"prov": "吉林省",
"py": "yanji"
},
{
"city": "图们",
"district": "延边朝鲜族自治州",
"prov": "吉林省",
"py": "tumen"
},
{
"city": "敦化",
"district": "延边朝鲜族自治州",
"prov": "吉林省",
"py": "dunhua"
},
{
"city": "珲春",
"district": "延边朝鲜族自治州",
"prov": "吉林省",
"py": "hunchun"
},
{
"city": "龙井",
"district": "延边朝鲜族自治州",
"prov": "吉林省",
"py": "longjing"
},
{
"city": "和龙",
"district": "延边朝鲜族自治州",
"prov": "吉林省",
"py": "helong"
},
{
"city": "汪清",
"district": "延边朝鲜族自治州",
"prov": "吉林省",
"py": "wangqing"
},
{
"city": "安图",
"district": "延边朝鲜族自治州",
"prov": "吉林省",
"py": "antu"
},
{
"city": "哈尔滨",
"district": "哈尔滨市",
"prov": "黑龙江省",
"py": "haerbin"
},
{
"city": "道里区",
"district": "哈尔滨市",
"prov": "黑龙江省",
"py": "daoliqu"
},
{
"city": "南岗区",
"district": "哈尔滨市",
"prov": "黑龙江省",
"py": "nangangqu"
},
{
"city": "道外区",
"district": "哈尔滨市",
"prov": "黑龙江省",
"py": "daowaiqu"
},
{
"city": "平房区",
"district": "哈尔滨市",
"prov": "黑龙江省",
"py": "pingfangqu"
},
{
"city": "松北区",
"district": "哈尔滨市",
"prov": "黑龙江省",
"py": "songbeiqu"
},
{
"city": "香坊区",
"district": "哈尔滨市",
"prov": "黑龙江省",
"py": "xiangfangqu"
},
{
"city": "呼兰",
"district": "哈尔滨市",
"prov": "黑龙江省",
"py": "hulan"
},
{
"city": "阿城",
"district": "哈尔滨市",
"prov": "黑龙江省",
"py": "acheng"
},
{
"city": "双城区",
"district": "哈尔滨市",
"prov": "黑龙江省",
"py": "shuangchengqu"
},
{
"city": "依兰",
"district": "哈尔滨市",
"prov": "黑龙江省",
"py": "yilan"
},
{
"city": "方正",
"district": "哈尔滨市",
"prov": "黑龙江省",
"py": "fangzheng"
},
{
"city": "宾县",
"district": "哈尔滨市",
"prov": "黑龙江省",
"py": "binxian"
},
{
"city": "巴彦",
"district": "哈尔滨市",
"prov": "黑龙江省",
"py": "bayan"
},
{
"city": "木兰",
"district": "哈尔滨市",
"prov": "黑龙江省",
"py": "mulan"
},
{
"city": "通河",
"district": "哈尔滨市",
"prov": "黑龙江省",
"py": "tonghe"
},
{
"city": "延寿",
"district": "哈尔滨市",
"prov": "黑龙江省",
"py": "yanshou"
},
{
"city": "尚志",
"district": "哈尔滨市",
"prov": "黑龙江省",
"py": "shangzhi"
},
{
"city": "五常",
"district": "哈尔滨市",
"prov": "黑龙江省",
"py": "wuchang"
},
{
"city": "齐齐哈尔",
"district": "齐齐哈尔市",
"prov": "黑龙江省",
"py": "qiqihaer"
},
{
"city": "龙沙",
"district": "齐齐哈尔市",
"prov": "黑龙江省",
"py": "longsha"
},
{
"city": "建华",
"district": "齐齐哈尔市",
"prov": "黑龙江省",
"py": "jianhua"
},
{
"city": "铁锋",
"district": "齐齐哈尔市",
"prov": "黑龙江省",
"py": "tiefeng"
},
{
"city": "昂昂溪",
"district": "齐齐哈尔市",
"prov": "黑龙江省",
"py": "angangxi"
},
{
"city": "富拉尔基",
"district": "齐齐哈尔市",
"prov": "黑龙江省",
"py": "fulaerji"
},
{
"city": "碾子山",
"district": "齐齐哈尔市",
"prov": "黑龙江省",
"py": "nianzishan"
},
{
"city": "梅里斯",
"district": "齐齐哈尔市",
"prov": "黑龙江省",
"py": "meilisi"
},
{
"city": "龙江",
"district": "齐齐哈尔市",
"prov": "黑龙江省",
"py": "longjiang"
},
{
"city": "依安",
"district": "齐齐哈尔市",
"prov": "黑龙江省",
"py": "yian"
},
{
"city": "泰来",
"district": "齐齐哈尔市",
"prov": "黑龙江省",
"py": "tailai"
},
{
"city": "甘南县",
"district": "齐齐哈尔市",
"prov": "黑龙江省",
"py": "gannanxian"
},
{
"city": "富裕",
"district": "齐齐哈尔市",
"prov": "黑龙江省",
"py": "fuyu"
},
{
"city": "克山",
"district": "齐齐哈尔市",
"prov": "黑龙江省",
"py": "keshan"
},
{
"city": "克东",
"district": "齐齐哈尔市",
"prov": "黑龙江省",
"py": "kedong"
},
{
"city": "拜泉",
"district": "齐齐哈尔市",
"prov": "黑龙江省",
"py": "baiquan"
},
{
"city": "讷河",
"district": "齐齐哈尔市",
"prov": "黑龙江省",
"py": "nehe"
},
{
"city": "鸡西",
"district": "鸡西市",
"prov": "黑龙江省",
"py": "jixi"
},
{
"city": "鸡冠区",
"district": "鸡西市",
"prov": "黑龙江省",
"py": "jiguanqu"
},
{
"city": "恒山区",
"district": "鸡西市",
"prov": "黑龙江省",
"py": "hengshanqu"
},
{
"city": "滴道区",
"district": "鸡西市",
"prov": "黑龙江省",
"py": "didaoqu"
},
{
"city": "梨树区",
"district": "鸡西市",
"prov": "黑龙江省",
"py": "lishuqu"
},
{
"city": "城子河",
"district": "鸡西市",
"prov": "黑龙江省",
"py": "chengzihe"
},
{
"city": "麻山",
"district": "鸡西市",
"prov": "黑龙江省",
"py": "mashan"
},
{
"city": "鸡东",
"district": "鸡西市",
"prov": "黑龙江省",
"py": "jidong"
},
{
"city": "虎林",
"district": "鸡西市",
"prov": "黑龙江省",
"py": "hulin"
},
{
"city": "密山",
"district": "鸡西市",
"prov": "黑龙江省",
"py": "mishan"
},
{
"city": "鹤岗",
"district": "鹤岗市",
"prov": "黑龙江省",
"py": "hegang"
},
{
"city": "向阳区",
"district": "鹤岗市",
"prov": "黑龙江省",
"py": "xiangyangqu"
},
{
"city": "工农区",
"district": "鹤岗市",
"prov": "黑龙江省",
"py": "gongnongqu"
},
{
"city": "南山区",
"district": "鹤岗市",
"prov": "黑龙江省",
"py": "nanshanqu"
},
{
"city": "兴安区",
"district": "鹤岗市",
"prov": "黑龙江省",
"py": "xinganqu"
},
{
"city": "东山区",
"district": "鹤岗市",
"prov": "黑龙江省",
"py": "donshanqu"
},
{
"city": "兴山区",
"district": "鹤岗市",
"prov": "黑龙江省",
"py": "xingshanqu"
},
{
"city": "萝北",
"district": "鹤岗市",
"prov": "黑龙江省",
"py": "luobei"
},
{
"city": "绥滨",
"district": "鹤岗市",
"prov": "黑龙江省",
"py": "suibin"
},
{
"city": "双鸭山",
"district": "双鸭山市",
"prov": "黑龙江省",
"py": "shuangyashan"
},
{
"city": "尖山区",
"district": "双鸭山市",
"prov": "黑龙江省",
"py": "jianshanqu"
},
{
"city": "岭东区",
"district": "双鸭山市",
"prov": "黑龙江省",
"py": "lingdongqu"
},
{
"city": "四方台",
"district": "双鸭山市",
"prov": "黑龙江省",
"py": "sifangtai"
},
{
"city": "宝山区",
"district": "双鸭山市",
"prov": "黑龙江省",
"py": "baoshanqu"
},
{
"city": "集贤",
"district": "双鸭山市",
"prov": "黑龙江省",
"py": "jixian"
},
{
"city": "友谊",
"district": "双鸭山市",
"prov": "黑龙江省",
"py": "youyi"
},
{
"city": "宝清",
"district": "双鸭山市",
"prov": "黑龙江省",
"py": "baoqing"
},
{
"city": "饶河",
"district": "双鸭山市",
"prov": "黑龙江省",
"py": "raohe"
},
{
"city": "大庆",
"district": "大庆市",
"prov": "黑龙江省",
"py": "daqing"
},
{
"city": "萨尔图",
"district": "大庆市",
"prov": "黑龙江省",
"py": "saertu"
},
{
"city": "龙凤区",
"district": "大庆市",
"prov": "黑龙江省",
"py": "longfengqu"
},
{
"city": "让胡路",
"district": "大庆市",
"prov": "黑龙江省",
"py": "ranghulu"
},
{
"city": "红岗区",
"district": "大庆市",
"prov": "黑龙江省",
"py": "honggangqu"
},
{
"city": "大同区",
"district": "大庆市",
"prov": "黑龙江省",
"py": "datongqu"
},
{
"city": "肇州",
"district": "大庆市",
"prov": "黑龙江省",
"py": "zhaozhou"
},
{
"city": "肇源",
"district": "大庆市",
"prov": "黑龙江省",
"py": "zhaoyuan"
},
{
"city": "林甸",
"district": "大庆市",
"prov": "黑龙江省",
"py": "lindian"
},
{
"city": "杜尔伯特",
"district": "大庆市",
"prov": "黑龙江省",
"py": "duerbote"
},
{
"city": "伊春",
"district": "伊春市",
"prov": "黑龙江省",
"py": "yichun"
},
{
"city": "伊美区",
"district": "伊春市",
"prov": "黑龙江省",
"py": "yimeiqu"
},
{
"city": "南岔县",
"district": "伊春市",
"prov": "黑龙江省",
"py": "nanchaxian"
},
{
"city": "友好区",
"district": "伊春市",
"prov": "黑龙江省",
"py": "youhaoqu"
},
{
"city": "西林区",
"district": "伊春市",
"prov": "黑龙江省",
"py": "xilinqu"
},
{
"city": "乌翠区",
"district": "伊春市",
"prov": "黑龙江省",
"py": "wucuiqu"
},
{
"city": "新青",
"district": "伊春市",
"prov": "黑龙江省",
"py": "xinqing"
},
{
"city": "美溪",
"district": "伊春市",
"prov": "黑龙江省",
"py": "meixi"
},
{
"city": "金林区",
"district": "伊春市",
"prov": "黑龙江省",
"py": "jinlinqu"
},
{
"city": "丰林县",
"district": "伊春市",
"prov": "黑龙江省",
"py": "fenglinxian"
},
{
"city": "乌马河",
"district": "伊春市",
"prov": "黑龙江省",
"py": "wumahe"
},
{
"city": "汤旺县",
"district": "伊春市",
"prov": "黑龙江省",
"py": "tangwangxian"
},
{
"city": "大箐山县",
"district": "伊春市",
"prov": "黑龙江省",
"py": "daqingshanxian"
},
{
"city": "乌伊岭",
"district": "伊春市",
"prov": "黑龙江省",
"py": "wuyiling"
},
{
"city": "红星区",
"district": "伊春市",
"prov": "黑龙江省",
"py": "hongxingqu"
},
{
"city": "上甘岭",
"district": "伊春市",
"prov": "黑龙江省",
"py": "shangganling"
},
{
"city": "嘉荫",
"district": "伊春市",
"prov": "黑龙江省",
"py": "jiayin"
},
{
"city": "铁力",
"district": "伊春市",
"prov": "黑龙江省",
"py": "tieli"
},
{
"city": "佳木斯",
"district": "佳木斯市",
"prov": "黑龙江省",
"py": "jiamusi"
},
{
"city": "向阳区",
"district": "佳木斯市",
"prov": "黑龙江省",
"py": "xiangyangqu"
},
{
"city": "前进区",
"district": "佳木斯市",
"prov": "黑龙江省",
"py": "qianjinqu"
},
{
"city": "东风区",
"district": "佳木斯市",
"prov": "黑龙江省",
"py": "dongfengqu"
},
{
"city": "郊区",
"district": "佳木斯市",
"prov": "黑龙江省",
"py": "jiaoqu"
},
{
"city": "桦南",
"district": "佳木斯市",
"prov": "黑龙江省",
"py": "huanan"
},
{
"city": "桦川",
"district": "佳木斯市",
"prov": "黑龙江省",
"py": "huachuan"
},
{
"city": "汤原",
"district": "佳木斯市",
"prov": "黑龙江省",
"py": "tangyuan"
},
{
"city": "同江",
"district": "佳木斯市",
"prov": "黑龙江省",
"py": "tongjiang"
},
{
"city": "富锦",
"district": "佳木斯市",
"prov": "黑龙江省",
"py": "fujin"
},
{
"city": "抚远",
"district": "佳木斯市",
"prov": "黑龙江省",
"py": "fuyuan"
},
{
"city": "七台河",
"district": "七台河市",
"prov": "黑龙江省",
"py": "qitaihe"
},
{
"city": "新兴区",
"district": "七台河市",
"prov": "黑龙江省",
"py": "xinxingqu"
},
{
"city": "桃山区",
"district": "七台河市",
"prov": "黑龙江省",
"py": "taoshanqu"
},
{
"city": "茄子河",
"district": "七台河市",
"prov": "黑龙江省",
"py": "qiezihe"
},
{
"city": "勃利",
"district": "七台河市",
"prov": "黑龙江省",
"py": "boli"
},
{
"city": "牡丹江",
"district": "牡丹江市",
"prov": "黑龙江省",
"py": "mudanjiang"
},
{
"city": "东安区",
"district": "牡丹江市",
"prov": "黑龙江省",
"py": "donganqu"
},
{
"city": "阳明",
"district": "牡丹江市",
"prov": "黑龙江省",
"py": "yangming"
},
{
"city": "爱民",
"district": "牡丹江市",
"prov": "黑龙江省",
"py": "aimin"
},
{
"city": "西安区",
"district": "牡丹江市",
"prov": "黑龙江省",
"py": "xianqu"
},
{
"city": "林口",
"district": "牡丹江市",
"prov": "黑龙江省",
"py": "linkou"
},
{
"city": "绥芬河",
"district": "牡丹江市",
"prov": "黑龙江省",
"py": "suifenhe"
},
{
"city": "海林",
"district": "牡丹江市",
"prov": "黑龙江省",
"py": "hailin"
},
{
"city": "宁安",
"district": "牡丹江市",
"prov": "黑龙江省",
"py": "ningan"
},
{
"city": "穆棱",
"district": "牡丹江市",
"prov": "黑龙江省",
"py": "muling"
},
{
"city": "东宁",
"district": "牡丹江市",
"prov": "黑龙江省",
"py": "dongning"
},
{
"city": "黑河",
"district": "黑河市",
"prov": "黑龙江省",
"py": "heihe"
},
{
"city": "爱辉",
"district": "黑河市",
"prov": "黑龙江省",
"py": "aihui"
},
{
"city": "嫩江",
"district": "黑河市",
"prov": "黑龙江省",
"py": "nenjiang"
},
{
"city": "逊克",
"district": "黑河市",
"prov": "黑龙江省",
"py": "xunke"
},
{
"city": "孙吴",
"district": "黑河市",
"prov": "黑龙江省",
"py": "sunwu"
},
{
"city": "北安",
"district": "黑河市",
"prov": "黑龙江省",
"py": "beian"
},
{
"city": "五大连池",
"district": "黑河市",
"prov": "黑龙江省",
"py": "wudalianchi"
},
{
"city": "绥化",
"district": "绥化市",
"prov": "黑龙江省",
"py": "suihua"
},
{
"city": "北林",
"district": "绥化市",
"prov": "黑龙江省",
"py": "beilin"
},
{
"city": "望奎",
"district": "绥化市",
"prov": "黑龙江省",
"py": "wangkui"
},
{
"city": "兰西",
"district": "绥化市",
"prov": "黑龙江省",
"py": "lanxi"
},
{
"city": "青冈",
"district": "绥化市",
"prov": "黑龙江省",
"py": "qinggang"
},
{
"city": "庆安",
"district": "绥化市",
"prov": "黑龙江省",
"py": "qingan"
},
{
"city": "明水",
"district": "绥化市",
"prov": "黑龙江省",
"py": "mingshui"
},
{
"city": "绥棱",
"district": "绥化市",
"prov": "黑龙江省",
"py": "suiling"
},
{
"city": "安达",
"district": "绥化市",
"prov": "黑龙江省",
"py": "anda"
},
{
"city": "肇东",
"district": "绥化市",
"prov": "黑龙江省",
"py": "zhaodong"
},
{
"city": "海伦",
"district": "绥化市",
"prov": "黑龙江省",
"py": "hailun"
},
{
"city": "大兴安岭",
"district": "大兴安岭地区",
"prov": "黑龙江省",
"py": "daxinganling"
},
{
"city": "漠河",
"district": "大兴安岭地区",
"prov": "黑龙江省",
"py": "mohe"
},
{
"city": "呼玛",
"district": "大兴安岭地区",
"prov": "黑龙江省",
"py": "huma"
},
{
"city": "塔河",
"district": "大兴安岭地区",
"prov": "黑龙江省",
"py": "tahe"
},
{
"city": "大兴安岭地区直辖",
"district": "大兴安岭地区",
"prov": "黑龙江省",
"py": "daxinganlingdiquzhixia"
},
{
"city": "加格达奇",
"district": "大兴安岭地区",
"prov": "黑龙江省",
"py": "jiagedaqi"
},
{
"city": "上海",
"district": "上海市",
"prov": "上海市",
"py": "shanghai"
},
{
"city": "黄浦",
"district": "上海市",
"prov": "上海市",
"py": "huangpu"
},
{
"city": "徐汇",
"district": "上海市",
"prov": "上海市",
"py": "xuhui"
},
{
"city": "长宁区",
"district": "上海市",
"prov": "上海市",
"py": "changningqu"
},
{
"city": "静安",
"district": "上海市",
"prov": "上海市",
"py": "jingan"
},
{
"city": "普陀区",
"district": "上海市",
"prov": "上海市",
"py": "putuoqu"
},
{
"city": "虹口",
"district": "上海市",
"prov": "上海市",
"py": "hongkou"
},
{
"city": "杨浦",
"district": "上海市",
"prov": "上海市",
"py": "yangpu"
},
{
"city": "闵行",
"district": "上海市",
"prov": "上海市",
"py": "minhang"
},
{
"city": "宝山",
"district": "上海市",
"prov": "上海市",
"py": "baoshan"
},
{
"city": "嘉定",
"district": "上海市",
"prov": "上海市",
"py": "jiading"
},
{
"city": "浦东新区",
"district": "上海市",
"prov": "上海市",
"py": "pudongxinqu"
},
{
"city": "金山",
"district": "上海市",
"prov": "上海市",
"py": "jinshan"
},
{
"city": "松江",
"district": "上海市",
"prov": "上海市",
"py": "songjiang"
},
{
"city": "青浦",
"district": "上海市",
"prov": "上海市",
"py": "qingpu"
},
{
"city": "奉贤",
"district": "上海市",
"prov": "上海市",
"py": "fengxian"
},
{
"city": "崇明",
"district": "上海市",
"prov": "上海市",
"py": "chongming"
},
{
"city": "南京",
"district": "南京市",
"prov": "江苏省",
"py": "nanjing"
},
{
"city": "玄武",
"district": "南京市",
"prov": "江苏省",
"py": "xuanwu"
},
{
"city": "秦淮",
"district": "南京市",
"prov": "江苏省",
"py": "qinhuai"
},
{
"city": "建邺",
"district": "南京市",
"prov": "江苏省",
"py": "jianye"
},
{
"city": "鼓楼",
"district": "南京市",
"prov": "江苏省",
"py": "gulou"
},
{
"city": "浦口",
"district": "南京市",
"prov": "江苏省",
"py": "pukou"
},
{
"city": "栖霞区",
"district": "南京市",
"prov": "江苏省",
"py": "qixiaqu"
},
{
"city": "雨花台",
"district": "南京市",
"prov": "江苏省",
"py": "yuhuatai"
},
{
"city": "江宁",
"district": "南京市",
"prov": "江苏省",
"py": "jiangning"
},
{
"city": "六合",
"district": "南京市",
"prov": "江苏省",
"py": "luhe"
},
{
"city": "溧水",
"district": "南京市",
"prov": "江苏省",
"py": "lishui"
},
{
"city": "高淳",
"district": "南京市",
"prov": "江苏省",
"py": "gaochun"
},
{
"city": "无锡",
"district": "无锡市",
"prov": "江苏省",
"py": "wuxi"
},
{
"city": "锡山",
"district": "无锡市",
"prov": "江苏省",
"py": "xishan"
},
{
"city": "惠山",
"district": "无锡市",
"prov": "江苏省",
"py": "huishan"
},
{
"city": "滨湖",
"district": "无锡市",
"prov": "江苏省",
"py": "binhu"
},
{
"city": "梁溪",
"district": "无锡市",
"prov": "江苏省",
"py": "liangxi"
},
{
"city": "新吴",
"district": "无锡市",
"prov": "江苏省",
"py": "xinwu"
},
{
"city": "江阴",
"district": "无锡市",
"prov": "江苏省",
"py": "jiangyin"
},
{
"city": "宜兴",
"district": "无锡市",
"prov": "江苏省",
"py": "yixing"
},
{
"city": "徐州",
"district": "徐州市",
"prov": "江苏省",
"py": "xuzhou"
},
{
"city": "鼓楼区",
"district": "徐州市",
"prov": "江苏省",
"py": "gulouqu"
},
{
"city": "云龙区",
"district": "徐州市",
"prov": "江苏省",
"py": "yunlongqu"
},
{
"city": "贾汪",
"district": "徐州市",
"prov": "江苏省",
"py": "jiawang"
},
{
"city": "泉山",
"district": "徐州市",
"prov": "江苏省",
"py": "quanshan"
},
{
"city": "铜山",
"district": "徐州市",
"prov": "江苏省",
"py": "tongshan"
},
{
"city": "丰县",
"district": "徐州市",
"prov": "江苏省",
"py": "fengxian"
},
{
"city": "沛县",
"district": "徐州市",
"prov": "江苏省",
"py": "peixian"
},
{
"city": "睢宁",
"district": "徐州市",
"prov": "江苏省",
"py": "suining"
},
{
"city": "新沂",
"district": "徐州市",
"prov": "江苏省",
"py": "xinyi"
},
{
"city": "邳州",
"district": "徐州市",
"prov": "江苏省",
"py": "pizhou"
},
{
"city": "常州",
"district": "常州市",
"prov": "江苏省",
"py": "changzhou"
},
{
"city": "天宁",
"district": "常州市",
"prov": "江苏省",
"py": "tianning"
},
{
"city": "钟楼",
"district": "常州市",
"prov": "江苏省",
"py": "zhonglou"
},
{
"city": "新北区",
"district": "常州市",
"prov": "江苏省",
"py": "xinbeiqu"
},
{
"city": "武进",
"district": "常州市",
"prov": "江苏省",
"py": "wujin"
},
{
"city": "金坛",
"district": "常州市",
"prov": "江苏省",
"py": "jintan"
},
{
"city": "溧阳",
"district": "常州市",
"prov": "江苏省",
"py": "liyang"
},
{
"city": "苏州",
"district": "苏州市",
"prov": "江苏省",
"py": "suzhou"
},
{
"city": "虎丘",
"district": "苏州市",
"prov": "江苏省",
"py": "huqiu"
},
{
"city": "吴中",
"district": "苏州市",
"prov": "江苏省",
"py": "wuzhong"
},
{
"city": "相城",
"district": "苏州市",
"prov": "江苏省",
"py": "xiangcheng"
},
{
"city": "姑苏",
"district": "苏州市",
"prov": "江苏省",
"py": "gusu"
},
{
"city": "吴江",
"district": "苏州市",
"prov": "江苏省",
"py": "wujiang"
},
{
"city": "苏州工业园区",
"district": "苏州市",
"prov": "江苏省",
"py": "suzhougongyeyuanqu"
},
{
"city": "常熟",
"district": "苏州市",
"prov": "江苏省",
"py": "changshu"
},
{
"city": "张家港",
"district": "苏州市",
"prov": "江苏省",
"py": "zhangjiagang"
},
{
"city": "昆山",
"district": "苏州市",
"prov": "江苏省",
"py": "kunshan"
},
{
"city": "太仓",
"district": "苏州市",
"prov": "江苏省",
"py": "taicang"
},
{
"city": "南通",
"district": "南通市",
"prov": "江苏省",
"py": "nantong"
},
{
"city": "崇川",
"district": "南通市",
"prov": "江苏省",
"py": "chongchuan"
},
{
"city": "港闸",
"district": "南通市",
"prov": "江苏省",
"py": "gangzha"
},
{
"city": "通州区",
"district": "南通市",
"prov": "江苏省",
"py": "tongzhouqu"
},
{
"city": "如东",
"district": "南通市",
"prov": "江苏省",
"py": "rudong"
},
{
"city": "启东",
"district": "南通市",
"prov": "江苏省",
"py": "qidong"
},
{
"city": "如皋",
"district": "南通市",
"prov": "江苏省",
"py": "rugao"
},
{
"city": "海门",
"district": "南通市",
"prov": "江苏省",
"py": "haimen"
},
{
"city": "海安",
"district": "南通市",
"prov": "江苏省",
"py": "haian"
},
{
"city": "连云港",
"district": "连云港市",
"prov": "江苏省",
"py": "lianyungang"
},
{
"city": "连云",
"district": "连云港市",
"prov": "江苏省",
"py": "lianyun"
},
{
"city": "海州",
"district": "连云港市",
"prov": "江苏省",
"py": "haizhou"
},
{
"city": "赣榆",
"district": "连云港市",
"prov": "江苏省",
"py": "ganyu"
},
{
"city": "东海",
"district": "连云港市",
"prov": "江苏省",
"py": "donghai"
},
{
"city": "灌云",
"district": "连云港市",
"prov": "江苏省",
"py": "guanyun"
},
{
"city": "灌南",
"district": "连云港市",
"prov": "江苏省",
"py": "guannan"
},
{
"city": "淮安",
"district": "淮安市",
"prov": "江苏省",
"py": "huaian"
},
{
"city": "淮安区",
"district": "淮安市",
"prov": "江苏省",
"py": "huaianqu"
},
{
"city": "淮阴",
"district": "淮安市",
"prov": "江苏省",
"py": "huaiyin"
},
{
"city": "清江浦",
"district": "淮安市",
"prov": "江苏省",
"py": "qingjiangpu"
},
{
"city": "洪泽",
"district": "淮安市",
"prov": "江苏省",
"py": "hongze"
},
{
"city": "涟水",
"district": "淮安市",
"prov": "江苏省",
"py": "lianshui"
},
{
"city": "盱眙",
"district": "淮安市",
"prov": "江苏省",
"py": "xuyi"
},
{
"city": "金湖",
"district": "淮安市",
"prov": "江苏省",
"py": "jinhu"
},
{
"city": "盐城",
"district": "盐城市",
"prov": "江苏省",
"py": "yancheng"
},
{
"city": "亭湖",
"district": "盐城市",
"prov": "江苏省",
"py": "tinghu"
},
{
"city": "盐都",
"district": "盐城市",
"prov": "江苏省",
"py": "yandu"
},
{
"city": "大丰",
"district": "盐城市",
"prov": "江苏省",
"py": "dafeng"
},
{
"city": "响水",
"district": "盐城市",
"prov": "江苏省",
"py": "xiangshui"
},
{
"city": "滨海",
"district": "盐城市",
"prov": "江苏省",
"py": "binhai"
},
{
"city": "阜宁",
"district": "盐城市",
"prov": "江苏省",
"py": "funing"
},
{
"city": "射阳",
"district": "盐城市",
"prov": "江苏省",
"py": "sheyang"
},
{
"city": "建湖",
"district": "盐城市",
"prov": "江苏省",
"py": "jianhu"
},
{
"city": "东台",
"district": "盐城市",
"prov": "江苏省",
"py": "dongtai"
},
{
"city": "扬州",
"district": "扬州市",
"prov": "江苏省",
"py": "yangzhou"
},
{
"city": "广陵",
"district": "扬州市",
"prov": "江苏省",
"py": "guangling"
},
{
"city": "邗江",
"district": "扬州市",
"prov": "江苏省",
"py": "hanjiang"
},
{
"city": "江都",
"district": "扬州市",
"prov": "江苏省",
"py": "jiangdu"
},
{
"city": "宝应",
"district": "扬州市",
"prov": "江苏省",
"py": "baoying"
},
{
"city": "仪征",
"district": "扬州市",
"prov": "江苏省",
"py": "yizheng"
},
{
"city": "高邮",
"district": "扬州市",
"prov": "江苏省",
"py": "gaoyou"
},
{
"city": "镇江",
"district": "镇江市",
"prov": "江苏省",
"py": "zhenjiang"
},
{
"city": "京口",
"district": "镇江市",
"prov": "江苏省",
"py": "jingkou"
},
{
"city": "润州",
"district": "镇江市",
"prov": "江苏省",
"py": "runzhou"
},
{
"city": "丹徒",
"district": "镇江市",
"prov": "江苏省",
"py": "dantu"
},
{
"city": "丹阳",
"district": "镇江市",
"prov": "江苏省",
"py": "danyang"
},
{
"city": "扬中",
"district": "镇江市",
"prov": "江苏省",
"py": "yangzhong"
},
{
"city": "句容",
"district": "镇江市",
"prov": "江苏省",
"py": "jurong"
},
{
"city": "泰州",
"district": "泰州市",
"prov": "江苏省",
"py": "taizhou"
},
{
"city": "海陵",
"district": "泰州市",
"prov": "江苏省",
"py": "hailing"
},
{
"city": "高港",
"district": "泰州市",
"prov": "江苏省",
"py": "gaogang"
},
{
"city": "姜堰",
"district": "泰州市",
"prov": "江苏省",
"py": "jiangyan"
},
{
"city": "兴化",
"district": "泰州市",
"prov": "江苏省",
"py": "xinghua"
},
{
"city": "靖江",
"district": "泰州市",
"prov": "江苏省",
"py": "jingjiang"
},
{
"city": "泰兴",
"district": "泰州市",
"prov": "江苏省",
"py": "taixing"
},
{
"city": "宿迁",
"district": "宿迁市",
"prov": "江苏省",
"py": "suqian"
},
{
"city": "宿城",
"district": "宿迁市",
"prov": "江苏省",
"py": "sucheng"
},
{
"city": "宿豫",
"district": "宿迁市",
"prov": "江苏省",
"py": "suyu"
},
{
"city": "沭阳",
"district": "宿迁市",
"prov": "江苏省",
"py": "shuyang"
},
{
"city": "泗阳",
"district": "宿迁市",
"prov": "江苏省",
"py": "siyang"
},
{
"city": "泗洪",
"district": "宿迁市",
"prov": "江苏省",
"py": "sihong"
},
{
"city": "杭州",
"district": "杭州市",
"prov": "浙江省",
"py": "hangzhou"
},
{
"city": "上城区",
"district": "杭州市",
"prov": "浙江省",
"py": "shangchengqu"
},
{
"city": "下城区",
"district": "杭州市",
"prov": "浙江省",
"py": "xiachengqu"
},
{
"city": "江干",
"district": "杭州市",
"prov": "浙江省",
"py": "jianggan"
},
{
"city": "拱墅",
"district": "杭州市",
"prov": "浙江省",
"py": "gongshu"
},
{
"city": "西湖",
"district": "杭州市",
"prov": "浙江省",
"py": "xihu"
},
{
"city": "滨江",
"district": "杭州市",
"prov": "浙江省",
"py": "binjiang"
},
{
"city": "萧山",
"district": "杭州市",
"prov": "浙江省",
"py": "xiaoshan"
},
{
"city": "余杭",
"district": "杭州市",
"prov": "浙江省",
"py": "yuhang"
},
{
"city": "富阳",
"district": "杭州市",
"prov": "浙江省",
"py": "fuyang"
},
{
"city": "临安",
"district": "杭州市",
"prov": "浙江省",
"py": "linan"
},
{
"city": "桐庐",
"district": "杭州市",
"prov": "浙江省",
"py": "tonglu"
},
{
"city": "淳安",
"district": "杭州市",
"prov": "浙江省",
"py": "chunan"
},
{
"city": "建德",
"district": "杭州市",
"prov": "浙江省",
"py": "jiande"
},
{
"city": "宁波",
"district": "宁波市",
"prov": "浙江省",
"py": "ningbo"
},
{
"city": "海曙",
"district": "宁波市",
"prov": "浙江省",
"py": "haishu"
},
{
"city": "江北区",
"district": "宁波市",
"prov": "浙江省",
"py": "jiangbeiqu"
},
{
"city": "北仑",
"district": "宁波市",
"prov": "浙江省",
"py": "beilun"
},
{
"city": "镇海",
"district": "宁波市",
"prov": "浙江省",
"py": "zhenhai"
},
{
"city": "鄞州",
"district": "宁波市",
"prov": "浙江省",
"py": "yinzhou"
},
{
"city": "奉化",
"district": "宁波市",
"prov": "浙江省",
"py": "fenghua"
},
{
"city": "象山",
"district": "宁波市",
"prov": "浙江省",
"py": "xiangshan"
},
{
"city": "宁海",
"district": "宁波市",
"prov": "浙江省",
"py": "ninghai"
},
{
"city": "余姚",
"district": "宁波市",
"prov": "浙江省",
"py": "yuyao"
},
{
"city": "慈溪",
"district": "宁波市",
"prov": "浙江省",
"py": "cixi"
},
{
"city": "温州",
"district": "温州市",
"prov": "浙江省",
"py": "wenzhou"
},
{
"city": "鹿城",
"district": "温州市",
"prov": "浙江省",
"py": "lucheng"
},
{
"city": "龙湾",
"district": "温州市",
"prov": "浙江省",
"py": "longwan"
},
{
"city": "瓯海",
"district": "温州市",
"prov": "浙江省",
"py": "ouhai"
},
{
"city": "洞头",
"district": "温州市",
"prov": "浙江省",
"py": "dongtou"
},
{
"city": "永嘉",
"district": "温州市",
"prov": "浙江省",
"py": "yongjia"
},
{
"city": "平阳",
"district": "温州市",
"prov": "浙江省",
"py": "pingyang"
},
{
"city": "苍南",
"district": "温州市",
"prov": "浙江省",
"py": "cangnan"
},
{
"city": "文成",
"district": "温州市",
"prov": "浙江省",
"py": "wencheng"
},
{
"city": "泰顺",
"district": "温州市",
"prov": "浙江省",
"py": "taishun"
},
{
"city": "瑞安",
"district": "温州市",
"prov": "浙江省",
"py": "ruian"
},
{
"city": "乐清",
"district": "温州市",
"prov": "浙江省",
"py": "yueqing"
},
{
"city": "龙港市",
"district": "温州市",
"prov": "浙江省",
"py": "longgangshi"
},
{
"city": "嘉兴",
"district": "嘉兴市",
"prov": "浙江省",
"py": "jiaxing"
},
{
"city": "南湖",
"district": "嘉兴市",
"prov": "浙江省",
"py": "nanhu"
},
{
"city": "秀洲",
"district": "嘉兴市",
"prov": "浙江省",
"py": "xiuzhou"
},
{
"city": "嘉善",
"district": "嘉兴市",
"prov": "浙江省",
"py": "jiashan"
},
{
"city": "海盐",
"district": "嘉兴市",
"prov": "浙江省",
"py": "haiyan"
},
{
"city": "海宁",
"district": "嘉兴市",
"prov": "浙江省",
"py": "haining"
},
{
"city": "平湖",
"district": "嘉兴市",
"prov": "浙江省",
"py": "pinghu"
},
{
"city": "桐乡",
"district": "嘉兴市",
"prov": "浙江省",
"py": "tongxiang"
},
{
"city": "湖州",
"district": "湖州市",
"prov": "浙江省",
"py": "huzhou"
},
{
"city": "吴兴",
"district": "湖州市",
"prov": "浙江省",
"py": "wuxing"
},
{
"city": "南浔",
"district": "湖州市",
"prov": "浙江省",
"py": "nanxun"
},
{
"city": "德清",
"district": "湖州市",
"prov": "浙江省",
"py": "deqing"
},
{
"city": "长兴",
"district": "湖州市",
"prov": "浙江省",
"py": "changxing"
},
{
"city": "安吉",
"district": "湖州市",
"prov": "浙江省",
"py": "anji"
},
{
"city": "绍兴",
"district": "绍兴市",
"prov": "浙江省",
"py": "shaoxing"
},
{
"city": "越城",
"district": "绍兴市",
"prov": "浙江省",
"py": "yuecheng"
},
{
"city": "柯桥",
"district": "绍兴市",
"prov": "浙江省",
"py": "keqiao"
},
{
"city": "上虞",
"district": "绍兴市",
"prov": "浙江省",
"py": "shangyu"
},
{
"city": "新昌",
"district": "绍兴市",
"prov": "浙江省",
"py": "xinchang"
},
{
"city": "诸暨",
"district": "绍兴市",
"prov": "浙江省",
"py": "zhuji"
},
{
"city": "嵊州",
"district": "绍兴市",
"prov": "浙江省",
"py": "shengzhou"
},
{
"city": "金华",
"district": "金华市",
"prov": "浙江省",
"py": "jinhua"
},
{
"city": "婺城",
"district": "金华市",
"prov": "浙江省",
"py": "wucheng"
},
{
"city": "金东",
"district": "金华市",
"prov": "浙江省",
"py": "jindong"
},
{
"city": "武义",
"district": "金华市",
"prov": "浙江省",
"py": "wuyi"
},
{
"city": "浦江",
"district": "金华市",
"prov": "浙江省",
"py": "pujiang"
},
{
"city": "磐安",
"district": "金华市",
"prov": "浙江省",
"py": "panan"
},
{
"city": "兰溪",
"district": "金华市",
"prov": "浙江省",
"py": "lanxi"
},
{
"city": "义乌",
"district": "金华市",
"prov": "浙江省",
"py": "yiwu"
},
{
"city": "东阳",
"district": "金华市",
"prov": "浙江省",
"py": "dongyang"
},
{
"city": "永康",
"district": "金华市",
"prov": "浙江省",
"py": "yongkang"
},
{
"city": "衢州",
"district": "衢州市",
"prov": "浙江省",
"py": "quzhou"
},
{
"city": "柯城",
"district": "衢州市",
"prov": "浙江省",
"py": "kecheng"
},
{
"city": "衢江",
"district": "衢州市",
"prov": "浙江省",
"py": "qujiang"
},
{
"city": "常山",
"district": "衢州市",
"prov": "浙江省",
"py": "changshan"
},
{
"city": "开化",
"district": "衢州市",
"prov": "浙江省",
"py": "kaihua"
},
{
"city": "龙游",
"district": "衢州市",
"prov": "浙江省",
"py": "longyou"
},
{
"city": "江山",
"district": "衢州市",
"prov": "浙江省",
"py": "jiangshan"
},
{
"city": "舟山",
"district": "舟山市",
"prov": "浙江省",
"py": "zhoushan"
},
{
"city": "定海",
"district": "舟山市",
"prov": "浙江省",
"py": "dinghai"
},
{
"city": "普陀",
"district": "舟山市",
"prov": "浙江省",
"py": "putuo"
},
{
"city": "岱山",
"district": "舟山市",
"prov": "浙江省",
"py": "daishan"
},
{
"city": "嵊泗",
"district": "舟山市",
"prov": "浙江省",
"py": "shengsi"
},
{
"city": "台州",
"district": "台州市",
"prov": "浙江省",
"py": "taizhou"
},
{
"city": "椒江",
"district": "台州市",
"prov": "浙江省",
"py": "jiaojiang"
},
{
"city": "黄岩",
"district": "台州市",
"prov": "浙江省",
"py": "huangyan"
},
{
"city": "路桥",
"district": "台州市",
"prov": "浙江省",
"py": "luqiao"
},
{
"city": "三门",
"district": "台州市",
"prov": "浙江省",
"py": "sanmen"
},
{
"city": "天台",
"district": "台州市",
"prov": "浙江省",
"py": "tiantai"
},
{
"city": "仙居",
"district": "台州市",
"prov": "浙江省",
"py": "xianju"
},
{
"city": "温岭",
"district": "台州市",
"prov": "浙江省",
"py": "wenling"
},
{
"city": "临海",
"district": "台州市",
"prov": "浙江省",
"py": "linhai"
},
{
"city": "玉环",
"district": "台州市",
"prov": "浙江省",
"py": "yuhuan"
},
{
"city": "丽水",
"district": "丽水市",
"prov": "浙江省",
"py": "lishui"
},
{
"city": "莲都",
"district": "丽水市",
"prov": "浙江省",
"py": "liandu"
},
{
"city": "青田",
"district": "丽水市",
"prov": "浙江省",
"py": "qingtian"
},
{
"city": "缙云",
"district": "丽水市",
"prov": "浙江省",
"py": "jinyun"
},
{
"city": "遂昌",
"district": "丽水市",
"prov": "浙江省",
"py": "suichang"
},
{
"city": "松阳",
"district": "丽水市",
"prov": "浙江省",
"py": "songyang"
},
{
"city": "云和",
"district": "丽水市",
"prov": "浙江省",
"py": "yunhe"
},
{
"city": "庆元",
"district": "丽水市",
"prov": "浙江省",
"py": "qingyuan"
},
{
"city": "景宁",
"district": "丽水市",
"prov": "浙江省",
"py": "jingning"
},
{
"city": "龙泉",
"district": "丽水市",
"prov": "浙江省",
"py": "longquan"
},
{
"city": "合肥",
"district": "合肥市",
"prov": "安徽省",
"py": "hefei"
},
{
"city": "瑶海",
"district": "合肥市",
"prov": "安徽省",
"py": "yaohai"
},
{
"city": "庐阳",
"district": "合肥市",
"prov": "安徽省",
"py": "luyang"
},
{
"city": "蜀山",
"district": "合肥市",
"prov": "安徽省",
"py": "shushan"
},
{
"city": "包河",
"district": "合肥市",
"prov": "安徽省",
"py": "baohe"
},
{
"city": "长丰",
"district": "合肥市",
"prov": "安徽省",
"py": "changfeng"
},
{
"city": "肥东",
"district": "合肥市",
"prov": "安徽省",
"py": "feidong"
},
{
"city": "肥西",
"district": "合肥市",
"prov": "安徽省",
"py": "feixi"
},
{
"city": "庐江",
"district": "合肥市",
"prov": "安徽省",
"py": "lujiang"
},
{
"city": "巢湖",
"district": "合肥市",
"prov": "安徽省",
"py": "chaohu"
},
{
"city": "芜湖",
"district": "芜湖市",
"prov": "安徽省",
"py": "wuhu"
},
{
"city": "镜湖",
"district": "芜湖市",
"prov": "安徽省",
"py": "jinghu"
},
{
"city": "弋江",
"district": "芜湖市",
"prov": "安徽省",
"py": "yijiang"
},
{
"city": "鸠江",
"district": "芜湖市",
"prov": "安徽省",
"py": "jiujiang"
},
{
"city": "三山",
"district": "芜湖市",
"prov": "安徽省",
"py": "sanshan"
},
{
"city": "芜湖县",
"district": "芜湖市",
"prov": "安徽省",
"py": "wuhuxian"
},
{
"city": "繁昌",
"district": "芜湖市",
"prov": "安徽省",
"py": "fanchang"
},
{
"city": "南陵",
"district": "芜湖市",
"prov": "安徽省",
"py": "nanling"
},
{
"city": "无为",
"district": "芜湖市",
"prov": "安徽省",
"py": "wuwei"
},
{
"city": "蚌埠",
"district": "蚌埠市",
"prov": "安徽省",
"py": "bengbu"
},
{
"city": "龙子湖",
"district": "蚌埠市",
"prov": "安徽省",
"py": "longzihu"
},
{
"city": "蚌山",
"district": "蚌埠市",
"prov": "安徽省",
"py": "bengshan"
},
{
"city": "禹会",
"district": "蚌埠市",
"prov": "安徽省",
"py": "yuhui"
},
{
"city": "淮上",
"district": "蚌埠市",
"prov": "安徽省",
"py": "huaishang"
},
{
"city": "怀远",
"district": "蚌埠市",
"prov": "安徽省",
"py": "huaiyuan"
},
{
"city": "五河",
"district": "蚌埠市",
"prov": "安徽省",
"py": "wuhe"
},
{
"city": "固镇",
"district": "蚌埠市",
"prov": "安徽省",
"py": "guzhen"
},
{
"city": "淮南",
"district": "淮南市",
"prov": "安徽省",
"py": "huainan"
},
{
"city": "大通区",
"district": "淮南市",
"prov": "安徽省",
"py": "datongqu"
},
{
"city": "田家庵",
"district": "淮南市",
"prov": "安徽省",
"py": "tianjiaan"
},
{
"city": "谢家集",
"district": "淮南市",
"prov": "安徽省",
"py": "xiejiaji"
},
{
"city": "八公山",
"district": "淮南市",
"prov": "安徽省",
"py": "bagongshan"
},
{
"city": "潘集",
"district": "淮南市",
"prov": "安徽省",
"py": "panji"
},
{
"city": "凤台",
"district": "淮南市",
"prov": "安徽省",
"py": "fengtai"
},
{
"city": "寿县",
"district": "淮南市",
"prov": "安徽省",
"py": "shouxian"
},
{
"city": "马鞍山",
"district": "马鞍山市",
"prov": "安徽省",
"py": "maanshan"
},
{
"city": "花山",
"district": "马鞍山市",
"prov": "安徽省",
"py": "huashan"
},
{
"city": "雨山",
"district": "马鞍山市",
"prov": "安徽省",
"py": "yushan"
},
{
"city": "博望",
"district": "马鞍山市",
"prov": "安徽省",
"py": "bowang"
},
{
"city": "当涂",
"district": "马鞍山市",
"prov": "安徽省",
"py": "dangtu"
},
{
"city": "含山",
"district": "马鞍山市",
"prov": "安徽省",
"py": "hanshan"
},
{
"city": "和县",
"district": "马鞍山市",
"prov": "安徽省",
"py": "hexian"
},
{
"city": "淮北",
"district": "淮北市",
"prov": "安徽省",
"py": "huaibei"
},
{
"city": "杜集",
"district": "淮北市",
"prov": "安徽省",
"py": "duji"
},
{
"city": "相山",
"district": "淮北市",
"prov": "安徽省",
"py": "xiangshan"
},
{
"city": "烈山",
"district": "淮北市",
"prov": "安徽省",
"py": "lieshan"
},
{
"city": "濉溪",
"district": "淮北市",
"prov": "安徽省",
"py": "suixi"
},
{
"city": "铜陵",
"district": "铜陵市",
"prov": "安徽省",
"py": "tongling"
},
{
"city": "铜官",
"district": "铜陵市",
"prov": "安徽省",
"py": "tongguan"
},
{
"city": "义安",
"district": "铜陵市",
"prov": "安徽省",
"py": "yian"
},
{
"city": "郊区",
"district": "铜陵市",
"prov": "安徽省",
"py": "jiaoqu"
},
{
"city": "枞阳",
"district": "铜陵市",
"prov": "安徽省",
"py": "zongyang"
},
{
"city": "安庆",
"district": "安庆市",
"prov": "安徽省",
"py": "anqing"
},
{
"city": "迎江",
"district": "安庆市",
"prov": "安徽省",
"py": "yingjiang"
},
{
"city": "大观",
"district": "安庆市",
"prov": "安徽省",
"py": "daguan"
},
{
"city": "宜秀",
"district": "安庆市",
"prov": "安徽省",
"py": "yixiu"
},
{
"city": "怀宁",
"district": "安庆市",
"prov": "安徽省",
"py": "huaining"
},
{
"city": "太湖",
"district": "安庆市",
"prov": "安徽省",
"py": "taihu"
},
{
"city": "宿松",
"district": "安庆市",
"prov": "安徽省",
"py": "xiusong"
},
{
"city": "望江",
"district": "安庆市",
"prov": "安徽省",
"py": "wangjiang"
},
{
"city": "岳西",
"district": "安庆市",
"prov": "安徽省",
"py": "yuexi"
},
{
"city": "桐城",
"district": "安庆市",
"prov": "安徽省",
"py": "tongcheng"
},
{
"city": "潜山",
"district": "安庆市",
"prov": "安徽省",
"py": "qianshan"
},
{
"city": "黄山",
"district": "黄山市",
"prov": "安徽省",
"py": "huangshan"
},
{
"city": "屯溪",
"district": "黄山市",
"prov": "安徽省",
"py": "tunxi"
},
{
"city": "黄山区",
"district": "黄山市",
"prov": "安徽省",
"py": "huangshanqu"
},
{
"city": "徽州",
"district": "黄山市",
"prov": "安徽省",
"py": "huizhou"
},
{
"city": "歙县",
"district": "黄山市",
"prov": "安徽省",
"py": "shexian"
},
{
"city": "休宁",
"district": "黄山市",
"prov": "安徽省",
"py": "xiuning"
},
{
"city": "黟县",
"district": "黄山市",
"prov": "安徽省",
"py": "yixian"
},
{
"city": "祁门",
"district": "黄山市",
"prov": "安徽省",
"py": "qimen"
},
{
"city": "滁州",
"district": "滁州市",
"prov": "安徽省",
"py": "chuzhou"
},
{
"city": "琅琊",
"district": "滁州市",
"prov": "安徽省",
"py": "langya"
},
{
"city": "南谯",
"district": "滁州市",
"prov": "安徽省",
"py": "nanqiao"
},
{
"city": "来安",
"district": "滁州市",
"prov": "安徽省",
"py": "laian"
},
{
"city": "全椒",
"district": "滁州市",
"prov": "安徽省",
"py": "quanjiao"
},
{
"city": "定远",
"district": "滁州市",
"prov": "安徽省",
"py": "dingyuan"
},
{
"city": "凤阳",
"district": "滁州市",
"prov": "安徽省",
"py": "fengyang"
},
{
"city": "天长",
"district": "滁州市",
"prov": "安徽省",
"py": "tianchang"
},
{
"city": "明光",
"district": "滁州市",
"prov": "安徽省",
"py": "mingguang"
},
{
"city": "阜阳",
"district": "阜阳市",
"prov": "安徽省",
"py": "fuyang"
},
{
"city": "颍州",
"district": "阜阳市",
"prov": "安徽省",
"py": "yingzhou"
},
{
"city": "颍东",
"district": "阜阳市",
"prov": "安徽省",
"py": "yingdong"
},
{
"city": "颍泉",
"district": "阜阳市",
"prov": "安徽省",
"py": "yingquan"
},
{
"city": "临泉",
"district": "阜阳市",
"prov": "安徽省",
"py": "linquan"
},
{
"city": "太和",
"district": "阜阳市",
"prov": "安徽省",
"py": "taihe"
},
{
"city": "阜南",
"district": "阜阳市",
"prov": "安徽省",
"py": "funan"
},
{
"city": "颍上",
"district": "阜阳市",
"prov": "安徽省",
"py": "yingshang"
},
{
"city": "界首",
"district": "阜阳市",
"prov": "安徽省",
"py": "jieshou"
},
{
"city": "宿州",
"district": "宿州市",
"prov": "安徽省",
"py": "suzhou"
},
{
"city": "埇桥",
"district": "宿州市",
"prov": "安徽省",
"py": "yongqiao"
},
{
"city": "砀山",
"district": "宿州市",
"prov": "安徽省",
"py": "dangshan"
},
{
"city": "萧县",
"district": "宿州市",
"prov": "安徽省",
"py": "xiaoxian"
},
{
"city": "灵璧",
"district": "宿州市",
"prov": "安徽省",
"py": "lingbi"
},
{
"city": "泗县",
"district": "宿州市",
"prov": "安徽省",
"py": "sixian"
},
{
"city": "六安",
"district": "六安市",
"prov": "安徽省",
"py": "luan"
},
{
"city": "金安",
"district": "六安市",
"prov": "安徽省",
"py": "jinan"
},
{
"city": "裕安",
"district": "六安市",
"prov": "安徽省",
"py": "yuan"
},
{
"city": "叶集",
"district": "六安市",
"prov": "安徽省",
"py": "yeji"
},
{
"city": "霍邱",
"district": "六安市",
"prov": "安徽省",
"py": "huoqiu"
},
{
"city": "舒城",
"district": "六安市",
"prov": "安徽省",
"py": "shucheng"
},
{
"city": "金寨",
"district": "六安市",
"prov": "安徽省",
"py": "jinzhai"
},
{
"city": "霍山",
"district": "六安市",
"prov": "安徽省",
"py": "huoshan"
},
{
"city": "亳州",
"district": "亳州市",
"prov": "安徽省",
"py": "bozhou"
},
{
"city": "谯城",
"district": "亳州市",
"prov": "安徽省",
"py": "qiaocheng"
},
{
"city": "涡阳",
"district": "亳州市",
"prov": "安徽省",
"py": "guoyang"
},
{
"city": "蒙城",
"district": "亳州市",
"prov": "安徽省",
"py": "mengcheng"
},
{
"city": "利辛",
"district": "亳州市",
"prov": "安徽省",
"py": "lixin"
},
{
"city": "池州",
"district": "池州市",
"prov": "安徽省",
"py": "chizhou"
},
{
"city": "贵池",
"district": "池州市",
"prov": "安徽省",
"py": "guichi"
},
{
"city": "东至",
"district": "池州市",
"prov": "安徽省",
"py": "dongzhi"
},
{
"city": "石台",
"district": "池州市",
"prov": "安徽省",
"py": "shitai"
},
{
"city": "青阳",
"district": "池州市",
"prov": "安徽省",
"py": "qingyang"
},
{
"city": "宣城",
"district": "宣城市",
"prov": "安徽省",
"py": "xuancheng"
},
{
"city": "宣州",
"district": "宣城市",
"prov": "安徽省",
"py": "xuanzhou"
},
{
"city": "郎溪",
"district": "宣城市",
"prov": "安徽省",
"py": "langxi"
},
{
"city": "广德",
"district": "宣城市",
"prov": "安徽省",
"py": "guangde"
},
{
"city": "泾县",
"district": "宣城市",
"prov": "安徽省",
"py": "jingxian"
},
{
"city": "绩溪",
"district": "宣城市",
"prov": "安徽省",
"py": "jixi"
},
{
"city": "旌德",
"district": "宣城市",
"prov": "安徽省",
"py": "jingde"
},
{
"city": "宁国",
"district": "宣城市",
"prov": "安徽省",
"py": "ningguo"
},
{
"city": "福州",
"district": "福州市",
"prov": "福建省",
"py": "fuzhou"
},
{
"city": "鼓楼区",
"district": "福州市",
"prov": "福建省",
"py": "gulouqu"
},
{
"city": "台江区",
"district": "福州市",
"prov": "福建省",
"py": "taijiangqu"
},
{
"city": "仓山",
"district": "福州市",
"prov": "福建省",
"py": "cangshan"
},
{
"city": "马尾",
"district": "福州市",
"prov": "福建省",
"py": "mawei"
},
{
"city": "晋安",
"district": "福州市",
"prov": "福建省",
"py": "jinan"
},
{
"city": "长乐",
"district": "福州市",
"prov": "福建省",
"py": "changle"
},
{
"city": "闽侯",
"district": "福州市",
"prov": "福建省",
"py": "minhou"
},
{
"city": "连江",
"district": "福州市",
"prov": "福建省",
"py": "lianjiang"
},
{
"city": "罗源",
"district": "福州市",
"prov": "福建省",
"py": "luoyuan"
},
{
"city": "闽清",
"district": "福州市",
"prov": "福建省",
"py": "minqing"
},
{
"city": "永泰",
"district": "福州市",
"prov": "福建省",
"py": "yongtai"
},
{
"city": "平潭",
"district": "福州市",
"prov": "福建省",
"py": "pingtan"
},
{
"city": "福清",
"district": "福州市",
"prov": "福建省",
"py": "fuqing"
},
{
"city": "厦门",
"district": "厦门市",
"prov": "福建省",
"py": "xiamen"
},
{
"city": "思明",
"district": "厦门市",
"prov": "福建省",
"py": "siming"
},
{
"city": "海沧",
"district": "厦门市",
"prov": "福建省",
"py": "haicang"
},
{
"city": "湖里",
"district": "厦门市",
"prov": "福建省",
"py": "huli"
},
{
"city": "集美",
"district": "厦门市",
"prov": "福建省",
"py": "jimei"
},
{
"city": "同安",
"district": "厦门市",
"prov": "福建省",
"py": "tongan"
},
{
"city": "翔安",
"district": "厦门市",
"prov": "福建省",
"py": "xiangan"
},
{
"city": "莆田",
"district": "莆田市",
"prov": "福建省",
"py": "putian"
},
{
"city": "城厢",
"district": "莆田市",
"prov": "福建省",
"py": "chengxiang"
},
{
"city": "涵江",
"district": "莆田市",
"prov": "福建省",
"py": "hanjiang"
},
{
"city": "荔城",
"district": "莆田市",
"prov": "福建省",
"py": "licheng"
},
{
"city": "秀屿",
"district": "莆田市",
"prov": "福建省",
"py": "xiuyu"
},
{
"city": "仙游",
"district": "莆田市",
"prov": "福建省",
"py": "xianyou"
},
{
"city": "三明",
"district": "三明市",
"prov": "福建省",
"py": "sanming"
},
{
"city": "梅列",
"district": "三明市",
"prov": "福建省",
"py": "meilie"
},
{
"city": "三元",
"district": "三明市",
"prov": "福建省",
"py": "sanyuan"
},
{
"city": "明溪",
"district": "三明市",
"prov": "福建省",
"py": "mingxi"
},
{
"city": "清流",
"district": "三明市",
"prov": "福建省",
"py": "qingliu"
},
{
"city": "宁化",
"district": "三明市",
"prov": "福建省",
"py": "ninghua"
},
{
"city": "大田",
"district": "三明市",
"prov": "福建省",
"py": "datian"
},
{
"city": "尤溪",
"district": "三明市",
"prov": "福建省",
"py": "youxi"
},
{
"city": "沙县",
"district": "三明市",
"prov": "福建省",
"py": "shaxian"
},
{
"city": "将乐",
"district": "三明市",
"prov": "福建省",
"py": "jiangle"
},
{
"city": "泰宁",
"district": "三明市",
"prov": "福建省",
"py": "taining"
},
{
"city": "建宁",
"district": "三明市",
"prov": "福建省",
"py": "jianning"
},
{
"city": "永安",
"district": "三明市",
"prov": "福建省",
"py": "yongan"
},
{
"city": "泉州",
"district": "泉州市",
"prov": "福建省",
"py": "quanzhou"
},
{
"city": "鲤城",
"district": "泉州市",
"prov": "福建省",
"py": "licheng"
},
{
"city": "丰泽",
"district": "泉州市",
"prov": "福建省",
"py": "fengze"
},
{
"city": "洛江",
"district": "泉州市",
"prov": "福建省",
"py": "luojiang"
},
{
"city": "泉港",
"district": "泉州市",
"prov": "福建省",
"py": "quangang"
},
{
"city": "惠安",
"district": "泉州市",
"prov": "福建省",
"py": "huian"
},
{
"city": "安溪",
"district": "泉州市",
"prov": "福建省",
"py": "anxi"
},
{
"city": "永春",
"district": "泉州市",
"prov": "福建省",
"py": "yongchun"
},
{
"city": "德化",
"district": "泉州市",
"prov": "福建省",
"py": "dehua"
},
{
"city": "金门",
"district": "泉州市",
"prov": "福建省",
"py": "jinmen"
},
{
"city": "石狮",
"district": "泉州市",
"prov": "福建省",
"py": "shishi"
},
{
"city": "晋江",
"district": "泉州市",
"prov": "福建省",
"py": "jinjiang"
},
{
"city": "南安",
"district": "泉州市",
"prov": "福建省",
"py": "nanan"
},
{
"city": "漳州",
"district": "漳州市",
"prov": "福建省",
"py": "zhangzhou"
},
{
"city": "芗城",
"district": "漳州市",
"prov": "福建省",
"py": "xiangcheng"
},
{
"city": "龙文",
"district": "漳州市",
"prov": "福建省",
"py": "longwen"
},
{
"city": "云霄",
"district": "漳州市",
"prov": "福建省",
"py": "yunxiao"
},
{
"city": "漳浦",
"district": "漳州市",
"prov": "福建省",
"py": "zhangpu"
},
{
"city": "诏安",
"district": "漳州市",
"prov": "福建省",
"py": "zhaoan"
},
{
"city": "长泰",
"district": "漳州市",
"prov": "福建省",
"py": "changtai"
},
{
"city": "东山",
"district": "漳州市",
"prov": "福建省",
"py": "dongshan"
},
{
"city": "南靖",
"district": "漳州市",
"prov": "福建省",
"py": "nanjing"
},
{
"city": "平和",
"district": "漳州市",
"prov": "福建省",
"py": "pinghe"
},
{
"city": "华安",
"district": "漳州市",
"prov": "福建省",
"py": "huaan"
},
{
"city": "龙海",
"district": "漳州市",
"prov": "福建省",
"py": "longhai"
},
{
"city": "南平",
"district": "南平市",
"prov": "福建省",
"py": "nanping"
},
{
"city": "延平",
"district": "南平市",
"prov": "福建省",
"py": "yanping"
},
{
"city": "建阳",
"district": "南平市",
"prov": "福建省",
"py": "jianyang"
},
{
"city": "顺昌",
"district": "南平市",
"prov": "福建省",
"py": "shunchang"
},
{
"city": "浦城",
"district": "南平市",
"prov": "福建省",
"py": "pucheng"
},
{
"city": "光泽",
"district": "南平市",
"prov": "福建省",
"py": "guangze"
},
{
"city": "松溪",
"district": "南平市",
"prov": "福建省",
"py": "songxi"
},
{
"city": "政和",
"district": "南平市",
"prov": "福建省",
"py": "zhenghe"
},
{
"city": "邵武",
"district": "南平市",
"prov": "福建省",
"py": "shaowu"
},
{
"city": "武夷山",
"district": "南平市",
"prov": "福建省",
"py": "wuyishan"
},
{
"city": "建瓯",
"district": "南平市",
"prov": "福建省",
"py": "jianou"
},
{
"city": "龙岩",
"district": "龙岩市",
"prov": "福建省",
"py": "longyan"
},
{
"city": "新罗",
"district": "龙岩市",
"prov": "福建省",
"py": "xinluo"
},
{
"city": "永定区",
"district": "龙岩市",
"prov": "福建省",
"py": "yongdingqu"
},
{
"city": "长汀",
"district": "龙岩市",
"prov": "福建省",
"py": "changting"
},
{
"city": "上杭",
"district": "龙岩市",
"prov": "福建省",
"py": "shanghang"
},
{
"city": "武平",
"district": "龙岩市",
"prov": "福建省",
"py": "wuping"
},
{
"city": "连城",
"district": "龙岩市",
"prov": "福建省",
"py": "liancheng"
},
{
"city": "漳平",
"district": "龙岩市",
"prov": "福建省",
"py": "zhangping"
},
{
"city": "宁德",
"district": "宁德市",
"prov": "福建省",
"py": "ningde"
},
{
"city": "蕉城",
"district": "宁德市",
"prov": "福建省",
"py": "jiaocheng"
},
{
"city": "霞浦",
"district": "宁德市",
"prov": "福建省",
"py": "xiapu"
},
{
"city": "古田",
"district": "宁德市",
"prov": "福建省",
"py": "gutian"
},
{
"city": "屏南",
"district": "宁德市",
"prov": "福建省",
"py": "pingnan"
},
{
"city": "寿宁",
"district": "宁德市",
"prov": "福建省",
"py": "shouning"
},
{
"city": "周宁",
"district": "宁德市",
"prov": "福建省",
"py": "zhouning"
},
{
"city": "柘荣",
"district": "宁德市",
"prov": "福建省",
"py": "zherong"
},
{
"city": "福安",
"district": "宁德市",
"prov": "福建省",
"py": "fuan"
},
{
"city": "福鼎",
"district": "宁德市",
"prov": "福建省",
"py": "fuding"
},
{
"city": "南昌",
"district": "南昌市",
"prov": "江西省",
"py": "nanchang"
},
{
"city": "东湖区",
"district": "南昌市",
"prov": "江西省",
"py": "donghuqu"
},
{
"city": "西湖区",
"district": "南昌市",
"prov": "江西省",
"py": "xihuqu"
},
{
"city": "青云谱",
"district": "南昌市",
"prov": "江西省",
"py": "qingyunpu"
},
{
"city": "湾里",
"district": "南昌市",
"prov": "江西省",
"py": "wanli"
},
{
"city": "青山湖",
"district": "南昌市",
"prov": "江西省",
"py": "qingshanhu"
},
{
"city": "新建区",
"district": "南昌市",
"prov": "江西省",
"py": "xinjianqu"
},
{
"city": "南昌县",
"district": "南昌市",
"prov": "江西省",
"py": "nanchangxian"
},
{
"city": "安义",
"district": "南昌市",
"prov": "江西省",
"py": "anyi"
},
{
"city": "进贤",
"district": "南昌市",
"prov": "江西省",
"py": "jinxian"
},
{
"city": "红谷滩区",
"district": "南昌市",
"prov": "江西省",
"py": "honggutanqu"
},
{
"city": "景德镇",
"district": "景德镇市",
"prov": "江西省",
"py": "jingdezhen"
},
{
"city": "昌江区",
"district": "景德镇市",
"prov": "江西省",
"py": "changjiangqu"
},
{
"city": "珠山",
"district": "景德镇市",
"prov": "江西省",
"py": "zhushan"
},
{
"city": "浮梁",
"district": "景德镇市",
"prov": "江西省",
"py": "fuliang"
},
{
"city": "乐平",
"district": "景德镇市",
"prov": "江西省",
"py": "leping"
},
{
"city": "萍乡",
"district": "萍乡市",
"prov": "江西省",
"py": "pingxiang"
},
{
"city": "安源",
"district": "萍乡市",
"prov": "江西省",
"py": "anyuan"
},
{
"city": "湘东",
"district": "萍乡市",
"prov": "江西省",
"py": "xiangdong"
},
{
"city": "莲花",
"district": "萍乡市",
"prov": "江西省",
"py": "lianhua"
},
{
"city": "上栗",
"district": "萍乡市",
"prov": "江西省",
"py": "shangli"
},
{
"city": "芦溪",
"district": "萍乡市",
"prov": "江西省",
"py": "luxi"
},
{
"city": "九江",
"district": "九江市",
"prov": "江西省",
"py": "jiujiang"
},
{
"city": "濂溪",
"district": "九江市",
"prov": "江西省",
"py": "lianxi"
},
{
"city": "浔阳",
"district": "九江市",
"prov": "江西省",
"py": "xunyang"
},
{
"city": "柴桑",
"district": "九江市",
"prov": "江西省",
"py": "chaisang"
},
{
"city": "武宁",
"district": "九江市",
"prov": "江西省",
"py": "wuning"
},
{
"city": "修水",
"district": "九江市",
"prov": "江西省",
"py": "xiushui"
},
{
"city": "永修",
"district": "九江市",
"prov": "江西省",
"py": "yongxiu"
},
{
"city": "德安",
"district": "九江市",
"prov": "江西省",
"py": "dean"
},
{
"city": "都昌",
"district": "九江市",
"prov": "江西省",
"py": "duchang"
},
{
"city": "湖口",
"district": "九江市",
"prov": "江西省",
"py": "hukou"
},
{
"city": "彭泽",
"district": "九江市",
"prov": "江西省",
"py": "pengze"
},
{
"city": "瑞昌",
"district": "九江市",
"prov": "江西省",
"py": "ruichang"
},
{
"city": "共青城",
"district": "九江市",
"prov": "江西省",
"py": "gongqingcheng"
},
{
"city": "庐山",
"district": "九江市",
"prov": "江西省",
"py": "lushan"
},
{
"city": "新余",
"district": "新余市",
"prov": "江西省",
"py": "xinyu"
},
{
"city": "渝水",
"district": "新余市",
"prov": "江西省",
"py": "yushui"
},
{
"city": "分宜",
"district": "新余市",
"prov": "江西省",
"py": "fenyi"
},
{
"city": "鹰潭",
"district": "鹰潭市",
"prov": "江西省",
"py": "yingtan"
},
{
"city": "月湖",
"district": "鹰潭市",
"prov": "江西省",
"py": "yuehu"
},
{
"city": "余江",
"district": "鹰潭市",
"prov": "江西省",
"py": "yujiang"
},
{
"city": "贵溪",
"district": "鹰潭市",
"prov": "江西省",
"py": "guixi"
},
{
"city": "赣州",
"district": "赣州市",
"prov": "江西省",
"py": "ganzhou"
},
{
"city": "章贡",
"district": "赣州市",
"prov": "江西省",
"py": "zhanggong"
},
{
"city": "南康",
"district": "赣州市",
"prov": "江西省",
"py": "nankang"
},
{
"city": "赣县",
"district": "赣州市",
"prov": "江西省",
"py": "ganxian"
},
{
"city": "信丰",
"district": "赣州市",
"prov": "江西省",
"py": "xinfeng"
},
{
"city": "大余",
"district": "赣州市",
"prov": "江西省",
"py": "dayu"
},
{
"city": "上犹",
"district": "赣州市",
"prov": "江西省",
"py": "shangyou"
},
{
"city": "崇义",
"district": "赣州市",
"prov": "江西省",
"py": "chongyi"
},
{
"city": "安远",
"district": "赣州市",
"prov": "江西省",
"py": "anyuan"
},
{
"city": "龙南",
"district": "赣州市",
"prov": "江西省",
"py": "longnan"
},
{
"city": "定南",
"district": "赣州市",
"prov": "江西省",
"py": "dingnan"
},
{
"city": "全南",
"district": "赣州市",
"prov": "江西省",
"py": "quannan"
},
{
"city": "宁都",
"district": "赣州市",
"prov": "江西省",
"py": "ningdu"
},
{
"city": "于都",
"district": "赣州市",
"prov": "江西省",
"py": "yudu"
},
{
"city": "兴国",
"district": "赣州市",
"prov": "江西省",
"py": "xingguo"
},
{
"city": "会昌",
"district": "赣州市",
"prov": "江西省",
"py": "huichang"
},
{
"city": "寻乌",
"district": "赣州市",
"prov": "江西省",
"py": "xunwu"
},
{
"city": "石城",
"district": "赣州市",
"prov": "江西省",
"py": "shicheng"
},
{
"city": "瑞金",
"district": "赣州市",
"prov": "江西省",
"py": "ruijin"
},
{
"city": "吉安",
"district": "吉安市",
"prov": "江西省",
"py": "jian"
},
{
"city": "吉州",
"district": "吉安市",
"prov": "江西省",
"py": "jizhou"
},
{
"city": "青原",
"district": "吉安市",
"prov": "江西省",
"py": "qingyuan"
},
{
"city": "吉安县",
"district": "吉安市",
"prov": "江西省",
"py": "jianxian"
},
{
"city": "吉水",
"district": "吉安市",
"prov": "江西省",
"py": "jishui"
},
{
"city": "峡江",
"district": "吉安市",
"prov": "江西省",
"py": "xiajiang"
},
{
"city": "新干",
"district": "吉安市",
"prov": "江西省",
"py": "xingan"
},
{
"city": "永丰",
"district": "吉安市",
"prov": "江西省",
"py": "yongfeng"
},
{
"city": "泰和",
"district": "吉安市",
"prov": "江西省",
"py": "taihe"
},
{
"city": "遂川",
"district": "吉安市",
"prov": "江西省",
"py": "suichuan"
},
{
"city": "万安",
"district": "吉安市",
"prov": "江西省",
"py": "wanan"
},
{
"city": "安福",
"district": "吉安市",
"prov": "江西省",
"py": "anfu"
},
{
"city": "永新",
"district": "吉安市",
"prov": "江西省",
"py": "yongxin"
},
{
"city": "井冈山",
"district": "吉安市",
"prov": "江西省",
"py": "jinggangshan"
},
{
"city": "宜春",
"district": "宜春市",
"prov": "江西省",
"py": "yichun"
},
{
"city": "袁州",
"district": "宜春市",
"prov": "江西省",
"py": "yuanzhou"
},
{
"city": "奉新",
"district": "宜春市",
"prov": "江西省",
"py": "fengxin"
},
{
"city": "万载",
"district": "宜春市",
"prov": "江西省",
"py": "wanzai"
},
{
"city": "上高",
"district": "宜春市",
"prov": "江西省",
"py": "shanggao"
},
{
"city": "宜丰",
"district": "宜春市",
"prov": "江西省",
"py": "yifeng"
},
{
"city": "靖安",
"district": "宜春市",
"prov": "江西省",
"py": "jingan"
},
{
"city": "铜鼓",
"district": "宜春市",
"prov": "江西省",
"py": "tonggu"
},
{
"city": "丰城",
"district": "宜春市",
"prov": "江西省",
"py": "fengcheng"
},
{
"city": "樟树",
"district": "宜春市",
"prov": "江西省",
"py": "zhangshu"
},
{
"city": "高安",
"district": "宜春市",
"prov": "江西省",
"py": "gaoan"
},
{
"city": "抚州",
"district": "抚州市",
"prov": "江西省",
"py": "fuzhou"
},
{
"city": "临川",
"district": "抚州市",
"prov": "江西省",
"py": "linchuan"
},
{
"city": "东乡区",
"district": "抚州市",
"prov": "江西省",
"py": "dongxiangqu"
},
{
"city": "南城",
"district": "抚州市",
"prov": "江西省",
"py": "nancheng"
},
{
"city": "黎川",
"district": "抚州市",
"prov": "江西省",
"py": "lichuan"
},
{
"city": "南丰",
"district": "抚州市",
"prov": "江西省",
"py": "nanfeng"
},
{
"city": "崇仁",
"district": "抚州市",
"prov": "江西省",
"py": "chongren"
},
{
"city": "乐安",
"district": "抚州市",
"prov": "江西省",
"py": "lean"
},
{
"city": "宜黄",
"district": "抚州市",
"prov": "江西省",
"py": "yihuang"
},
{
"city": "金溪",
"district": "抚州市",
"prov": "江西省",
"py": "jinxi"
},
{
"city": "资溪",
"district": "抚州市",
"prov": "江西省",
"py": "zixi"
},
{
"city": "广昌",
"district": "抚州市",
"prov": "江西省",
"py": "guangchang"
},
{
"city": "上饶",
"district": "上饶市",
"prov": "江西省",
"py": "shangrao"
},
{
"city": "信州",
"district": "上饶市",
"prov": "江西省",
"py": "xinzhou"
},
{
"city": "广丰",
"district": "上饶市",
"prov": "江西省",
"py": "guangfeng"
},
{
"city": "上饶县",
"district": "上饶市",
"prov": "江西省",
"py": "shangraoxian"
},
{
"city": "玉山",
"district": "上饶市",
"prov": "江西省",
"py": "yushan"
},
{
"city": "铅山",
"district": "上饶市",
"prov": "江西省",
"py": "yanshan"
},
{
"city": "横峰",
"district": "上饶市",
"prov": "江西省",
"py": "hengfeng"
},
{
"city": "弋阳",
"district": "上饶市",
"prov": "江西省",
"py": "yiyang"
},
{
"city": "余干",
"district": "上饶市",
"prov": "江西省",
"py": "yugan"
},
{
"city": "鄱阳",
"district": "上饶市",
"prov": "江西省",
"py": "poyang"
},
{
"city": "万年",
"district": "上饶市",
"prov": "江西省",
"py": "wannian"
},
{
"city": "婺源",
"district": "上饶市",
"prov": "江西省",
"py": "wuyuan"
},
{
"city": "德兴",
"district": "上饶市",
"prov": "江西省",
"py": "dexing"
},
{
"city": "广信区",
"district": "上饶市",
"prov": "江西省",
"py": "guangxinqu"
},
{
"city": "济南",
"district": "济南市",
"prov": "山东省",
"py": "jinan"
},
{
"city": "历下",
"district": "济南市",
"prov": "山东省",
"py": "lixia"
},
{
"city": "市中",
"district": "济南市",
"prov": "山东省",
"py": "shizhong"
},
{
"city": "槐荫",
"district": "济南市",
"prov": "山东省",
"py": "huaiyin"
},
{
"city": "天桥",
"district": "济南市",
"prov": "山东省",
"py": "tianqiao"
},
{
"city": "历城",
"district": "济南市",
"prov": "山东省",
"py": "licheng"
},
{
"city": "长清",
"district": "济南市",
"prov": "山东省",
"py": "changqing"
},
{
"city": "章丘",
"district": "济南市",
"prov": "山东省",
"py": "zhangqiu"
},
{
"city": "济阳",
"district": "济南市",
"prov": "山东省",
"py": "jiyang"
},
{
"city": "莱芜",
"district": "济南市",
"prov": "山东省",
"py": "laiwu"
},
{
"city": "钢城",
"district": "济南市",
"prov": "山东省",
"py": "gangcheng"
},
{
"city": "平阴",
"district": "济南市",
"prov": "山东省",
"py": "pingyin"
},
{
"city": "商河",
"district": "济南市",
"prov": "山东省",
"py": "shanghe"
},
{
"city": "青岛",
"district": "青岛市",
"prov": "山东省",
"py": "qingdao"
},
{
"city": "市南区",
"district": "青岛市",
"prov": "山东省",
"py": "shinanqu"
},
{
"city": "市北区",
"district": "青岛市",
"prov": "山东省",
"py": "shibeiqu"
},
{
"city": "黄岛",
"district": "青岛市",
"prov": "山东省",
"py": "huangdao"
},
{
"city": "崂山",
"district": "青岛市",
"prov": "山东省",
"py": "laoshan"
},
{
"city": "李沧",
"district": "青岛市",
"prov": "山东省",
"py": "licang"
},
{
"city": "城阳",
"district": "青岛市",
"prov": "山东省",
"py": "chengyang"
},
{
"city": "即墨",
"district": "青岛市",
"prov": "山东省",
"py": "jimo"
},
{
"city": "胶州",
"district": "青岛市",
"prov": "山东省",
"py": "jiaozhou"
},
{
"city": "平度",
"district": "青岛市",
"prov": "山东省",
"py": "pingdu"
},
{
"city": "莱西",
"district": "青岛市",
"prov": "山东省",
"py": "laixi"
},
{
"city": "淄博",
"district": "淄博市",
"prov": "山东省",
"py": "zibo"
},
{
"city": "淄川",
"district": "淄博市",
"prov": "山东省",
"py": "zichuan"
},
{
"city": "张店",
"district": "淄博市",
"prov": "山东省",
"py": "zhangdian"
},
{
"city": "博山",
"district": "淄博市",
"prov": "山东省",
"py": "boshan"
},
{
"city": "临淄",
"district": "淄博市",
"prov": "山东省",
"py": "linzi"
},
{
"city": "周村",
"district": "淄博市",
"prov": "山东省",
"py": "zhoucun"
},
{
"city": "桓台",
"district": "淄博市",
"prov": "山东省",
"py": "huantai"
},
{
"city": "高青",
"district": "淄博市",
"prov": "山东省",
"py": "gaoqing"
},
{
"city": "沂源",
"district": "淄博市",
"prov": "山东省",
"py": "yiyuan"
},
{
"city": "枣庄",
"district": "枣庄市",
"prov": "山东省",
"py": "zaozhuang"
},
{
"city": "市中区",
"district": "枣庄市",
"prov": "山东省",
"py": "shizhongqu"
},
{
"city": "薛城",
"district": "枣庄市",
"prov": "山东省",
"py": "xuecheng"
},
{
"city": "峄城",
"district": "枣庄市",
"prov": "山东省",
"py": "yicheng"
},
{
"city": "台儿庄",
"district": "枣庄市",
"prov": "山东省",
"py": "taierzhuang"
},
{
"city": "山亭",
"district": "枣庄市",
"prov": "山东省",
"py": "shanting"
},
{
"city": "滕州",
"district": "枣庄市",
"prov": "山东省",
"py": "tengzhou"
},
{
"city": "东营",
"district": "东营市",
"prov": "山东省",
"py": "dongying"
},
{
"city": "东营区",
"district": "东营市",
"prov": "山东省",
"py": "dongyingqu"
},
{
"city": "河口区",
"district": "东营市",
"prov": "山东省",
"py": "hekouqu"
},
{
"city": "垦利",
"district": "东营市",
"prov": "山东省",
"py": "kenli"
},
{
"city": "利津",
"district": "东营市",
"prov": "山东省",
"py": "lijin"
},
{
"city": "广饶",
"district": "东营市",
"prov": "山东省",
"py": "guangrao"
},
{
"city": "烟台",
"district": "烟台市",
"prov": "山东省",
"py": "yantai"
},
{
"city": "芝罘",
"district": "烟台市",
"prov": "山东省",
"py": "zhifu"
},
{
"city": "福山",
"district": "烟台市",
"prov": "山东省",
"py": "fushan"
},
{
"city": "牟平",
"district": "烟台市",
"prov": "山东省",
"py": "mouping"
},
{
"city": "莱山",
"district": "烟台市",
"prov": "山东省",
"py": "laishan"
},
{
"city": "长岛",
"district": "烟台市",
"prov": "山东省",
"py": "changdao"
},
{
"city": "龙口",
"district": "烟台市",
"prov": "山东省",
"py": "longkou"
},
{
"city": "莱阳",
"district": "烟台市",
"prov": "山东省",
"py": "laiyang"
},
{
"city": "莱州",
"district": "烟台市",
"prov": "山东省",
"py": "laizhou"
},
{
"city": "蓬莱",
"district": "烟台市",
"prov": "山东省",
"py": "penglai"
},
{
"city": "招远",
"district": "烟台市",
"prov": "山东省",
"py": "zhaoyuan"
},
{
"city": "栖霞",
"district": "烟台市",
"prov": "山东省",
"py": "qixia"
},
{
"city": "海阳",
"district": "烟台市",
"prov": "山东省",
"py": "haiyang"
},
{
"city": "潍坊",
"district": "潍坊市",
"prov": "山东省",
"py": "weifang"
},
{
"city": "潍城",
"district": "潍坊市",
"prov": "山东省",
"py": "weicheng"
},
{
"city": "寒亭",
"district": "潍坊市",
"prov": "山东省",
"py": "hanting"
},
{
"city": "坊子",
"district": "潍坊市",
"prov": "山东省",
"py": "fangzi"
},
{
"city": "奎文",
"district": "潍坊市",
"prov": "山东省",
"py": "kuiwen"
},
{
"city": "临朐",
"district": "潍坊市",
"prov": "山东省",
"py": "linqu"
},
{
"city": "昌乐",
"district": "潍坊市",
"prov": "山东省",
"py": "changle"
},
{
"city": "青州",
"district": "潍坊市",
"prov": "山东省",
"py": "qingzhou"
},
{
"city": "诸城",
"district": "潍坊市",
"prov": "山东省",
"py": "zhucheng"
},
{
"city": "寿光",
"district": "潍坊市",
"prov": "山东省",
"py": "shouguang"
},
{
"city": "安丘",
"district": "潍坊市",
"prov": "山东省",
"py": "anqiu"
},
{
"city": "高密",
"district": "潍坊市",
"prov": "山东省",
"py": "gaomi"
},
{
"city": "昌邑",
"district": "潍坊市",
"prov": "山东省",
"py": "changyi"
},
{
"city": "济宁",
"district": "济宁市",
"prov": "山东省",
"py": "jining"
},
{
"city": "任城",
"district": "济宁市",
"prov": "山东省",
"py": "rencheng"
},
{
"city": "兖州",
"district": "济宁市",
"prov": "山东省",
"py": "yanzhou"
},
{
"city": "微山",
"district": "济宁市",
"prov": "山东省",
"py": "weishan"
},
{
"city": "鱼台",
"district": "济宁市",
"prov": "山东省",
"py": "yutai"
},
{
"city": "金乡",
"district": "济宁市",
"prov": "山东省",
"py": "jinxiang"
},
{
"city": "嘉祥",
"district": "济宁市",
"prov": "山东省",
"py": "jiaxiang"
},
{
"city": "汶上",
"district": "济宁市",
"prov": "山东省",
"py": "wenshang"
},
{
"city": "泗水",
"district": "济宁市",
"prov": "山东省",
"py": "sishui"
},
{
"city": "梁山",
"district": "济宁市",
"prov": "山东省",
"py": "liangshan"
},
{
"city": "曲阜",
"district": "济宁市",
"prov": "山东省",
"py": "qufu"
},
{
"city": "邹城",
"district": "济宁市",
"prov": "山东省",
"py": "zoucheng"
},
{
"city": "泰安",
"district": "泰安市",
"prov": "山东省",
"py": "taian"
},
{
"city": "泰山",
"district": "泰安市",
"prov": "山东省",
"py": "taishan"
},
{
"city": "岱岳",
"district": "泰安市",
"prov": "山东省",
"py": "daiyue"
},
{
"city": "宁阳",
"district": "泰安市",
"prov": "山东省",
"py": "ningyang"
},
{
"city": "东平",
"district": "泰安市",
"prov": "山东省",
"py": "dongping"
},
{
"city": "新泰",
"district": "泰安市",
"prov": "山东省",
"py": "xintai"
},
{
"city": "肥城",
"district": "泰安市",
"prov": "山东省",
"py": "feicheng"
},
{
"city": "威海",
"district": "威海市",
"prov": "山东省",
"py": "weihai"
},
{
"city": "环翠",
"district": "威海市",
"prov": "山东省",
"py": "huancui"
},
{
"city": "文登",
"district": "威海市",
"prov": "山东省",
"py": "wendeng"
},
{
"city": "荣成",
"district": "威海市",
"prov": "山东省",
"py": "rongcheng"
},
{
"city": "乳山",
"district": "威海市",
"prov": "山东省",
"py": "rushan"
},
{
"city": "日照",
"district": "日照市",
"prov": "山东省",
"py": "rizhao"
},
{
"city": "东港区",
"district": "日照市",
"prov": "山东省",
"py": "donggangqu"
},
{
"city": "岚山",
"district": "日照市",
"prov": "山东省",
"py": "lanshan"
},
{
"city": "五莲",
"district": "日照市",
"prov": "山东省",
"py": "wulian"
},
{
"city": "莒县",
"district": "日照市",
"prov": "山东省",
"py": "juxian"
},
{
"city": "临沂",
"district": "临沂市",
"prov": "山东省",
"py": "linyi"
},
{
"city": "兰山",
"district": "临沂市",
"prov": "山东省",
"py": "lanshan"
},
{
"city": "罗庄",
"district": "临沂市",
"prov": "山东省",
"py": "luozhuang"
},
{
"city": "河东区",
"district": "临沂市",
"prov": "山东省",
"py": "hedongqu"
},
{
"city": "沂南",
"district": "临沂市",
"prov": "山东省",
"py": "yinan"
},
{
"city": "郯城",
"district": "临沂市",
"prov": "山东省",
"py": "tancheng"
},
{
"city": "沂水",
"district": "临沂市",
"prov": "山东省",
"py": "yishui"
},
{
"city": "兰陵",
"district": "临沂市",
"prov": "山东省",
"py": "lanling"
},
{
"city": "费县",
"district": "临沂市",
"prov": "山东省",
"py": "feixian"
},
{
"city": "平邑",
"district": "临沂市",
"prov": "山东省",
"py": "pingyi"
},
{
"city": "莒南",
"district": "临沂市",
"prov": "山东省",
"py": "junan"
},
{
"city": "蒙阴",
"district": "临沂市",
"prov": "山东省",
"py": "mengyin"
},
{
"city": "临沭",
"district": "临沂市",
"prov": "山东省",
"py": "linshu"
},
{
"city": "德州",
"district": "德州市",
"prov": "山东省",
"py": "dezhou"
},
{
"city": "德城",
"district": "德州市",
"prov": "山东省",
"py": "decheng"
},
{
"city": "陵城",
"district": "德州市",
"prov": "山东省",
"py": "lingcheng"
},
{
"city": "宁津",
"district": "德州市",
"prov": "山东省",
"py": "ningjin"
},
{
"city": "庆云",
"district": "德州市",
"prov": "山东省",
"py": "qingyun"
},
{
"city": "临邑",
"district": "德州市",
"prov": "山东省",
"py": "linyi"
},
{
"city": "齐河",
"district": "德州市",
"prov": "山东省",
"py": "qihe"
},
{
"city": "平原",
"district": "德州市",
"prov": "山东省",
"py": "pingyuan"
},
{
"city": "夏津",
"district": "德州市",
"prov": "山东省",
"py": "xiajin"
},
{
"city": "武城",
"district": "德州市",
"prov": "山东省",
"py": "wucheng"
},
{
"city": "乐陵",
"district": "德州市",
"prov": "山东省",
"py": "leling"
},
{
"city": "禹城",
"district": "德州市",
"prov": "山东省",
"py": "yucheng"
},
{
"city": "聊城",
"district": "聊城市",
"prov": "山东省",
"py": "liaocheng"
},
{
"city": "东昌府",
"district": "聊城市",
"prov": "山东省",
"py": "dongchangfu"
},
{
"city": "阳谷",
"district": "聊城市",
"prov": "山东省",
"py": "yanggu"
},
{
"city": "莘县",
"district": "聊城市",
"prov": "山东省",
"py": "shenxian"
},
{
"city": "茌平",
"district": "聊城市",
"prov": "山东省",
"py": "chiping"
},
{
"city": "东阿",
"district": "聊城市",
"prov": "山东省",
"py": "donge"
},
{
"city": "冠县",
"district": "聊城市",
"prov": "山东省",
"py": "guanxian"
},
{
"city": "高唐",
"district": "聊城市",
"prov": "山东省",
"py": "gaotang"
},
{
"city": "临清",
"district": "聊城市",
"prov": "山东省",
"py": "linqing"
},
{
"city": "滨州",
"district": "滨州市",
"prov": "山东省",
"py": "binzhou"
},
{
"city": "滨城",
"district": "滨州市",
"prov": "山东省",
"py": "bincheng"
},
{
"city": "沾化",
"district": "滨州市",
"prov": "山东省",
"py": "zhanhua"
},
{
"city": "惠民",
"district": "滨州市",
"prov": "山东省",
"py": "huimin"
},
{
"city": "阳信",
"district": "滨州市",
"prov": "山东省",
"py": "yangxin"
},
{
"city": "无棣",
"district": "滨州市",
"prov": "山东省",
"py": "wudi"
},
{
"city": "博兴",
"district": "滨州市",
"prov": "山东省",
"py": "boxing"
},
{
"city": "邹平",
"district": "滨州市",
"prov": "山东省",
"py": "zouping"
},
{
"city": "菏泽",
"district": "菏泽市",
"prov": "山东省",
"py": "heze"
},
{
"city": "牡丹",
"district": "菏泽市",
"prov": "山东省",
"py": "mudan"
},
{
"city": "定陶",
"district": "菏泽市",
"prov": "山东省",
"py": "dingtao"
},
{
"city": "曹县",
"district": "菏泽市",
"prov": "山东省",
"py": "caoxian"
},
{
"city": "单县",
"district": "菏泽市",
"prov": "山东省",
"py": "shanxian"
},
{
"city": "成武",
"district": "菏泽市",
"prov": "山东省",
"py": "chengwu"
},
{
"city": "巨野",
"district": "菏泽市",
"prov": "山东省",
"py": "juye"
},
{
"city": "郓城",
"district": "菏泽市",
"prov": "山东省",
"py": "yuncheng"
},
{
"city": "鄄城",
"district": "菏泽市",
"prov": "山东省",
"py": "juancheng"
},
{
"city": "东明",
"district": "菏泽市",
"prov": "山东省",
"py": "dongming"
},
{
"city": "郑州",
"district": "郑州市",
"prov": "河南省",
"py": "zhengzhou"
},
{
"city": "中原",
"district": "郑州市",
"prov": "河南省",
"py": "zhongyuan"
},
{
"city": "二七区",
"district": "郑州市",
"prov": "河南省",
"py": "erqiqu"
},
{
"city": "管城",
"district": "郑州市",
"prov": "河南省",
"py": "guancheng"
},
{
"city": "金水",
"district": "郑州市",
"prov": "河南省",
"py": "jinshui"
},
{
"city": "上街",
"district": "郑州市",
"prov": "河南省",
"py": "shangjie"
},
{
"city": "惠济",
"district": "郑州市",
"prov": "河南省",
"py": "huiji"
},
{
"city": "中牟",
"district": "郑州市",
"prov": "河南省",
"py": "zhongmou"
},
{
"city": "巩义",
"district": "郑州市",
"prov": "河南省",
"py": "gongyi"
},
{
"city": "荥阳",
"district": "郑州市",
"prov": "河南省",
"py": "xingyang"
},
{
"city": "新密",
"district": "郑州市",
"prov": "河南省",
"py": "xinmi"
},
{
"city": "新郑",
"district": "郑州市",
"prov": "河南省",
"py": "xinzheng"
},
{
"city": "登封",
"district": "郑州市",
"prov": "河南省",
"py": "dengfeng"
},
{
"city": "开封",
"district": "开封市",
"prov": "河南省",
"py": "kaifeng"
},
{
"city": "龙亭",
"district": "开封市",
"prov": "河南省",
"py": "longting"
},
{
"city": "顺河",
"district": "开封市",
"prov": "河南省",
"py": "shunhe"
},
{
"city": "鼓楼区",
"district": "开封市",
"prov": "河南省",
"py": "gulouqu"
},
{
"city": "禹王台",
"district": "开封市",
"prov": "河南省",
"py": "yuwangtai"
},
{
"city": "祥符",
"district": "开封市",
"prov": "河南省",
"py": "xiangfu"
},
{
"city": "杞县",
"district": "开封市",
"prov": "河南省",
"py": "qixian"
},
{
"city": "通许",
"district": "开封市",
"prov": "河南省",
"py": "tongxu"
},
{
"city": "尉氏",
"district": "开封市",
"prov": "河南省",
"py": "weishi"
},
{
"city": "兰考",
"district": "开封市",
"prov": "河南省",
"py": "lankao"
},
{
"city": "洛阳",
"district": "洛阳市",
"prov": "河南省",
"py": "luoyang"
},
{
"city": "老城区",
"district": "洛阳市",
"prov": "河南省",
"py": "laochengqu"
},
{
"city": "西工",
"district": "洛阳市",
"prov": "河南省",
"py": "xigong"
},
{
"city": "瀍河",
"district": "洛阳市",
"prov": "河南省",
"py": "chanhe"
},
{
"city": "涧西",
"district": "洛阳市",
"prov": "河南省",
"py": "jianxi"
},
{
"city": "吉利",
"district": "洛阳市",
"prov": "河南省",
"py": "jili"
},
{
"city": "洛龙",
"district": "洛阳市",
"prov": "河南省",
"py": "luolong"
},
{
"city": "孟津",
"district": "洛阳市",
"prov": "河南省",
"py": "mengjin"
},
{
"city": "新安",
"district": "洛阳市",
"prov": "河南省",
"py": "xinan"
},
{
"city": "栾川",
"district": "洛阳市",
"prov": "河南省",
"py": "luanchuan"
},
{
"city": "嵩县",
"district": "洛阳市",
"prov": "河南省",
"py": "songxian"
},
{
"city": "汝阳",
"district": "洛阳市",
"prov": "河南省",
"py": "ruyang"
},
{
"city": "宜阳",
"district": "洛阳市",
"prov": "河南省",
"py": "yiyang"
},
{
"city": "洛宁",
"district": "洛阳市",
"prov": "河南省",
"py": "luoning"
},
{
"city": "伊川",
"district": "洛阳市",
"prov": "河南省",
"py": "yichuan"
},
{
"city": "偃师",
"district": "洛阳市",
"prov": "河南省",
"py": "yanshi"
},
{
"city": "平顶山",
"district": "平顶山市",
"prov": "河南省",
"py": "pingdingshan"
},
{
"city": "新华区",
"district": "平顶山市",
"prov": "河南省",
"py": "xinhuaqu"
},
{
"city": "卫东",
"district": "平顶山市",
"prov": "河南省",
"py": "weidong"
},
{
"city": "石龙",
"district": "平顶山市",
"prov": "河南省",
"py": "shilong"
},
{
"city": "湛河",
"district": "平顶山市",
"prov": "河南省",
"py": "zhanhe"
},
{
"city": "宝丰",
"district": "平顶山市",
"prov": "河南省",
"py": "baofeng"
},
{
"city": "叶县",
"district": "平顶山市",
"prov": "河南省",
"py": "yexian"
},
{
"city": "鲁山",
"district": "平顶山市",
"prov": "河南省",
"py": "lushan"
},
{
"city": "郏县",
"district": "平顶山市",
"prov": "河南省",
"py": "jiaxian"
},
{
"city": "舞钢",
"district": "平顶山市",
"prov": "河南省",
"py": "wugang"
},
{
"city": "汝州",
"district": "平顶山市",
"prov": "河南省",
"py": "ruzhou"
},
{
"city": "安阳",
"district": "安阳市",
"prov": "河南省",
"py": "anyang"
},
{
"city": "文峰",
"district": "安阳市",
"prov": "河南省",
"py": "wenfeng"
},
{
"city": "北关",
"district": "安阳市",
"prov": "河南省",
"py": "beiguan"
},
{
"city": "殷都",
"district": "安阳市",
"prov": "河南省",
"py": "yindu"
},
{
"city": "龙安",
"district": "安阳市",
"prov": "河南省",
"py": "longan"
},
{
"city": "安阳县",
"district": "安阳市",
"prov": "河南省",
"py": "anyangxian"
},
{
"city": "汤阴",
"district": "安阳市",
"prov": "河南省",
"py": "tangyin"
},
{
"city": "滑县",
"district": "安阳市",
"prov": "河南省",
"py": "huaxian"
},
{
"city": "内黄",
"district": "安阳市",
"prov": "河南省",
"py": "neihuang"
},
{
"city": "林州",
"district": "安阳市",
"prov": "河南省",
"py": "linzhou"
},
{
"city": "鹤壁",
"district": "鹤壁市",
"prov": "河南省",
"py": "hebi"
},
{
"city": "鹤山区",
"district": "鹤壁市",
"prov": "河南省",
"py": "heshanqu"
},
{
"city": "山城",
"district": "鹤壁市",
"prov": "河南省",
"py": "shancheng"
},
{
"city": "淇滨",
"district": "鹤壁市",
"prov": "河南省",
"py": "qibin"
},
{
"city": "浚县",
"district": "鹤壁市",
"prov": "河南省",
"py": "xunxian"
},
{
"city": "淇县",
"district": "鹤壁市",
"prov": "河南省",
"py": "qixian"
},
{
"city": "新乡",
"district": "新乡市",
"prov": "河南省",
"py": "xinxiang"
},
{
"city": "红旗",
"district": "新乡市",
"prov": "河南省",
"py": "hongqi"
},
{
"city": "卫滨",
"district": "新乡市",
"prov": "河南省",
"py": "weibin"
},
{
"city": "凤泉",
"district": "新乡市",
"prov": "河南省",
"py": "fengquan"
},
{
"city": "牧野",
"district": "新乡市",
"prov": "河南省",
"py": "muye"
},
{
"city": "新乡县",
"district": "新乡市",
"prov": "河南省",
"py": "xinxiangxian"
},
{
"city": "获嘉",
"district": "新乡市",
"prov": "河南省",
"py": "huojia"
},
{
"city": "原阳",
"district": "新乡市",
"prov": "河南省",
"py": "yuanyang"
},
{
"city": "延津",
"district": "新乡市",
"prov": "河南省",
"py": "yanjin"
},
{
"city": "封丘",
"district": "新乡市",
"prov": "河南省",
"py": "fengqiu"
},
{
"city": "长垣",
"district": "新乡市",
"prov": "河南省",
"py": "changyuan"
},
{
"city": "卫辉",
"district": "新乡市",
"prov": "河南省",
"py": "weihui"
},
{
"city": "辉县",
"district": "新乡市",
"prov": "河南省",
"py": "huixian"
},
{
"city": "焦作",
"district": "焦作市",
"prov": "河南省",
"py": "jiaozuo"
},
{
"city": "解放",
"district": "焦作市",
"prov": "河南省",
"py": "jiefang"
},
{
"city": "中站",
"district": "焦作市",
"prov": "河南省",
"py": "zhongzhan"
},
{
"city": "马村",
"district": "焦作市",
"prov": "河南省",
"py": "macun"
},
{
"city": "山阳区",
"district": "焦作市",
"prov": "河南省",
"py": "shanyangqu"
},
{
"city": "修武",
"district": "焦作市",
"prov": "河南省",
"py": "xiuwu"
},
{
"city": "博爱",
"district": "焦作市",
"prov": "河南省",
"py": "boai"
},
{
"city": "武陟",
"district": "焦作市",
"prov": "河南省",
"py": "wuzhi"
},
{
"city": "温县",
"district": "焦作市",
"prov": "河南省",
"py": "wenxian"
},
{
"city": "沁阳",
"district": "焦作市",
"prov": "河南省",
"py": "qinyang"
},
{
"city": "孟州",
"district": "焦作市",
"prov": "河南省",
"py": "mengzhou"
},
{
"city": "濮阳",
"district": "濮阳市",
"prov": "河南省",
"py": "puyang"
},
{
"city": "华龙",
"district": "濮阳市",
"prov": "河南省",
"py": "hualong"
},
{
"city": "清丰",
"district": "濮阳市",
"prov": "河南省",
"py": "qingfeng"
},
{
"city": "南乐",
"district": "濮阳市",
"prov": "河南省",
"py": "nanle"
},
{
"city": "范县",
"district": "濮阳市",
"prov": "河南省",
"py": "fanxian"
},
{
"city": "台前",
"district": "濮阳市",
"prov": "河南省",
"py": "taiqian"
},
{
"city": "濮阳县",
"district": "濮阳市",
"prov": "河南省",
"py": "puyangxian"
},
{
"city": "许昌",
"district": "许昌市",
"prov": "河南省",
"py": "xuchang"
},
{
"city": "魏都",
"district": "许昌市",
"prov": "河南省",
"py": "weidu"
},
{
"city": "建安",
"district": "许昌市",
"prov": "河南省",
"py": "jianan"
},
{
"city": "鄢陵",
"district": "许昌市",
"prov": "河南省",
"py": "yanling"
},
{
"city": "襄城",
"district": "许昌市",
"prov": "河南省",
"py": "xiangcheng"
},
{
"city": "禹州",
"district": "许昌市",
"prov": "河南省",
"py": "yuzhou"
},
{
"city": "长葛",
"district": "许昌市",
"prov": "河南省",
"py": "changge"
},
{
"city": "漯河",
"district": "漯河市",
"prov": "河南省",
"py": "luohe"
},
{
"city": "源汇",
"district": "漯河市",
"prov": "河南省",
"py": "yuanhui"
},
{
"city": "郾城",
"district": "漯河市",
"prov": "河南省",
"py": "yancheng"
},
{
"city": "召陵",
"district": "漯河市",
"prov": "河南省",
"py": "shaoling"
},
{
"city": "舞阳",
"district": "漯河市",
"prov": "河南省",
"py": "wuyang"
},
{
"city": "临颍",
"district": "漯河市",
"prov": "河南省",
"py": "linying"
},
{
"city": "三门峡",
"district": "三门峡市",
"prov": "河南省",
"py": "sanmenxia"
},
{
"city": "湖滨区",
"district": "三门峡市",
"prov": "河南省",
"py": "hubinqu"
},
{
"city": "陕州",
"district": "三门峡市",
"prov": "河南省",
"py": "shanzhou"
},
{
"city": "渑池",
"district": "三门峡市",
"prov": "河南省",
"py": "mianchi"
},
{
"city": "卢氏",
"district": "三门峡市",
"prov": "河南省",
"py": "lushi"
},
{
"city": "义马",
"district": "三门峡市",
"prov": "河南省",
"py": "yima"
},
{
"city": "灵宝",
"district": "三门峡市",
"prov": "河南省",
"py": "lingbao"
},
{
"city": "南阳",
"district": "南阳市",
"prov": "河南省",
"py": "nanyang"
},
{
"city": "宛城",
"district": "南阳市",
"prov": "河南省",
"py": "wancheng"
},
{
"city": "卧龙",
"district": "南阳市",
"prov": "河南省",
"py": "wolong"
},
{
"city": "南召",
"district": "南阳市",
"prov": "河南省",
"py": "nanzhao"
},
{
"city": "方城",
"district": "南阳市",
"prov": "河南省",
"py": "fangcheng"
},
{
"city": "西峡",
"district": "南阳市",
"prov": "河南省",
"py": "xixia"
},
{
"city": "镇平",
"district": "南阳市",
"prov": "河南省",
"py": "zhenping"
},
{
"city": "内乡",
"district": "南阳市",
"prov": "河南省",
"py": "neixiang"
},
{
"city": "淅川",
"district": "南阳市",
"prov": "河南省",
"py": "xichuan"
},
{
"city": "社旗",
"district": "南阳市",
"prov": "河南省",
"py": "sheqi"
},
{
"city": "唐河",
"district": "南阳市",
"prov": "河南省",
"py": "tanghe"
},
{
"city": "新野",
"district": "南阳市",
"prov": "河南省",
"py": "xinye"
},
{
"city": "桐柏",
"district": "南阳市",
"prov": "河南省",
"py": "tongbai"
},
{
"city": "邓州",
"district": "南阳市",
"prov": "河南省",
"py": "dengzhou"
},
{
"city": "商丘",
"district": "商丘市",
"prov": "河南省",
"py": "shangqiu"
},
{
"city": "梁园",
"district": "商丘市",
"prov": "河南省",
"py": "liangyuan"
},
{
"city": "睢阳",
"district": "商丘市",
"prov": "河南省",
"py": "suiyang"
},
{
"city": "民权",
"district": "商丘市",
"prov": "河南省",
"py": "minquan"
},
{
"city": "睢县",
"district": "商丘市",
"prov": "河南省",
"py": "suixian"
},
{
"city": "宁陵",
"district": "商丘市",
"prov": "河南省",
"py": "ningling"
},
{
"city": "柘城",
"district": "商丘市",
"prov": "河南省",
"py": "zhecheng"
},
{
"city": "虞城",
"district": "商丘市",
"prov": "河南省",
"py": "yucheng"
},
{
"city": "夏邑",
"district": "商丘市",
"prov": "河南省",
"py": "xiayi"
},
{
"city": "永城",
"district": "商丘市",
"prov": "河南省",
"py": "yongcheng"
},
{
"city": "信阳",
"district": "信阳市",
"prov": "河南省",
"py": "xinyang"
},
{
"city": "浉河",
"district": "信阳市",
"prov": "河南省",
"py": "shihe"
},
{
"city": "平桥",
"district": "信阳市",
"prov": "河南省",
"py": "pingqiao"
},
{
"city": "罗山",
"district": "信阳市",
"prov": "河南省",
"py": "luoshan"
},
{
"city": "光山",
"district": "信阳市",
"prov": "河南省",
"py": "guangshan"
},
{
"city": "新县",
"district": "信阳市",
"prov": "河南省",
"py": "xinxian"
},
{
"city": "商城",
"district": "信阳市",
"prov": "河南省",
"py": "shangcheng"
},
{
"city": "固始",
"district": "信阳市",
"prov": "河南省",
"py": "gushi"
},
{
"city": "潢川",
"district": "信阳市",
"prov": "河南省",
"py": "huangchuan"
},
{
"city": "淮滨",
"district": "信阳市",
"prov": "河南省",
"py": "huaibin"
},
{
"city": "息县",
"district": "信阳市",
"prov": "河南省",
"py": "xixian"
},
{
"city": "周口",
"district": "周口市",
"prov": "河南省",
"py": "zhoukou"
},
{
"city": "川汇",
"district": "周口市",
"prov": "河南省",
"py": "chuanhui"
},
{
"city": "扶沟",
"district": "周口市",
"prov": "河南省",
"py": "fugou"
},
{
"city": "西华",
"district": "周口市",
"prov": "河南省",
"py": "xihua"
},
{
"city": "商水",
"district": "周口市",
"prov": "河南省",
"py": "shangshui"
},
{
"city": "沈丘",
"district": "周口市",
"prov": "河南省",
"py": "shenqiu"
},
{
"city": "郸城",
"district": "周口市",
"prov": "河南省",
"py": "dancheng"
},
{
"city": "淮阳",
"district": "周口市",
"prov": "河南省",
"py": "huaiyang"
},
{
"city": "太康",
"district": "周口市",
"prov": "河南省",
"py": "taikang"
},
{
"city": "鹿邑",
"district": "周口市",
"prov": "河南省",
"py": "luyi"
},
{
"city": "项城",
"district": "周口市",
"prov": "河南省",
"py": "xiangcheng"
},
{
"city": "驻马店",
"district": "驻马店市",
"prov": "河南省",
"py": "zhumadian"
},
{
"city": "驿城",
"district": "驻马店市",
"prov": "河南省",
"py": "yicheng"
},
{
"city": "西平",
"district": "驻马店市",
"prov": "河南省",
"py": "xiping"
},
{
"city": "上蔡",
"district": "驻马店市",
"prov": "河南省",
"py": "shangcai"
},
{
"city": "平舆",
"district": "驻马店市",
"prov": "河南省",
"py": "pingyu"
},
{
"city": "正阳",
"district": "驻马店市",
"prov": "河南省",
"py": "zhengyang"
},
{
"city": "确山",
"district": "驻马店市",
"prov": "河南省",
"py": "queshan"
},
{
"city": "泌阳",
"district": "驻马店市",
"prov": "河南省",
"py": "biyang"
},
{
"city": "汝南",
"district": "驻马店市",
"prov": "河南省",
"py": "runan"
},
{
"city": "遂平",
"district": "驻马店市",
"prov": "河南省",
"py": "suiping"
},
{
"city": "新蔡",
"district": "驻马店市",
"prov": "河南省",
"py": "xincai"
},
{
"city": "济源",
"district": "济源市",
"prov": "河南省",
"py": "jiyuan"
},
{
"city": "武汉",
"district": "武汉市",
"prov": "湖北省",
"py": "wuhan"
},
{
"city": "江岸",
"district": "武汉市",
"prov": "湖北省",
"py": "jiangan"
},
{
"city": "江汉",
"district": "武汉市",
"prov": "湖北省",
"py": "jianghan"
},
{
"city": "硚口",
"district": "武汉市",
"prov": "湖北省",
"py": "qiaokou"
},
{
"city": "汉阳",
"district": "武汉市",
"prov": "湖北省",
"py": "hanyang"
},
{
"city": "武昌",
"district": "武汉市",
"prov": "湖北省",
"py": "wuchang"
},
{
"city": "青山",
"district": "武汉市",
"prov": "湖北省",
"py": "qingshan"
},
{
"city": "洪山",
"district": "武汉市",
"prov": "湖北省",
"py": "honghu"
},
{
"city": "东西湖",
"district": "武汉市",
"prov": "湖北省",
"py": "dongxihu"
},
{
"city": "汉南",
"district": "武汉市",
"prov": "湖北省",
"py": "hannan"
},
{
"city": "蔡甸",
"district": "武汉市",
"prov": "湖北省",
"py": "caidian"
},
{
"city": "江夏",
"district": "武汉市",
"prov": "湖北省",
"py": "jiangxia"
},
{
"city": "黄陂",
"district": "武汉市",
"prov": "湖北省",
"py": "huangpi"
},
{
"city": "新洲",
"district": "武汉市",
"prov": "湖北省",
"py": "xinzhou"
},
{
"city": "黄石",
"district": "黄石市",
"prov": "湖北省",
"py": "huangshi"
},
{
"city": "黄石港",
"district": "黄石市",
"prov": "湖北省",
"py": "huangshigang"
},
{
"city": "西塞山",
"district": "黄石市",
"prov": "湖北省",
"py": "xisaishan"
},
{
"city": "下陆",
"district": "黄石市",
"prov": "湖北省",
"py": "xialu"
},
{
"city": "铁山",
"district": "黄石市",
"prov": "湖北省",
"py": "tieshan"
},
{
"city": "阳新",
"district": "黄石市",
"prov": "湖北省",
"py": "yangxin"
},
{
"city": "大冶",
"district": "黄石市",
"prov": "湖北省",
"py": "daye"
},
{
"city": "十堰",
"district": "十堰市",
"prov": "湖北省",
"py": "shiyan"
},
{
"city": "茅箭",
"district": "十堰市",
"prov": "湖北省",
"py": "maojian"
},
{
"city": "张湾",
"district": "十堰市",
"prov": "湖北省",
"py": "zhangwan"
},
{
"city": "郧阳",
"district": "十堰市",
"prov": "湖北省",
"py": "yunyang"
},
{
"city": "郧西",
"district": "十堰市",
"prov": "湖北省",
"py": "yunxi"
},
{
"city": "竹山",
"district": "十堰市",
"prov": "湖北省",
"py": "zhushan"
},
{
"city": "竹溪",
"district": "十堰市",
"prov": "湖北省",
"py": "zhuxi"
},
{
"city": "房县",
"district": "十堰市",
"prov": "湖北省",
"py": "fangxian"
},
{
"city": "丹江口",
"district": "十堰市",
"prov": "湖北省",
"py": "danjiangkou"
},
{
"city": "宜昌",
"district": "宜昌市",
"prov": "湖北省",
"py": "yichang"
},
{
"city": "西陵",
"district": "宜昌市",
"prov": "湖北省",
"py": "xiling"
},
{
"city": "伍家岗",
"district": "宜昌市",
"prov": "湖北省",
"py": "wujiagang"
},
{
"city": "点军",
"district": "宜昌市",
"prov": "湖北省",
"py": "dianjun"
},
{
"city": "猇亭",
"district": "宜昌市",
"prov": "湖北省",
"py": "xiaoting"
},
{
"city": "夷陵",
"district": "宜昌市",
"prov": "湖北省",
"py": "yiling"
},
{
"city": "远安",
"district": "宜昌市",
"prov": "湖北省",
"py": "yuanan"
},
{
"city": "兴山",
"district": "宜昌市",
"prov": "湖北省",
"py": "xingshan"
},
{
"city": "秭归",
"district": "宜昌市",
"prov": "湖北省",
"py": "zigui"
},
{
"city": "长阳",
"district": "宜昌市",
"prov": "湖北省",
"py": "changyang"
},
{
"city": "五峰",
"district": "宜昌市",
"prov": "湖北省",
"py": "wufeng"
},
{
"city": "宜都",
"district": "宜昌市",
"prov": "湖北省",
"py": "yidu"
},
{
"city": "当阳",
"district": "宜昌市",
"prov": "湖北省",
"py": "dangyang"
},
{
"city": "枝江",
"district": "宜昌市",
"prov": "湖北省",
"py": "zhijiang"
},
{
"city": "襄阳",
"district": "襄阳市",
"prov": "湖北省",
"py": "xiangyang"
},
{
"city": "襄城区",
"district": "襄阳市",
"prov": "湖北省",
"py": "xiangchengqu"
},
{
"city": "樊城",
"district": "襄阳市",
"prov": "湖北省",
"py": "fancheng"
},
{
"city": "襄州",
"district": "襄阳市",
"prov": "湖北省",
"py": "xiangzhou"
},
{
"city": "南漳",
"district": "襄阳市",
"prov": "湖北省",
"py": "nanzhang"
},
{
"city": "谷城",
"district": "襄阳市",
"prov": "湖北省",
"py": "gucheng"
},
{
"city": "保康",
"district": "襄阳市",
"prov": "湖北省",
"py": "baokang"
},
{
"city": "老河口",
"district": "襄阳市",
"prov": "湖北省",
"py": "laohekou"
},
{
"city": "枣阳",
"district": "襄阳市",
"prov": "湖北省",
"py": "zaoyang"
},
{
"city": "宜城",
"district": "襄阳市",
"prov": "湖北省",
"py": "yicheng"
},
{
"city": "鄂州",
"district": "鄂州市",
"prov": "湖北省",
"py": "ezhou"
},
{
"city": "梁子湖",
"district": "鄂州市",
"prov": "湖北省",
"py": "liangzihu"
},
{
"city": "华容区",
"district": "鄂州市",
"prov": "湖北省",
"py": "huarongqu"
},
{
"city": "鄂城",
"district": "鄂州市",
"prov": "湖北省",
"py": "echeng"
},
{
"city": "荆门",
"district": "荆门市",
"prov": "湖北省",
"py": "jingmen"
},
{
"city": "东宝",
"district": "荆门市",
"prov": "湖北省",
"py": "dongbao"
},
{
"city": "掇刀",
"district": "荆门市",
"prov": "湖北省",
"py": "duodao"
},
{
"city": "沙洋",
"district": "荆门市",
"prov": "湖北省",
"py": "shayang"
},
{
"city": "钟祥",
"district": "荆门市",
"prov": "湖北省",
"py": "zhongxiang"
},
{
"city": "京山",
"district": "荆门市",
"prov": "湖北省",
"py": "jingshan"
},
{
"city": "孝感",
"district": "孝感市",
"prov": "湖北省",
"py": "xiaogan"
},
{
"city": "孝南",
"district": "孝感市",
"prov": "湖北省",
"py": "xiaonan"
},
{
"city": "孝昌",
"district": "孝感市",
"prov": "湖北省",
"py": "xiaochang"
},
{
"city": "大悟",
"district": "孝感市",
"prov": "湖北省",
"py": "dawu"
},
{
"city": "云梦",
"district": "孝感市",
"prov": "湖北省",
"py": "yunmeng"
},
{
"city": "应城",
"district": "孝感市",
"prov": "湖北省",
"py": "yingcheng"
},
{
"city": "安陆",
"district": "孝感市",
"prov": "湖北省",
"py": "anlu"
},
{
"city": "汉川",
"district": "孝感市",
"prov": "湖北省",
"py": "hanchuan"
},
{
"city": "荆州",
"district": "荆州市",
"prov": "湖北省",
"py": "jingzhou"
},
{
"city": "沙市",
"district": "荆州市",
"prov": "湖北省",
"py": "shashi"
},
{
"city": "荆州区",
"district": "荆州市",
"prov": "湖北省",
"py": "jingzhouqu"
},
{
"city": "公安",
"district": "荆州市",
"prov": "湖北省",
"py": "gongan"
},
{
"city": "监利",
"district": "荆州市",
"prov": "湖北省",
"py": "jianli"
},
{
"city": "江陵",
"district": "荆州市",
"prov": "湖北省",
"py": "jiangling"
},
{
"city": "石首",
"district": "荆州市",
"prov": "湖北省",
"py": "shishou"
},
{
"city": "洪湖",
"district": "荆州市",
"prov": "湖北省",
"py": "honghu"
},
{
"city": "松滋",
"district": "荆州市",
"prov": "湖北省",
"py": "songzi"
},
{
"city": "黄冈",
"district": "黄冈市",
"prov": "湖北省",
"py": "huanggang"
},
{
"city": "黄州",
"district": "黄冈市",
"prov": "湖北省",
"py": "huangzhou"
},
{
"city": "团风",
"district": "黄冈市",
"prov": "湖北省",
"py": "tuanfeng"
},
{
"city": "红安",
"district": "黄冈市",
"prov": "湖北省",
"py": "hongan"
},
{
"city": "罗田",
"district": "黄冈市",
"prov": "湖北省",
"py": "luotian"
},
{
"city": "英山",
"district": "黄冈市",
"prov": "湖北省",
"py": "yingshan"
},
{
"city": "浠水",
"district": "黄冈市",
"prov": "湖北省",
"py": "xishui"
},
{
"city": "蕲春",
"district": "黄冈市",
"prov": "湖北省",
"py": "qichun"
},
{
"city": "黄梅",
"district": "黄冈市",
"prov": "湖北省",
"py": "huangmei"
},
{
"city": "麻城",
"district": "黄冈市",
"prov": "湖北省",
"py": "macheng"
},
{
"city": "武穴",
"district": "黄冈市",
"prov": "湖北省",
"py": "wuxue"
},
{
"city": "咸宁",
"district": "咸宁市",
"prov": "湖北省",
"py": "xianning"
},
{
"city": "咸安",
"district": "咸宁市",
"prov": "湖北省",
"py": "xianan"
},
{
"city": "嘉鱼",
"district": "咸宁市",
"prov": "湖北省",
"py": "jiayu"
},
{
"city": "通城",
"district": "咸宁市",
"prov": "湖北省",
"py": "tongcheng"
},
{
"city": "崇阳",
"district": "咸宁市",
"prov": "湖北省",
"py": "chongyang"
},
{
"city": "通山",
"district": "咸宁市",
"prov": "湖北省",
"py": "tongshan"
},
{
"city": "赤壁",
"district": "咸宁市",
"prov": "湖北省",
"py": "chibi"
},
{
"city": "随州",
"district": "随州市",
"prov": "湖北省",
"py": "suizhou"
},
{
"city": "曾都",
"district": "随州市",
"prov": "湖北省",
"py": "zengdu"
},
{
"city": "随县",
"district": "随州市",
"prov": "湖北省",
"py": "suixian"
},
{
"city": "广水",
"district": "随州市",
"prov": "湖北省",
"py": "guangshui"
},
{
"city": "恩施",
"district": "恩施土家族苗族自治州",
"prov": "湖北省",
"py": "enshi"
},
{
"city": "恩施市",
"district": "恩施土家族苗族自治州",
"prov": "湖北省",
"py": "enshishi"
},
{
"city": "利川",
"district": "恩施土家族苗族自治州",
"prov": "湖北省",
"py": "lichuan"
},
{
"city": "建始",
"district": "恩施土家族苗族自治州",
"prov": "湖北省",
"py": "jianshi"
},
{
"city": "巴东",
"district": "恩施土家族苗族自治州",
"prov": "湖北省",
"py": "badong"
},
{
"city": "宣恩",
"district": "恩施土家族苗族自治州",
"prov": "湖北省",
"py": "xuanen"
},
{
"city": "咸丰",
"district": "恩施土家族苗族自治州",
"prov": "湖北省",
"py": "xianfeng"
},
{
"city": "来凤",
"district": "恩施土家族苗族自治州",
"prov": "湖北省",
"py": "laifeng"
},
{
"city": "鹤峰",
"district": "恩施土家族苗族自治州",
"prov": "湖北省",
"py": "hefeng"
},
{
"city": "仙桃",
"district": "仙桃市",
"prov": "湖北省",
"py": "xiantao"
},
{
"city": "潜江",
"district": "潜江市",
"prov": "湖北省",
"py": "qianjiang"
},
{
"city": "天门",
"district": "天门市",
"prov": "湖北省",
"py": "tianmen"
},
{
"city": "神农架",
"district": "神农架林区",
"prov": "湖北省",
"py": "shennongjia"
},
{
"city": "长沙",
"district": "长沙市",
"prov": "湖南省",
"py": "changsha"
},
{
"city": "芙蓉",
"district": "长沙市",
"prov": "湖南省",
"py": "furong"
},
{
"city": "天心",
"district": "长沙市",
"prov": "湖南省",
"py": "tianxin"
},
{
"city": "岳麓",
"district": "长沙市",
"prov": "湖南省",
"py": "yuelu"
},
{
"city": "开福",
"district": "长沙市",
"prov": "湖南省",
"py": "kaifu"
},
{
"city": "雨花区",
"district": "长沙市",
"prov": "湖南省",
"py": "yuhuaqu"
},
{
"city": "望城",
"district": "长沙市",
"prov": "湖南省",
"py": "wangcheng"
},
{
"city": "长沙县",
"district": "长沙市",
"prov": "湖南省",
"py": "changshaxian"
},
{
"city": "浏阳",
"district": "长沙市",
"prov": "湖南省",
"py": "liuyang"
},
{
"city": "宁乡",
"district": "长沙市",
"prov": "湖南省",
"py": "ningxiang"
},
{
"city": "株洲",
"district": "株洲市",
"prov": "湖南省",
"py": "zhuzhou"
},
{
"city": "荷塘",
"district": "株洲市",
"prov": "湖南省",
"py": "hetang"
},
{
"city": "芦淞",
"district": "株洲市",
"prov": "湖南省",
"py": "lusong"
},
{
"city": "石峰",
"district": "株洲市",
"prov": "湖南省",
"py": "shifeng"
},
{
"city": "天元",
"district": "株洲市",
"prov": "湖南省",
"py": "tianyuan"
},
{
"city": "渌口",
"district": "株洲市",
"prov": "湖南省",
"py": "lukou"
},
{
"city": "攸县",
"district": "株洲市",
"prov": "湖南省",
"py": "youxian"
},
{
"city": "茶陵",
"district": "株洲市",
"prov": "湖南省",
"py": "chaling"
},
{
"city": "炎陵",
"district": "株洲市",
"prov": "湖南省",
"py": "yanling"
},
{
"city": "醴陵",
"district": "株洲市",
"prov": "湖南省",
"py": "liling"
},
{
"city": "湘潭",
"district": "湘潭市",
"prov": "湖南省",
"py": "xiangtan"
},
{
"city": "雨湖",
"district": "湘潭市",
"prov": "湖南省",
"py": "yuhu"
},
{
"city": "岳塘",
"district": "湘潭市",
"prov": "湖南省",
"py": "yuetang"
},
{
"city": "湘潭县",
"district": "湘潭市",
"prov": "湖南省",
"py": "xiangtanxian"
},
{
"city": "湘乡",
"district": "湘潭市",
"prov": "湖南省",
"py": "xiangxiang"
},
{
"city": "韶山",
"district": "湘潭市",
"prov": "湖南省",
"py": "shaoshan"
},
{
"city": "衡阳",
"district": "衡阳市",
"prov": "湖南省",
"py": "hengyang"
},
{
"city": "珠晖",
"district": "衡阳市",
"prov": "湖南省",
"py": "zhuhui"
},
{
"city": "雁峰",
"district": "衡阳市",
"prov": "湖南省",
"py": "yanfeng"
},
{
"city": "石鼓",
"district": "衡阳市",
"prov": "湖南省",
"py": "shigu"
},
{
"city": "蒸湘",
"district": "衡阳市",
"prov": "湖南省",
"py": "zhengxiang"
},
{
"city": "南岳",
"district": "衡阳市",
"prov": "湖南省",
"py": "nanyue"
},
{
"city": "衡阳县",
"district": "衡阳市",
"prov": "湖南省",
"py": "hengyangxian"
},
{
"city": "衡南",
"district": "衡阳市",
"prov": "湖南省",
"py": "hengnan"
},
{
"city": "衡山",
"district": "衡阳市",
"prov": "湖南省",
"py": "hengshan"
},
{
"city": "衡东",
"district": "衡阳市",
"prov": "湖南省",
"py": "hengdong"
},
{
"city": "祁东",
"district": "衡阳市",
"prov": "湖南省",
"py": "qidong"
},
{
"city": "耒阳",
"district": "衡阳市",
"prov": "湖南省",
"py": "leiyang"
},
{
"city": "常宁",
"district": "衡阳市",
"prov": "湖南省",
"py": "changning"
},
{
"city": "邵阳",
"district": "邵阳市",
"prov": "湖南省",
"py": "shaoyang"
},
{
"city": "双清",
"district": "邵阳市",
"prov": "湖南省",
"py": "shuangqing"
},
{
"city": "大祥",
"district": "邵阳市",
"prov": "湖南省",
"py": "daxiang"
},
{
"city": "北塔",
"district": "邵阳市",
"prov": "湖南省",
"py": "beita"
},
{
"city": "邵东",
"district": "邵阳市",
"prov": "湖南省",
"py": "shaodong"
},
{
"city": "新邵",
"district": "邵阳市",
"prov": "湖南省",
"py": "xinshao"
},
{
"city": "邵阳县",
"district": "邵阳市",
"prov": "湖南省",
"py": "shaoyangxian"
},
{
"city": "隆回",
"district": "邵阳市",
"prov": "湖南省",
"py": "longhui"
},
{
"city": "洞口",
"district": "邵阳市",
"prov": "湖南省",
"py": "dongkou"
},
{
"city": "绥宁",
"district": "邵阳市",
"prov": "湖南省",
"py": "suining"
},
{
"city": "新宁",
"district": "邵阳市",
"prov": "湖南省",
"py": "xinning"
},
{
"city": "城步",
"district": "邵阳市",
"prov": "湖南省",
"py": "chengbu"
},
{
"city": "武冈",
"district": "邵阳市",
"prov": "湖南省",
"py": "wugang"
},
{
"city": "岳阳",
"district": "岳阳市",
"prov": "湖南省",
"py": "yueyang"
},
{
"city": "岳阳楼区",
"district": "岳阳市",
"prov": "湖南省",
"py": "yueyanglouqu"
},
{
"city": "云溪",
"district": "岳阳市",
"prov": "湖南省",
"py": "yunxi"
},
{
"city": "君山",
"district": "岳阳市",
"prov": "湖南省",
"py": "junshan"
},
{
"city": "岳阳县",
"district": "岳阳市",
"prov": "湖南省",
"py": "yueyangxian"
},
{
"city": "华容",
"district": "岳阳市",
"prov": "湖南省",
"py": "huarong"
},
{
"city": "湘阴",
"district": "岳阳市",
"prov": "湖南省",
"py": "xiangyin"
},
{
"city": "平江",
"district": "岳阳市",
"prov": "湖南省",
"py": "pingjiang"
},
{
"city": "汨罗",
"district": "岳阳市",
"prov": "湖南省",
"py": "miluo"
},
{
"city": "临湘",
"district": "岳阳市",
"prov": "湖南省",
"py": "linxiang"
},
{
"city": "常德",
"district": "常德市",
"prov": "湖南省",
"py": "changde"
},
{
"city": "武陵",
"district": "常德市",
"prov": "湖南省",
"py": "wuling"
},
{
"city": "鼎城",
"district": "常德市",
"prov": "湖南省",
"py": "dingcheng"
},
{
"city": "安乡",
"district": "常德市",
"prov": "湖南省",
"py": "anxiang"
},
{
"city": "汉寿",
"district": "常德市",
"prov": "湖南省",
"py": "hanshou"
},
{
"city": "澧县",
"district": "常德市",
"prov": "湖南省",
"py": "lixian"
},
{
"city": "临澧",
"district": "常德市",
"prov": "湖南省",
"py": "linli"
},
{
"city": "桃源",
"district": "常德市",
"prov": "湖南省",
"py": "taoyuan"
},
{
"city": "石门",
"district": "常德市",
"prov": "湖南省",
"py": "shimen"
},
{
"city": "津市",
"district": "常德市",
"prov": "湖南省",
"py": "jinshi"
},
{
"city": "张家界",
"district": "张家界市",
"prov": "湖南省",
"py": "zhangjiajie"
},
{
"city": "永定",
"district": "张家界市",
"prov": "湖南省",
"py": "yongding"
},
{
"city": "武陵源",
"district": "张家界市",
"prov": "湖南省",
"py": "wulingyuan"
},
{
"city": "慈利",
"district": "张家界市",
"prov": "湖南省",
"py": "cili"
},
{
"city": "桑植",
"district": "张家界市",
"prov": "湖南省",
"py": "sangzhi"
},
{
"city": "益阳",
"district": "益阳市",
"prov": "湖南省",
"py": "yiyang"
},
{
"city": "资阳区",
"district": "益阳市",
"prov": "湖南省",
"py": "ziyangqu"
},
{
"city": "赫山",
"district": "益阳市",
"prov": "湖南省",
"py": "heshan"
},
{
"city": "南县",
"district": "益阳市",
"prov": "湖南省",
"py": "nanxian"
},
{
"city": "桃江",
"district": "益阳市",
"prov": "湖南省",
"py": "taojiang"
},
{
"city": "安化",
"district": "益阳市",
"prov": "湖南省",
"py": "anhua"
},
{
"city": "沅江",
"district": "益阳市",
"prov": "湖南省",
"py": "yuanjiang"
},
{
"city": "郴州",
"district": "郴州市",
"prov": "湖南省",
"py": "chenzhou"
},
{
"city": "北湖",
"district": "郴州市",
"prov": "湖南省",
"py": "beihu"
},
{
"city": "苏仙",
"district": "郴州市",
"prov": "湖南省",
"py": "suxian"
},
{
"city": "桂阳",
"district": "郴州市",
"prov": "湖南省",
"py": "guiyang"
},
{
"city": "宜章",
"district": "郴州市",
"prov": "湖南省",
"py": "yizhang"
},
{
"city": "永兴",
"district": "郴州市",
"prov": "湖南省",
"py": "yongxing"
},
{
"city": "嘉禾",
"district": "郴州市",
"prov": "湖南省",
"py": "jiahe"
},
{
"city": "临武",
"district": "郴州市",
"prov": "湖南省",
"py": "linwu"
},
{
"city": "汝城",
"district": "郴州市",
"prov": "湖南省",
"py": "rucheng"
},
{
"city": "桂东",
"district": "郴州市",
"prov": "湖南省",
"py": "guidong"
},
{
"city": "安仁",
"district": "郴州市",
"prov": "湖南省",
"py": "anren"
},
{
"city": "资兴",
"district": "郴州市",
"prov": "湖南省",
"py": "zixing"
},
{
"city": "永州",
"district": "永州市",
"prov": "湖南省",
"py": "yongzhou"
},
{
"city": "零陵",
"district": "永州市",
"prov": "湖南省",
"py": "lingling"
},
{
"city": "冷水滩",
"district": "永州市",
"prov": "湖南省",
"py": "lengshuitan"
},
{
"city": "祁阳",
"district": "永州市",
"prov": "湖南省",
"py": "qiyang"
},
{
"city": "东安",
"district": "永州市",
"prov": "湖南省",
"py": "dongan"
},
{
"city": "双牌",
"district": "永州市",
"prov": "湖南省",
"py": "shuangpai"
},
{
"city": "道县",
"district": "永州市",
"prov": "湖南省",
"py": "daoxian"
},
{
"city": "江永",
"district": "永州市",
"prov": "湖南省",
"py": "jiangyong"
},
{
"city": "宁远",
"district": "永州市",
"prov": "湖南省",
"py": "ningyuan"
},
{
"city": "蓝山",
"district": "永州市",
"prov": "湖南省",
"py": "lanshan"
},
{
"city": "新田",
"district": "永州市",
"prov": "湖南省",
"py": "xintian"
},
{
"city": "江华",
"district": "永州市",
"prov": "湖南省",
"py": "jianghua"
},
{
"city": "怀化",
"district": "怀化市",
"prov": "湖南省",
"py": "huaihua"
},
{
"city": "鹤城",
"district": "怀化市",
"prov": "湖南省",
"py": "hecheng"
},
{
"city": "中方",
"district": "怀化市",
"prov": "湖南省",
"py": "zhongfang"
},
{
"city": "沅陵",
"district": "怀化市",
"prov": "湖南省",
"py": "yuanling"
},
{
"city": "辰溪",
"district": "怀化市",
"prov": "湖南省",
"py": "chenxi"
},
{
"city": "溆浦",
"district": "怀化市",
"prov": "湖南省",
"py": "xupu"
},
{
"city": "会同",
"district": "怀化市",
"prov": "湖南省",
"py": "huitong"
},
{
"city": "麻阳",
"district": "怀化市",
"prov": "湖南省",
"py": "mayang"
},
{
"city": "新晃",
"district": "怀化市",
"prov": "湖南省",
"py": "xinhuang"
},
{
"city": "芷江",
"district": "怀化市",
"prov": "湖南省",
"py": "zhijiang"
},
{
"city": "靖州",
"district": "怀化市",
"prov": "湖南省",
"py": "jingzhou"
},
{
"city": "通道",
"district": "怀化市",
"prov": "湖南省",
"py": "tongdao"
},
{
"city": "洪江",
"district": "怀化市",
"prov": "湖南省",
"py": "hongjiang"
},
{
"city": "娄底",
"district": "娄底市",
"prov": "湖南省",
"py": "loudi"
},
{
"city": "娄星",
"district": "娄底市",
"prov": "湖南省",
"py": "louxing"
},
{
"city": "双峰",
"district": "娄底市",
"prov": "湖南省",
"py": "shuangfeng"
},
{
"city": "新化",
"district": "娄底市",
"prov": "湖南省",
"py": "xinhua"
},
{
"city": "冷水江",
"district": "娄底市",
"prov": "湖南省",
"py": "lengshuijiang"
},
{
"city": "涟源",
"district": "娄底市",
"prov": "湖南省",
"py": "lianyuan"
},
{
"city": "湘西",
"district": "湘西土家族苗族自治州",
"prov": "湖南省",
"py": "xiangxi"
},
{
"city": "吉首",
"district": "湘西土家族苗族自治州",
"prov": "湖南省",
"py": "jishou"
},
{
"city": "泸溪",
"district": "湘西土家族苗族自治州",
"prov": "湖南省",
"py": "luxi"
},
{
"city": "凤凰",
"district": "湘西土家族苗族自治州",
"prov": "湖南省",
"py": "fenghuang"
},
{
"city": "花垣",
"district": "湘西土家族苗族自治州",
"prov": "湖南省",
"py": "huayuan"
},
{
"city": "保靖",
"district": "湘西土家族苗族自治州",
"prov": "湖南省",
"py": "baojing"
},
{
"city": "古丈",
"district": "湘西土家族苗族自治州",
"prov": "湖南省",
"py": "guzhang"
},
{
"city": "永顺",
"district": "湘西土家族苗族自治州",
"prov": "湖南省",
"py": "yongshun"
},
{
"city": "龙山",
"district": "湘西土家族苗族自治州",
"prov": "湖南省",
"py": "longshan"
},
{
"city": "广州",
"district": "广州市",
"prov": "广东省",
"py": "guangzhou"
},
{
"city": "荔湾",
"district": "广州市",
"prov": "广东省",
"py": "liwan"
},
{
"city": "越秀",
"district": "广州市",
"prov": "广东省",
"py": "yuexiu"
},
{
"city": "海珠",
"district": "广州市",
"prov": "广东省",
"py": "haizhu"
},
{
"city": "天河",
"district": "广州市",
"prov": "广东省",
"py": "tianhe"
},
{
"city": "白云",
"district": "广州市",
"prov": "广东省",
"py": "baiyun"
},
{
"city": "黄埔",
"district": "广州市",
"prov": "广东省",
"py": "huangpu"
},
{
"city": "番禺",
"district": "广州市",
"prov": "广东省",
"py": "panyu"
},
{
"city": "花都",
"district": "广州市",
"prov": "广东省",
"py": "huadu"
},
{
"city": "南沙区",
"district": "广州市",
"prov": "广东省",
"py": "nanshaqu"
},
{
"city": "从化",
"district": "广州市",
"prov": "广东省",
"py": "conghua"
},
{
"city": "增城",
"district": "广州市",
"prov": "广东省",
"py": "zengcheng"
},
{
"city": "韶关",
"district": "韶关市",
"prov": "广东省",
"py": "shaoguan"
},
{
"city": "武江",
"district": "韶关市",
"prov": "广东省",
"py": "wujiang"
},
{
"city": "浈江",
"district": "韶关市",
"prov": "广东省",
"py": "zhenjiang"
},
{
"city": "曲江",
"district": "韶关市",
"prov": "广东省",
"py": "qujiang"
},
{
"city": "始兴",
"district": "韶关市",
"prov": "广东省",
"py": "shixing"
},
{
"city": "仁化",
"district": "韶关市",
"prov": "广东省",
"py": "renhua"
},
{
"city": "翁源",
"district": "韶关市",
"prov": "广东省",
"py": "wengyuan"
},
{
"city": "乳源",
"district": "韶关市",
"prov": "广东省",
"py": "ruyuan"
},
{
"city": "新丰",
"district": "韶关市",
"prov": "广东省",
"py": "xinfeng"
},
{
"city": "乐昌",
"district": "韶关市",
"prov": "广东省",
"py": "lechang"
},
{
"city": "南雄",
"district": "韶关市",
"prov": "广东省",
"py": "nanxiong"
},
{
"city": "深圳",
"district": "深圳市",
"prov": "广东省",
"py": "shenzhen"
},
{
"city": "罗湖",
"district": "深圳市",
"prov": "广东省",
"py": "luohu"
},
{
"city": "福田",
"district": "深圳市",
"prov": "广东省",
"py": "futian"
},
{
"city": "南山",
"district": "深圳市",
"prov": "广东省",
"py": "nanshan"
},
{
"city": "宝安",
"district": "深圳市",
"prov": "广东省",
"py": "baoan"
},
{
"city": "龙岗",
"district": "深圳市",
"prov": "广东省",
"py": "longgang"
},
{
"city": "盐田",
"district": "深圳市",
"prov": "广东省",
"py": "yantian"
},
{
"city": "龙华",
"district": "深圳市",
"prov": "广东省",
"py": "longhua"
},
{
"city": "坪山",
"district": "深圳市",
"prov": "广东省",
"py": "pingshan"
},
{
"city": "光明",
"district": "深圳市",
"prov": "广东省",
"py": "guangming"
},
{
"city": "珠海",
"district": "珠海市",
"prov": "广东省",
"py": "zhuhai"
},
{
"city": "香洲",
"district": "珠海市",
"prov": "广东省",
"py": "xiangzhou"
},
{
"city": "斗门",
"district": "珠海市",
"prov": "广东省",
"py": "doumen"
},
{
"city": "金湾",
"district": "珠海市",
"prov": "广东省",
"py": "jinwan"
},
{
"city": "汕头",
"district": "汕头市",
"prov": "广东省",
"py": "shantou"
},
{
"city": "龙湖",
"district": "汕头市",
"prov": "广东省",
"py": "longhu"
},
{
"city": "金平区",
"district": "汕头市",
"prov": "广东省",
"py": "jinpingqu"
},
{
"city": "濠江",
"district": "汕头市",
"prov": "广东省",
"py": "haojiang"
},
{
"city": "潮阳",
"district": "汕头市",
"prov": "广东省",
"py": "chaoyang"
},
{
"city": "潮南",
"district": "汕头市",
"prov": "广东省",
"py": "chaonan"
},
{
"city": "澄海",
"district": "汕头市",
"prov": "广东省",
"py": "chenghai"
},
{
"city": "南澳",
"district": "汕头市",
"prov": "广东省",
"py": "nanao"
},
{
"city": "佛山",
"district": "佛山市",
"prov": "广东省",
"py": "foshan"
},
{
"city": "禅城",
"district": "佛山市",
"prov": "广东省",
"py": "chancheng"
},
{
"city": "南海区",
"district": "佛山市",
"prov": "广东省",
"py": "nanhaiqu"
},
{
"city": "顺德",
"district": "佛山市",
"prov": "广东省",
"py": "shunde"
},
{
"city": "三水",
"district": "佛山市",
"prov": "广东省",
"py": "sanshui"
},
{
"city": "高明",
"district": "佛山市",
"prov": "广东省",
"py": "gaoming"
},
{
"city": "江门",
"district": "江门市",
"prov": "广东省",
"py": "jiangmen"
},
{
"city": "蓬江",
"district": "江门市",
"prov": "广东省",
"py": "pengjiang"
},
{
"city": "江海",
"district": "江门市",
"prov": "广东省",
"py": "jianghai"
},
{
"city": "新会",
"district": "江门市",
"prov": "广东省",
"py": "xinhui"
},
{
"city": "台山",
"district": "江门市",
"prov": "广东省",
"py": "taishan"
},
{
"city": "开平",
"district": "江门市",
"prov": "广东省",
"py": "kaiping"
},
{
"city": "鹤山",
"district": "江门市",
"prov": "广东省",
"py": "heshan"
},
{
"city": "恩平",
"district": "江门市",
"prov": "广东省",
"py": "enping"
},
{
"city": "湛江",
"district": "湛江市",
"prov": "广东省",
"py": "zhanjiang"
},
{
"city": "赤坎",
"district": "湛江市",
"prov": "广东省",
"py": "chikan"
},
{
"city": "霞山",
"district": "湛江市",
"prov": "广东省",
"py": "xiashan"
},
{
"city": "坡头",
"district": "湛江市",
"prov": "广东省",
"py": "potou"
},
{
"city": "麻章",
"district": "湛江市",
"prov": "广东省",
"py": "mazhang"
},
{
"city": "遂溪",
"district": "湛江市",
"prov": "广东省",
"py": "suixi"
},
{
"city": "徐闻",
"district": "湛江市",
"prov": "广东省",
"py": "xuwen"
},
{
"city": "廉江",
"district": "湛江市",
"prov": "广东省",
"py": "lianjiang"
},
{
"city": "雷州",
"district": "湛江市",
"prov": "广东省",
"py": "leizhou"
},
{
"city": "吴川",
"district": "湛江市",
"prov": "广东省",
"py": "wuchuan"
},
{
"city": "茂名",
"district": "茂名市",
"prov": "广东省",
"py": "maoming"
},
{
"city": "茂南",
"district": "茂名市",
"prov": "广东省",
"py": "maonan"
},
{
"city": "电白",
"district": "茂名市",
"prov": "广东省",
"py": "dianbai"
},
{
"city": "高州",
"district": "茂名市",
"prov": "广东省",
"py": "gaozhou"
},
{
"city": "化州",
"district": "茂名市",
"prov": "广东省",
"py": "huazhou"
},
{
"city": "信宜",
"district": "茂名市",
"prov": "广东省",
"py": "xinyi"
},
{
"city": "肇庆",
"district": "肇庆市",
"prov": "广东省",
"py": "zhaoqing"
},
{
"city": "端州",
"district": "肇庆市",
"prov": "广东省",
"py": "duanzhou"
},
{
"city": "鼎湖",
"district": "肇庆市",
"prov": "广东省",
"py": "dinghu"
},
{
"city": "高要",
"district": "肇庆市",
"prov": "广东省",
"py": "gaoyao"
},
{
"city": "广宁",
"district": "肇庆市",
"prov": "广东省",
"py": "guangning"
},
{
"city": "怀集",
"district": "肇庆市",
"prov": "广东省",
"py": "huaiji"
},
{
"city": "封开",
"district": "肇庆市",
"prov": "广东省",
"py": "fengkai"
},
{
"city": "德庆",
"district": "肇庆市",
"prov": "广东省",
"py": "deqing"
},
{
"city": "四会",
"district": "肇庆市",
"prov": "广东省",
"py": "sihui"
},
{
"city": "惠州",
"district": "惠州市",
"prov": "广东省",
"py": "huizhou"
},
{
"city": "惠城",
"district": "惠州市",
"prov": "广东省",
"py": "huicheng"
},
{
"city": "惠阳",
"district": "惠州市",
"prov": "广东省",
"py": "huiyang"
},
{
"city": "博罗",
"district": "惠州市",
"prov": "广东省",
"py": "boluo"
},
{
"city": "惠东",
"district": "惠州市",
"prov": "广东省",
"py": "huidong"
},
{
"city": "龙门",
"district": "惠州市",
"prov": "广东省",
"py": "longmen"
},
{
"city": "梅州",
"district": "梅州市",
"prov": "广东省",
"py": "meizhou"
},
{
"city": "梅江",
"district": "梅州市",
"prov": "广东省",
"py": "meijiang"
},
{
"city": "梅县",
"district": "梅州市",
"prov": "广东省",
"py": "meixian"
},
{
"city": "大埔",
"district": "梅州市",
"prov": "广东省",
"py": "dabu"
},
{
"city": "丰顺",
"district": "梅州市",
"prov": "广东省",
"py": "fengshun"
},
{
"city": "五华",
"district": "梅州市",
"prov": "广东省",
"py": "wuhua"
},
{
"city": "平远",
"district": "梅州市",
"prov": "广东省",
"py": "pingyuan"
},
{
"city": "蕉岭",
"district": "梅州市",
"prov": "广东省",
"py": "jiaoling"
},
{
"city": "兴宁",
"district": "梅州市",
"prov": "广东省",
"py": "xingning"
},
{
"city": "汕尾",
"district": "汕尾市",
"prov": "广东省",
"py": "shanwei"
},
{
"city": "城区",
"district": "汕尾市",
"prov": "广东省",
"py": "chengqu"
},
{
"city": "海丰",
"district": "汕尾市",
"prov": "广东省",
"py": "haifeng"
},
{
"city": "陆河",
"district": "汕尾市",
"prov": "广东省",
"py": "luhe"
},
{
"city": "陆丰",
"district": "汕尾市",
"prov": "广东省",
"py": "lufeng"
},
{
"city": "河源",
"district": "河源市",
"prov": "广东省",
"py": "heyuan"
},
{
"city": "源城",
"district": "河源市",
"prov": "广东省",
"py": "yuancheng"
},
{
"city": "紫金",
"district": "河源市",
"prov": "广东省",
"py": "zijin"
},
{
"city": "龙川",
"district": "河源市",
"prov": "广东省",
"py": "longchuan"
},
{
"city": "连平",
"district": "河源市",
"prov": "广东省",
"py": "lianping"
},
{
"city": "和平",
"district": "河源市",
"prov": "广东省",
"py": "heping"
},
{
"city": "东源",
"district": "河源市",
"prov": "广东省",
"py": "dongyuan"
},
{
"city": "阳江",
"district": "阳江市",
"prov": "广东省",
"py": "yangjiang"
},
{
"city": "江城区",
"district": "阳江市",
"prov": "广东省",
"py": "jiangchengqu"
},
{
"city": "阳东",
"district": "阳江市",
"prov": "广东省",
"py": "yangdong"
},
{
"city": "阳西",
"district": "阳江市",
"prov": "广东省",
"py": "yangxi"
},
{
"city": "阳春",
"district": "阳江市",
"prov": "广东省",
"py": "yangchun"
},
{
"city": "清远",
"district": "清远市",
"prov": "广东省",
"py": "qingyuan"
},
{
"city": "清城",
"district": "清远市",
"prov": "广东省",
"py": "qingcheng"
},
{
"city": "清新",
"district": "清远市",
"prov": "广东省",
"py": "qingxin"
},
{
"city": "佛冈",
"district": "清远市",
"prov": "广东省",
"py": "fogang"
},
{
"city": "阳山",
"district": "清远市",
"prov": "广东省",
"py": "yangshan"
},
{
"city": "连山",
"district": "清远市",
"prov": "广东省",
"py": "lianshan"
},
{
"city": "连南",
"district": "清远市",
"prov": "广东省",
"py": "liannan"
},
{
"city": "英德",
"district": "清远市",
"prov": "广东省",
"py": "yingde"
},
{
"city": "连州",
"district": "清远市",
"prov": "广东省",
"py": "lianzhou"
},
{
"city": "东莞",
"district": "东莞市",
"prov": "广东省",
"py": "dongguan"
},
{
"city": "中山",
"district": "中山市",
"prov": "广东省",
"py": "zhongshan"
},
{
"city": "潮州",
"district": "潮州市",
"prov": "广东省",
"py": "chaozhou"
},
{
"city": "湘桥",
"district": "潮州市",
"prov": "广东省",
"py": "xiangqiao"
},
{
"city": "潮安",
"district": "潮州市",
"prov": "广东省",
"py": "chaoan"
},
{
"city": "饶平",
"district": "潮州市",
"prov": "广东省",
"py": "raoping"
},
{
"city": "揭阳",
"district": "揭阳市",
"prov": "广东省",
"py": "jieyang"
},
{
"city": "榕城",
"district": "揭阳市",
"prov": "广东省",
"py": "rongcheng"
},
{
"city": "揭东",
"district": "揭阳市",
"prov": "广东省",
"py": "jiedong"
},
{
"city": "揭西",
"district": "揭阳市",
"prov": "广东省",
"py": "jiexi"
},
{
"city": "惠来",
"district": "揭阳市",
"prov": "广东省",
"py": "huilai"
},
{
"city": "普宁",
"district": "揭阳市",
"prov": "广东省",
"py": "puning"
},
{
"city": "云浮",
"district": "云浮市",
"prov": "广东省",
"py": "yunfu"
},
{
"city": "云城",
"district": "云浮市",
"prov": "广东省",
"py": "yuncheng"
},
{
"city": "云安",
"district": "云浮市",
"prov": "广东省",
"py": "yunan"
},
{
"city": "新兴",
"district": "云浮市",
"prov": "广东省",
"py": "xinxing"
},
{
"city": "郁南",
"district": "云浮市",
"prov": "广东省",
"py": "yunan"
},
{
"city": "罗定",
"district": "云浮市",
"prov": "广东省",
"py": "luoding"
},
{
"city": "南宁",
"district": "南宁市",
"prov": "广西壮族自治区",
"py": "nanning"
},
{
"city": "兴宁区",
"district": "南宁市",
"prov": "广西壮族自治区",
"py": "xingningqu"
},
{
"city": "青秀",
"district": "南宁市",
"prov": "广西壮族自治区",
"py": "qingxiu"
},
{
"city": "江南区",
"district": "南宁市",
"prov": "广西壮族自治区",
"py": "jiangnanqu"
},
{
"city": "西乡塘",
"district": "南宁市",
"prov": "广西壮族自治区",
"py": "xixiangtang"
},
{
"city": "良庆",
"district": "南宁市",
"prov": "广西壮族自治区",
"py": "liangqing"
},
{
"city": "邕宁",
"district": "南宁市",
"prov": "广西壮族自治区",
"py": "yongning"
},
{
"city": "武鸣",
"district": "南宁市",
"prov": "广西壮族自治区",
"py": "wuming"
},
{
"city": "隆安",
"district": "南宁市",
"prov": "广西壮族自治区",
"py": "longan"
},
{
"city": "马山",
"district": "南宁市",
"prov": "广西壮族自治区",
"py": "mashan"
},
{
"city": "上林",
"district": "南宁市",
"prov": "广西壮族自治区",
"py": "shanglin"
},
{
"city": "宾阳",
"district": "南宁市",
"prov": "广西壮族自治区",
"py": "binyang"
},
{
"city": "横县",
"district": "南宁市",
"prov": "广西壮族自治区",
"py": "hengxian"
},
{
"city": "柳州",
"district": "柳州市",
"prov": "广西壮族自治区",
"py": "liuzhou"
},
{
"city": "城中区",
"district": "柳州市",
"prov": "广西壮族自治区",
"py": "chengzhongqu"
},
{
"city": "鱼峰",
"district": "柳州市",
"prov": "广西壮族自治区",
"py": "yufeng"
},
{
"city": "柳南",
"district": "柳州市",
"prov": "广西壮族自治区",
"py": "liunan"
},
{
"city": "柳北",
"district": "柳州市",
"prov": "广西壮族自治区",
"py": "liubei"
},
{
"city": "柳江",
"district": "柳州市",
"prov": "广西壮族自治区",
"py": "liujiang"
},
{
"city": "柳城",
"district": "柳州市",
"prov": "广西壮族自治区",
"py": "liucheng"
},
{
"city": "鹿寨",
"district": "柳州市",
"prov": "广西壮族自治区",
"py": "luzhai"
},
{
"city": "融安",
"district": "柳州市",
"prov": "广西壮族自治区",
"py": "rongan"
},
{
"city": "融水",
"district": "柳州市",
"prov": "广西壮族自治区",
"py": "rongshui"
},
{
"city": "三江",
"district": "柳州市",
"prov": "广西壮族自治区",
"py": "sanjiang"
},
{
"city": "桂林",
"district": "桂林市",
"prov": "广西壮族自治区",
"py": "guilin"
},
{
"city": "秀峰",
"district": "桂林市",
"prov": "广西壮族自治区",
"py": "xiufeng"
},
{
"city": "叠彩",
"district": "桂林市",
"prov": "广西壮族自治区",
"py": "diecai"
},
{
"city": "象山区",
"district": "桂林市",
"prov": "广西壮族自治区",
"py": "xiangshanqu"
},
{
"city": "七星",
"district": "桂林市",
"prov": "广西壮族自治区",
"py": "qixing"
},
{
"city": "雁山",
"district": "桂林市",
"prov": "广西壮族自治区",
"py": "yanshan"
},
{
"city": "临桂",
"district": "桂林市",
"prov": "广西壮族自治区",
"py": "lingui"
},
{
"city": "阳朔",
"district": "桂林市",
"prov": "广西壮族自治区",
"py": "yangshuo"
},
{
"city": "灵川",
"district": "桂林市",
"prov": "广西壮族自治区",
"py": "lingchuan"
},
{
"city": "全州",
"district": "桂林市",
"prov": "广西壮族自治区",
"py": "quanzhou"
},
{
"city": "兴安",
"district": "桂林市",
"prov": "广西壮族自治区",
"py": "xingan"
},
{
"city": "永福",
"district": "桂林市",
"prov": "广西壮族自治区",
"py": "yongfu"
},
{
"city": "灌阳",
"district": "桂林市",
"prov": "广西壮族自治区",
"py": "guanyang"
},
{
"city": "龙胜",
"district": "桂林市",
"prov": "广西壮族自治区",
"py": "longsheng"
},
{
"city": "资源",
"district": "桂林市",
"prov": "广西壮族自治区",
"py": "ziyuan"
},
{
"city": "平乐",
"district": "桂林市",
"prov": "广西壮族自治区",
"py": "pingle"
},
{
"city": "恭城",
"district": "桂林市",
"prov": "广西壮族自治区",
"py": "gongcheng"
},
{
"city": "荔浦",
"district": "桂林市",
"prov": "广西壮族自治区",
"py": "lipu"
},
{
"city": "梧州",
"district": "梧州市",
"prov": "广西壮族自治区",
"py": "wuzhou"
},
{
"city": "万秀",
"district": "梧州市",
"prov": "广西壮族自治区",
"py": "wanxiu"
},
{
"city": "长洲",
"district": "梧州市",
"prov": "广西壮族自治区",
"py": "changzhou"
},
{
"city": "龙圩",
"district": "梧州市",
"prov": "广西壮族自治区",
"py": "longxu"
},
{
"city": "苍梧",
"district": "梧州市",
"prov": "广西壮族自治区",
"py": "cangwu"
},
{
"city": "藤县",
"district": "梧州市",
"prov": "广西壮族自治区",
"py": "tengxian"
},
{
"city": "蒙山",
"district": "梧州市",
"prov": "广西壮族自治区",
"py": "mengshan"
},
{
"city": "岑溪",
"district": "梧州市",
"prov": "广西壮族自治区",
"py": "cenxi"
},
{
"city": "北海",
"district": "北海市",
"prov": "广西壮族自治区",
"py": "beihai"
},
{
"city": "海城区",
"district": "北海市",
"prov": "广西壮族自治区",
"py": "haichengqu"
},
{
"city": "银海",
"district": "北海市",
"prov": "广西壮族自治区",
"py": "yinhai"
},
{
"city": "铁山港",
"district": "北海市",
"prov": "广西壮族自治区",
"py": "tieshangang"
},
{
"city": "合浦",
"district": "北海市",
"prov": "广西壮族自治区",
"py": "hepu"
},
{
"city": "防城港",
"district": "防城港市",
"prov": "广西壮族自治区",
"py": "fangchenggang"
},
{
"city": "港口区",
"district": "防城港市",
"prov": "广西壮族自治区",
"py": "gangkouqu"
},
{
"city": "防城",
"district": "防城港市",
"prov": "广西壮族自治区",
"py": "fangcheng"
},
{
"city": "上思",
"district": "防城港市",
"prov": "广西壮族自治区",
"py": "shangsi"
},
{
"city": "东兴",
"district": "防城港市",
"prov": "广西壮族自治区",
"py": "dongxing"
},
{
"city": "钦州",
"district": "钦州市",
"prov": "广西壮族自治区",
"py": "qinzhou"
},
{
"city": "钦南",
"district": "钦州市",
"prov": "广西壮族自治区",
"py": "qinnan"
},
{
"city": "钦北",
"district": "钦州市",
"prov": "广西壮族自治区",
"py": "qinbei"
},
{
"city": "灵山",
"district": "钦州市",
"prov": "广西壮族自治区",
"py": "lingshan"
},
{
"city": "浦北",
"district": "钦州市",
"prov": "广西壮族自治区",
"py": "pubei"
},
{
"city": "贵港",
"district": "贵港市",
"prov": "广西壮族自治区",
"py": "guigang"
},
{
"city": "港北",
"district": "贵港市",
"prov": "广西壮族自治区",
"py": "gangbei"
},
{
"city": "港南",
"district": "贵港市",
"prov": "广西壮族自治区",
"py": "gangnan"
},
{
"city": "覃塘",
"district": "贵港市",
"prov": "广西壮族自治区",
"py": "qintang"
},
{
"city": "平南",
"district": "贵港市",
"prov": "广西壮族自治区",
"py": "pingnan"
},
{
"city": "桂平",
"district": "贵港市",
"prov": "广西壮族自治区",
"py": "guiping"
},
{
"city": "玉林",
"district": "玉林市",
"prov": "广西壮族自治区",
"py": "yulin"
},
{
"city": "玉州",
"district": "玉林市",
"prov": "广西壮族自治区",
"py": "yuzhou"
},
{
"city": "福绵",
"district": "玉林市",
"prov": "广西壮族自治区",
"py": "fumian"
},
{
"city": "容县",
"district": "玉林市",
"prov": "广西壮族自治区",
"py": "rongxian"
},
{
"city": "陆川",
"district": "玉林市",
"prov": "广西壮族自治区",
"py": "luchuan"
},
{
"city": "博白",
"district": "玉林市",
"prov": "广西壮族自治区",
"py": "bobai"
},
{
"city": "兴业",
"district": "玉林市",
"prov": "广西壮族自治区",
"py": "xingye"
},
{
"city": "北流",
"district": "玉林市",
"prov": "广西壮族自治区",
"py": "beiliu"
},
{
"city": "百色",
"district": "百色市",
"prov": "广西壮族自治区",
"py": "baise"
},
{
"city": "右江",
"district": "百色市",
"prov": "广西壮族自治区",
"py": "youjiang"
},
{
"city": "田阳",
"district": "百色市",
"prov": "广西壮族自治区",
"py": "tianyang"
},
{
"city": "田东",
"district": "百色市",
"prov": "广西壮族自治区",
"py": "tiandong"
},
{
"city": "平果",
"district": "百色市",
"prov": "广西壮族自治区",
"py": "pingguo"
},
{
"city": "德保",
"district": "百色市",
"prov": "广西壮族自治区",
"py": "debao"
},
{
"city": "那坡",
"district": "百色市",
"prov": "广西壮族自治区",
"py": "napo"
},
{
"city": "凌云",
"district": "百色市",
"prov": "广西壮族自治区",
"py": "lingyun"
},
{
"city": "乐业",
"district": "百色市",
"prov": "广西壮族自治区",
"py": "leye"
},
{
"city": "田林",
"district": "百色市",
"prov": "广西壮族自治区",
"py": "tianlin"
},
{
"city": "西林",
"district": "百色市",
"prov": "广西壮族自治区",
"py": "xilin"
},
{
"city": "隆林",
"district": "百色市",
"prov": "广西壮族自治区",
"py": "longlin"
},
{
"city": "靖西",
"district": "百色市",
"prov": "广西壮族自治区",
"py": "jingxi"
},
{
"city": "贺州",
"district": "贺州市",
"prov": "广西壮族自治区",
"py": "hezhou"
},
{
"city": "八步",
"district": "贺州市",
"prov": "广西壮族自治区",
"py": "babu"
},
{
"city": "平桂",
"district": "贺州市",
"prov": "广西壮族自治区",
"py": "pinggui"
},
{
"city": "昭平",
"district": "贺州市",
"prov": "广西壮族自治区",
"py": "zhaoping"
},
{
"city": "钟山",
"district": "贺州市",
"prov": "广西壮族自治区",
"py": "zhongshan"
},
{
"city": "富川",
"district": "贺州市",
"prov": "广西壮族自治区",
"py": "fuchuan"
},
{
"city": "河池",
"district": "河池市",
"prov": "广西壮族自治区",
"py": "hechi"
},
{
"city": "金城江",
"district": "河池市",
"prov": "广西壮族自治区",
"py": "jinchengjiang"
},
{
"city": "宜州",
"district": "河池市",
"prov": "广西壮族自治区",
"py": "yizhou"
},
{
"city": "南丹",
"district": "河池市",
"prov": "广西壮族自治区",
"py": "nandan"
},
{
"city": "天峨",
"district": "河池市",
"prov": "广西壮族自治区",
"py": "tiane"
},
{
"city": "凤山",
"district": "河池市",
"prov": "广西壮族自治区",
"py": "fengshan"
},
{
"city": "东兰",
"district": "河池市",
"prov": "广西壮族自治区",
"py": "donglan"
},
{
"city": "罗城",
"district": "河池市",
"prov": "广西壮族自治区",
"py": "luocheng"
},
{
"city": "环江",
"district": "河池市",
"prov": "广西壮族自治区",
"py": "huanjiang"
},
{
"city": "巴马",
"district": "河池市",
"prov": "广西壮族自治区",
"py": "bama"
},
{
"city": "都安",
"district": "河池市",
"prov": "广西壮族自治区",
"py": "duan"
},
{
"city": "大化",
"district": "河池市",
"prov": "广西壮族自治区",
"py": "dahua"
},
{
"city": "来宾",
"district": "来宾市",
"prov": "广西壮族自治区",
"py": "laibin"
},
{
"city": "兴宾",
"district": "来宾市",
"prov": "广西壮族自治区",
"py": "xingbin"
},
{
"city": "忻城",
"district": "来宾市",
"prov": "广西壮族自治区",
"py": "xincheng"
},
{
"city": "象州",
"district": "来宾市",
"prov": "广西壮族自治区",
"py": "xiangzhou"
},
{
"city": "武宣",
"district": "来宾市",
"prov": "广西壮族自治区",
"py": "wuxuan"
},
{
"city": "金秀",
"district": "来宾市",
"prov": "广西壮族自治区",
"py": "jinxiu"
},
{
"city": "合山",
"district": "来宾市",
"prov": "广西壮族自治区",
"py": "heshan"
},
{
"city": "崇左",
"district": "崇左市",
"prov": "广西壮族自治区",
"py": "chongzuo"
},
{
"city": "江州",
"district": "崇左市",
"prov": "广西壮族自治区",
"py": "jiangzhou"
},
{
"city": "扶绥",
"district": "崇左市",
"prov": "广西壮族自治区",
"py": "fusui"
},
{
"city": "宁明",
"district": "崇左市",
"prov": "广西壮族自治区",
"py": "ningming"
},
{
"city": "龙州",
"district": "崇左市",
"prov": "广西壮族自治区",
"py": "longzhou"
},
{
"city": "大新",
"district": "崇左市",
"prov": "广西壮族自治区",
"py": "daxin"
},
{
"city": "天等",
"district": "崇左市",
"prov": "广西壮族自治区",
"py": "tiandeng"
},
{
"city": "凭祥",
"district": "崇左市",
"prov": "广西壮族自治区",
"py": "pingxiang"
},
{
"city": "海口",
"district": "海口市",
"prov": "海南省",
"py": "haikou"
},
{
"city": "秀英",
"district": "海口市",
"prov": "海南省",
"py": "xiuying"
},
{
"city": "龙华区",
"district": "海口市",
"prov": "海南省",
"py": "longhuaqu"
},
{
"city": "琼山",
"district": "海口市",
"prov": "海南省",
"py": "qiongshan"
},
{
"city": "美兰",
"district": "海口市",
"prov": "海南省",
"py": "meilan"
},
{
"city": "三亚",
"district": "三亚市",
"prov": "海南省",
"py": "sanya"
},
{
"city": "海棠区",
"district": "三亚市",
"prov": "海南省",
"py": "haitangqu"
},
{
"city": "吉阳区",
"district": "三亚市",
"prov": "海南省",
"py": "jiyangqu"
},
{
"city": "天涯区",
"district": "三亚市",
"prov": "海南省",
"py": "tianyaqu"
},
{
"city": "崖州区",
"district": "三亚市",
"prov": "海南省",
"py": "yazhouqu"
},
{
"city": "三沙",
"district": "三沙市",
"prov": "海南省",
"py": "sansha"
},
{
"city": "西沙群岛",
"district": "三沙市",
"prov": "海南省",
"py": "xishaqundao"
},
{
"city": "南沙群岛",
"district": "三沙市",
"prov": "海南省",
"py": "nanshaqundao"
},
{
"city": "中沙群岛",
"district": "三沙市",
"prov": "海南省",
"py": "zhongshaqundao"
},
{
"city": "儋州",
"district": "儋州市",
"prov": "海南省",
"py": "danzhou"
},
{
"city": "五指山",
"district": "五指山市",
"prov": "海南省",
"py": "wuzhishan"
},
{
"city": "琼海",
"district": "琼海市",
"prov": "海南省",
"py": "qionghai"
},
{
"city": "文昌",
"district": "文昌市",
"prov": "海南省",
"py": "wenchang"
},
{
"city": "万宁",
"district": "万宁市",
"prov": "海南省",
"py": "wanning"
},
{
"city": "东方",
"district": "东方市",
"prov": "海南省",
"py": "dongfang"
},
{
"city": "定安",
"district": "定安县",
"prov": "海南省",
"py": "dingan"
},
{
"city": "屯昌",
"district": "屯昌县",
"prov": "海南省",
"py": "tunchang"
},
{
"city": "澄迈",
"district": "澄迈县",
"prov": "海南省",
"py": "chengmai"
},
{
"city": "临高",
"district": "临高县",
"prov": "海南省",
"py": "lingao"
},
{
"city": "白沙",
"district": "白沙黎族自治县",
"prov": "海南省",
"py": "baisha"
},
{
"city": "昌江",
"district": "昌江黎族自治县",
"prov": "海南省",
"py": "changjiang"
},
{
"city": "乐东",
"district": "乐东黎族自治县",
"prov": "海南省",
"py": "ledong"
},
{
"city": "陵水",
"district": "陵水黎族自治县",
"prov": "海南省",
"py": "lingshui"
},
{
"city": "保亭",
"district": "保亭黎族苗族自治县",
"prov": "海南省",
"py": "baoting"
},
{
"city": "琼中",
"district": "琼中黎族苗族自治县",
"prov": "海南省",
"py": "qiongzhong"
},
{
"city": "重庆",
"district": "重庆市",
"prov": "重庆市",
"py": "chongqing"
},
{
"city": "万州",
"district": "重庆市",
"prov": "重庆市",
"py": "wanzhou"
},
{
"city": "涪陵",
"district": "重庆市",
"prov": "重庆市",
"py": "fuling"
},
{
"city": "渝中",
"district": "重庆市",
"prov": "重庆市",
"py": "yuzhong"
},
{
"city": "大渡口",
"district": "重庆市",
"prov": "重庆市",
"py": "dadukou"
},
{
"city": "江北",
"district": "重庆市",
"prov": "重庆市",
"py": "jiangbei"
},
{
"city": "沙坪坝",
"district": "重庆市",
"prov": "重庆市",
"py": "shapingba"
},
{
"city": "九龙坡",
"district": "重庆市",
"prov": "重庆市",
"py": "jiulongpo"
},
{
"city": "南岸",
"district": "重庆市",
"prov": "重庆市",
"py": "nanan"
},
{
"city": "北碚",
"district": "重庆市",
"prov": "重庆市",
"py": "beibei"
},
{
"city": "綦江",
"district": "重庆市",
"prov": "重庆市",
"py": "qijiang"
},
{
"city": "大足",
"district": "重庆市",
"prov": "重庆市",
"py": "dazu"
},
{
"city": "渝北",
"district": "重庆市",
"prov": "重庆市",
"py": "yubei"
},
{
"city": "巴南",
"district": "重庆市",
"prov": "重庆市",
"py": "banan"
},
{
"city": "黔江",
"district": "重庆市",
"prov": "重庆市",
"py": "qianjiang"
},
{
"city": "长寿",
"district": "重庆市",
"prov": "重庆市",
"py": "changshou"
},
{
"city": "江津",
"district": "重庆市",
"prov": "重庆市",
"py": "jiangjin"
},
{
"city": "合川",
"district": "重庆市",
"prov": "重庆市",
"py": "hechuan"
},
{
"city": "永川",
"district": "重庆市",
"prov": "重庆市",
"py": "yongchuan"
},
{
"city": "南川",
"district": "重庆市",
"prov": "重庆市",
"py": "nanchuan"
},
{
"city": "璧山",
"district": "重庆市",
"prov": "重庆市",
"py": "bishan"
},
{
"city": "铜梁",
"district": "重庆市",
"prov": "重庆市",
"py": "tongliang"
},
{
"city": "潼南",
"district": "重庆市",
"prov": "重庆市",
"py": "tongnan"
},
{
"city": "荣昌",
"district": "重庆市",
"prov": "重庆市",
"py": "rongchang"
},
{
"city": "开州",
"district": "重庆市",
"prov": "重庆市",
"py": "kaizhou"
},
{
"city": "梁平",
"district": "重庆市",
"prov": "重庆市",
"py": "liangping"
},
{
"city": "武隆",
"district": "重庆市",
"prov": "重庆市",
"py": "wulong"
},
{
"city": "城口",
"district": "重庆市",
"prov": "重庆市",
"py": "chengkou"
},
{
"city": "丰都",
"district": "重庆市",
"prov": "重庆市",
"py": "fengdu"
},
{
"city": "垫江",
"district": "重庆市",
"prov": "重庆市",
"py": "dianjiang"
},
{
"city": "忠县",
"district": "重庆市",
"prov": "重庆市",
"py": "zhongxian"
},
{
"city": "云阳",
"district": "重庆市",
"prov": "重庆市",
"py": "yunyang"
},
{
"city": "奉节",
"district": "重庆市",
"prov": "重庆市",
"py": "fengjie"
},
{
"city": "巫山",
"district": "重庆市",
"prov": "重庆市",
"py": "wushan"
},
{
"city": "巫溪",
"district": "重庆市",
"prov": "重庆市",
"py": "wuxi"
},
{
"city": "石柱",
"district": "重庆市",
"prov": "重庆市",
"py": "shizhu"
},
{
"city": "秀山",
"district": "重庆市",
"prov": "重庆市",
"py": "xiushan"
},
{
"city": "酉阳",
"district": "重庆市",
"prov": "重庆市",
"py": "youyang"
},
{
"city": "彭水",
"district": "重庆市",
"prov": "重庆市",
"py": "pengshui"
},
{
"city": "成都",
"district": "成都市",
"prov": "四川省",
"py": "chengdu"
},
{
"city": "锦江",
"district": "成都市",
"prov": "四川省",
"py": "jinjiang"
},
{
"city": "青羊",
"district": "成都市",
"prov": "四川省",
"py": "qingyang"
},
{
"city": "金牛",
"district": "成都市",
"prov": "四川省",
"py": "jinniu"
},
{
"city": "武侯",
"district": "成都市",
"prov": "四川省",
"py": "wuhou"
},
{
"city": "成华",
"district": "成都市",
"prov": "四川省",
"py": "chenghua"
},
{
"city": "龙泉驿",
"district": "成都市",
"prov": "四川省",
"py": "longquanyi"
},
{
"city": "青白江",
"district": "成都市",
"prov": "四川省",
"py": "qingbaijiang"
},
{
"city": "新都",
"district": "成都市",
"prov": "四川省",
"py": "xindu"
},
{
"city": "温江",
"district": "成都市",
"prov": "四川省",
"py": "wenjiang"
},
{
"city": "双流",
"district": "成都市",
"prov": "四川省",
"py": "shuangliu"
},
{
"city": "郫都",
"district": "成都市",
"prov": "四川省",
"py": "pixian"
},
{
"city": "金堂",
"district": "成都市",
"prov": "四川省",
"py": "jintang"
},
{
"city": "大邑",
"district": "成都市",
"prov": "四川省",
"py": "dayi"
},
{
"city": "蒲江",
"district": "成都市",
"prov": "四川省",
"py": "pujiang"
},
{
"city": "新津",
"district": "成都市",
"prov": "四川省",
"py": "xinjin"
},
{
"city": "都江堰",
"district": "成都市",
"prov": "四川省",
"py": "dujiangyan"
},
{
"city": "彭州",
"district": "成都市",
"prov": "四川省",
"py": "pengzhou"
},
{
"city": "邛崃",
"district": "成都市",
"prov": "四川省",
"py": "qionglai"
},
{
"city": "崇州",
"district": "成都市",
"prov": "四川省",
"py": "chongzhou"
},
{
"city": "简阳",
"district": "成都市",
"prov": "四川省",
"py": "jianyang"
},
{
"city": "自贡",
"district": "自贡市",
"prov": "四川省",
"py": "zigong"
},
{
"city": "自流井",
"district": "自贡市",
"prov": "四川省",
"py": "ziliujing"
},
{
"city": "贡井",
"district": "自贡市",
"prov": "四川省",
"py": "gongjing"
},
{
"city": "大安区",
"district": "自贡市",
"prov": "四川省",
"py": "daanqu"
},
{
"city": "沿滩",
"district": "自贡市",
"prov": "四川省",
"py": "yantan"
},
{
"city": "荣县",
"district": "自贡市",
"prov": "四川省",
"py": "rongxian"
},
{
"city": "富顺",
"district": "自贡市",
"prov": "四川省",
"py": "fushun"
},
{
"city": "攀枝花",
"district": "攀枝花市",
"prov": "四川省",
"py": "panzhihua"
},
{
"city": "东区",
"district": "攀枝花市",
"prov": "四川省",
"py": "dongqu"
},
{
"city": "西区",
"district": "攀枝花市",
"prov": "四川省",
"py": "xiqu"
},
{
"city": "仁和",
"district": "攀枝花市",
"prov": "四川省",
"py": "renhe"
},
{
"city": "米易",
"district": "攀枝花市",
"prov": "四川省",
"py": "miyi"
},
{
"city": "盐边",
"district": "攀枝花市",
"prov": "四川省",
"py": "yanbian"
},
{
"city": "泸州",
"district": "泸州市",
"prov": "四川省",
"py": "luzhou"
},
{
"city": "江阳",
"district": "泸州市",
"prov": "四川省",
"py": "jiangyang"
},
{
"city": "纳溪",
"district": "泸州市",
"prov": "四川省",
"py": "naxi"
},
{
"city": "龙马潭",
"district": "泸州市",
"prov": "四川省",
"py": "longmatan"
},
{
"city": "泸县",
"district": "泸州市",
"prov": "四川省",
"py": "luxian"
},
{
"city": "合江",
"district": "泸州市",
"prov": "四川省",
"py": "hejiang"
},
{
"city": "叙永",
"district": "泸州市",
"prov": "四川省",
"py": "xuyong"
},
{
"city": "古蔺",
"district": "泸州市",
"prov": "四川省",
"py": "gulin"
},
{
"city": "德阳",
"district": "德阳市",
"prov": "四川省",
"py": "deyang"
},
{
"city": "旌阳",
"district": "德阳市",
"prov": "四川省",
"py": "jingyang"
},
{
"city": "罗江",
"district": "德阳市",
"prov": "四川省",
"py": "luojiang"
},
{
"city": "中江",
"district": "德阳市",
"prov": "四川省",
"py": "zhongjiang"
},
{
"city": "广汉",
"district": "德阳市",
"prov": "四川省",
"py": "guanghan"
},
{
"city": "什邡",
"district": "德阳市",
"prov": "四川省",
"py": "shifang"
},
{
"city": "绵竹",
"district": "德阳市",
"prov": "四川省",
"py": "mianzhu"
},
{
"city": "绵阳",
"district": "绵阳市",
"prov": "四川省",
"py": "mianyang"
},
{
"city": "涪城",
"district": "绵阳市",
"prov": "四川省",
"py": "fucheng"
},
{
"city": "游仙",
"district": "绵阳市",
"prov": "四川省",
"py": "youxian"
},
{
"city": "安州",
"district": "绵阳市",
"prov": "四川省",
"py": "anzhou"
},
{
"city": "三台",
"district": "绵阳市",
"prov": "四川省",
"py": "santai"
},
{
"city": "盐亭",
"district": "绵阳市",
"prov": "四川省",
"py": "yanting"
},
{
"city": "梓潼",
"district": "绵阳市",
"prov": "四川省",
"py": "zitong"
},
{
"city": "北川",
"district": "绵阳市",
"prov": "四川省",
"py": "beichuan"
},
{
"city": "平武",
"district": "绵阳市",
"prov": "四川省",
"py": "pingwu"
},
{
"city": "江油",
"district": "绵阳市",
"prov": "四川省",
"py": "jiangyou"
},
{
"city": "广元",
"district": "广元市",
"prov": "四川省",
"py": "guangyuan"
},
{
"city": "利州",
"district": "广元市",
"prov": "四川省",
"py": "lizhou"
},
{
"city": "昭化",
"district": "广元市",
"prov": "四川省",
"py": "zhaohua"
},
{
"city": "朝天",
"district": "广元市",
"prov": "四川省",
"py": "chaotian"
},
{
"city": "旺苍",
"district": "广元市",
"prov": "四川省",
"py": "wangcang"
},
{
"city": "青川",
"district": "广元市",
"prov": "四川省",
"py": "qingchuan"
},
{
"city": "剑阁",
"district": "广元市",
"prov": "四川省",
"py": "jiange"
},
{
"city": "苍溪",
"district": "广元市",
"prov": "四川省",
"py": "cangxi"
},
{
"city": "遂宁",
"district": "遂宁市",
"prov": "四川省",
"py": "suining"
},
{
"city": "船山",
"district": "遂宁市",
"prov": "四川省",
"py": "chuanshan"
},
{
"city": "安居",
"district": "遂宁市",
"prov": "四川省",
"py": "anju"
},
{
"city": "蓬溪",
"district": "遂宁市",
"prov": "四川省",
"py": "pengxi"
},
{
"city": "射洪",
"district": "遂宁市",
"prov": "四川省",
"py": "shehong"
},
{
"city": "大英",
"district": "遂宁市",
"prov": "四川省",
"py": "daying"
},
{
"city": "内江",
"district": "内江市",
"prov": "四川省",
"py": "neijiang"
},
{
"city": "市中区",
"district": "内江市",
"prov": "四川省",
"py": "shizhongqu"
},
{
"city": "东兴区",
"district": "内江市",
"prov": "四川省",
"py": "dongxingqu"
},
{
"city": "威远",
"district": "内江市",
"prov": "四川省",
"py": "weiyuan"
},
{
"city": "资中",
"district": "内江市",
"prov": "四川省",
"py": "zizhong"
},
{
"city": "隆昌",
"district": "内江市",
"prov": "四川省",
"py": "longchang"
},
{
"city": "乐山",
"district": "乐山市",
"prov": "四川省",
"py": "leshan"
},
{
"city": "市中区",
"district": "乐山市",
"prov": "四川省",
"py": "shizhongqu"
},
{
"city": "沙湾区",
"district": "乐山市",
"prov": "四川省",
"py": "shawanqu"
},
{
"city": "五通桥",
"district": "乐山市",
"prov": "四川省",
"py": "wutongqiao"
},
{
"city": "金口河",
"district": "乐山市",
"prov": "四川省",
"py": "jinkouhe"
},
{
"city": "犍为",
"district": "乐山市",
"prov": "四川省",
"py": "qianwei"
},
{
"city": "井研",
"district": "乐山市",
"prov": "四川省",
"py": "jingyan"
},
{
"city": "夹江",
"district": "乐山市",
"prov": "四川省",
"py": "jiajiang"
},
{
"city": "沐川",
"district": "乐山市",
"prov": "四川省",
"py": "muchuan"
},
{
"city": "峨边",
"district": "乐山市",
"prov": "四川省",
"py": "ebian"
},
{
"city": "马边",
"district": "乐山市",
"prov": "四川省",
"py": "mabian"
},
{
"city": "峨眉山",
"district": "乐山市",
"prov": "四川省",
"py": "emeishan"
},
{
"city": "南充",
"district": "南充市",
"prov": "四川省",
"py": "nanchong"
},
{
"city": "顺庆",
"district": "南充市",
"prov": "四川省",
"py": "shunqing"
},
{
"city": "高坪",
"district": "南充市",
"prov": "四川省",
"py": "gaoping"
},
{
"city": "嘉陵",
"district": "南充市",
"prov": "四川省",
"py": "jialing"
},
{
"city": "南部",
"district": "南充市",
"prov": "四川省",
"py": "nanbu"
},
{
"city": "营山",
"district": "南充市",
"prov": "四川省",
"py": "yingshan"
},
{
"city": "蓬安",
"district": "南充市",
"prov": "四川省",
"py": "pengan"
},
{
"city": "仪陇",
"district": "南充市",
"prov": "四川省",
"py": "yilong"
},
{
"city": "西充",
"district": "南充市",
"prov": "四川省",
"py": "xichong"
},
{
"city": "阆中",
"district": "南充市",
"prov": "四川省",
"py": "langzhong"
},
{
"city": "眉山",
"district": "眉山市",
"prov": "四川省",
"py": "meishan"
},
{
"city": "东坡",
"district": "眉山市",
"prov": "四川省",
"py": "dongpo"
},
{
"city": "彭山",
"district": "眉山市",
"prov": "四川省",
"py": "pengshan"
},
{
"city": "仁寿",
"district": "眉山市",
"prov": "四川省",
"py": "renshou"
},
{
"city": "洪雅",
"district": "眉山市",
"prov": "四川省",
"py": "hongya"
},
{
"city": "丹棱",
"district": "眉山市",
"prov": "四川省",
"py": "danleng"
},
{
"city": "青神",
"district": "眉山市",
"prov": "四川省",
"py": "qingshen"
},
{
"city": "宜宾",
"district": "宜宾市",
"prov": "四川省",
"py": "yibin"
},
{
"city": "翠屏",
"district": "宜宾市",
"prov": "四川省",
"py": "cuiping"
},
{
"city": "南溪",
"district": "宜宾市",
"prov": "四川省",
"py": "nanxi"
},
{
"city": "叙州",
"district": "宜宾市",
"prov": "四川省",
"py": "xuzhou"
},
{
"city": "江安",
"district": "宜宾市",
"prov": "四川省",
"py": "jiangan"
},
{
"city": "长宁",
"district": "宜宾市",
"prov": "四川省",
"py": "changning"
},
{
"city": "高县",
"district": "宜宾市",
"prov": "四川省",
"py": "gaoxian"
},
{
"city": "珙县",
"district": "宜宾市",
"prov": "四川省",
"py": "gongxian"
},
{
"city": "筠连",
"district": "宜宾市",
"prov": "四川省",
"py": "junlian"
},
{
"city": "兴文",
"district": "宜宾市",
"prov": "四川省",
"py": "xingwen"
},
{
"city": "屏山",
"district": "宜宾市",
"prov": "四川省",
"py": "pingshan"
},
{
"city": "广安",
"district": "广安市",
"prov": "四川省",
"py": "guangan"
},
{
"city": "广安区",
"district": "广安市",
"prov": "四川省",
"py": "guanganqu"
},
{
"city": "前锋",
"district": "广安市",
"prov": "四川省",
"py": "qianfeng"
},
{
"city": "岳池",
"district": "广安市",
"prov": "四川省",
"py": "yuechi"
},
{
"city": "武胜",
"district": "广安市",
"prov": "四川省",
"py": "wusheng"
},
{
"city": "邻水",
"district": "广安市",
"prov": "四川省",
"py": "linshui"
},
{
"city": "华蓥",
"district": "广安市",
"prov": "四川省",
"py": "huaying"
},
{
"city": "达州",
"district": "达州市",
"prov": "四川省",
"py": "dazhou"
},
{
"city": "通川",
"district": "达州市",
"prov": "四川省",
"py": "tongchuan"
},
{
"city": "达川",
"district": "达州市",
"prov": "四川省",
"py": "dachuan"
},
{
"city": "宣汉",
"district": "达州市",
"prov": "四川省",
"py": "xuanhan"
},
{
"city": "开江",
"district": "达州市",
"prov": "四川省",
"py": "kaijiang"
},
{
"city": "大竹",
"district": "达州市",
"prov": "四川省",
"py": "dazhu"
},
{
"city": "渠县",
"district": "达州市",
"prov": "四川省",
"py": "quxian"
},
{
"city": "万源",
"district": "达州市",
"prov": "四川省",
"py": "wanyuan"
},
{
"city": "雅安",
"district": "雅安市",
"prov": "四川省",
"py": "yaan"
},
{
"city": "雨城",
"district": "雅安市",
"prov": "四川省",
"py": "yucheng"
},
{
"city": "名山",
"district": "雅安市",
"prov": "四川省",
"py": "mingshan"
},
{
"city": "荥经",
"district": "雅安市",
"prov": "四川省",
"py": "yingjing"
},
{
"city": "汉源",
"district": "雅安市",
"prov": "四川省",
"py": "hanyuan"
},
{
"city": "石棉",
"district": "雅安市",
"prov": "四川省",
"py": "shimian"
},
{
"city": "天全",
"district": "雅安市",
"prov": "四川省",
"py": "tianquan"
},
{
"city": "芦山",
"district": "雅安市",
"prov": "四川省",
"py": "lushan"
},
{
"city": "宝兴",
"district": "雅安市",
"prov": "四川省",
"py": "baoxing"
},
{
"city": "巴中",
"district": "巴中市",
"prov": "四川省",
"py": "bazhong"
},
{
"city": "巴州",
"district": "巴中市",
"prov": "四川省",
"py": "bazhou"
},
{
"city": "恩阳",
"district": "巴中市",
"prov": "四川省",
"py": "enyang"
},
{
"city": "通江",
"district": "巴中市",
"prov": "四川省",
"py": "tongjiang"
},
{
"city": "南江",
"district": "巴中市",
"prov": "四川省",
"py": "nanjiang"
},
{
"city": "平昌",
"district": "巴中市",
"prov": "四川省",
"py": "pingchang"
},
{
"city": "资阳",
"district": "资阳市",
"prov": "四川省",
"py": "ziyang"
},
{
"city": "雁江",
"district": "资阳市",
"prov": "四川省",
"py": "yanjiang"
},
{
"city": "安岳",
"district": "资阳市",
"prov": "四川省",
"py": "anyue"
},
{
"city": "乐至",
"district": "资阳市",
"prov": "四川省",
"py": "lezhi"
},
{
"city": "阿坝",
"district": "阿坝藏族羌族自治州",
"prov": "四川省",
"py": "aba"
},
{
"city": "马尔康",
"district": "阿坝藏族羌族自治州",
"prov": "四川省",
"py": "maerkang"
},
{
"city": "汶川",
"district": "阿坝藏族羌族自治州",
"prov": "四川省",
"py": "wenchuan"
},
{
"city": "理县",
"district": "阿坝藏族羌族自治州",
"prov": "四川省",
"py": "lixian"
},
{
"city": "茂县",
"district": "阿坝藏族羌族自治州",
"prov": "四川省",
"py": "maoxian"
},
{
"city": "松潘",
"district": "阿坝藏族羌族自治州",
"prov": "四川省",
"py": "songpan"
},
{
"city": "九寨沟",
"district": "阿坝藏族羌族自治州",
"prov": "四川省",
"py": "jiuzhaigou"
},
{
"city": "金川",
"district": "阿坝藏族羌族自治州",
"prov": "四川省",
"py": "jinchuan"
},
{
"city": "小金",
"district": "阿坝藏族羌族自治州",
"prov": "四川省",
"py": "xiaojin"
},
{
"city": "黑水",
"district": "阿坝藏族羌族自治州",
"prov": "四川省",
"py": "heishui"
},
{
"city": "壤塘",
"district": "阿坝藏族羌族自治州",
"prov": "四川省",
"py": "rangtang"
},
{
"city": "阿坝县",
"district": "阿坝藏族羌族自治州",
"prov": "四川省",
"py": "abaxian"
},
{
"city": "若尔盖",
"district": "阿坝藏族羌族自治州",
"prov": "四川省",
"py": "ruoergai"
},
{
"city": "红原",
"district": "阿坝藏族羌族自治州",
"prov": "四川省",
"py": "hongyuan"
},
{
"city": "甘孜",
"district": "甘孜藏族自治州",
"prov": "四川省",
"py": "ganzi"
},
{
"city": "康定",
"district": "甘孜藏族自治州",
"prov": "四川省",
"py": "kangding"
},
{
"city": "泸定",
"district": "甘孜藏族自治州",
"prov": "四川省",
"py": "luding"
},
{
"city": "丹巴",
"district": "甘孜藏族自治州",
"prov": "四川省",
"py": "danba"
},
{
"city": "九龙",
"district": "甘孜藏族自治州",
"prov": "四川省",
"py": "jiulong"
},
{
"city": "雅江",
"district": "甘孜藏族自治州",
"prov": "四川省",
"py": "yajiang"
},
{
"city": "道孚",
"district": "甘孜藏族自治州",
"prov": "四川省",
"py": "daofu"
},
{
"city": "炉霍",
"district": "甘孜藏族自治州",
"prov": "四川省",
"py": "luhuo"
},
{
"city": "甘孜县",
"district": "甘孜藏族自治州",
"prov": "四川省",
"py": "ganzixian"
},
{
"city": "新龙",
"district": "甘孜藏族自治州",
"prov": "四川省",
"py": "xinlong"
},
{
"city": "德格",
"district": "甘孜藏族自治州",
"prov": "四川省",
"py": "dege"
},
{
"city": "白玉",
"district": "甘孜藏族自治州",
"prov": "四川省",
"py": "baiyu"
},
{
"city": "石渠",
"district": "甘孜藏族自治州",
"prov": "四川省",
"py": "shiqu"
},
{
"city": "色达",
"district": "甘孜藏族自治州",
"prov": "四川省",
"py": "seda"
},
{
"city": "理塘",
"district": "甘孜藏族自治州",
"prov": "四川省",
"py": "litang"
},
{
"city": "巴塘",
"district": "甘孜藏族自治州",
"prov": "四川省",
"py": "batang"
},
{
"city": "乡城",
"district": "甘孜藏族自治州",
"prov": "四川省",
"py": "xiangcheng"
},
{
"city": "稻城",
"district": "甘孜藏族自治州",
"prov": "四川省",
"py": "daocheng"
},
{
"city": "得荣",
"district": "甘孜藏族自治州",
"prov": "四川省",
"py": "derong"
},
{
"city": "凉山",
"district": "凉山彝族自治州",
"prov": "四川省",
"py": "liangshan"
},
{
"city": "西昌",
"district": "凉山彝族自治州",
"prov": "四川省",
"py": "xichang"
},
{
"city": "木里",
"district": "凉山彝族自治州",
"prov": "四川省",
"py": "muli"
},
{
"city": "盐源",
"district": "凉山彝族自治州",
"prov": "四川省",
"py": "yanyuan"
},
{
"city": "德昌",
"district": "凉山彝族自治州",
"prov": "四川省",
"py": "dechang"
},
{
"city": "会理",
"district": "凉山彝族自治州",
"prov": "四川省",
"py": "huili"
},
{
"city": "会东",
"district": "凉山彝族自治州",
"prov": "四川省",
"py": "huidong"
},
{
"city": "宁南",
"district": "凉山彝族自治州",
"prov": "四川省",
"py": "ningnan"
},
{
"city": "普格",
"district": "凉山彝族自治州",
"prov": "四川省",
"py": "puge"
},
{
"city": "布拖",
"district": "凉山彝族自治州",
"prov": "四川省",
"py": "butuo"
},
{
"city": "金阳",
"district": "凉山彝族自治州",
"prov": "四川省",
"py": "jinyang"
},
{
"city": "昭觉",
"district": "凉山彝族自治州",
"prov": "四川省",
"py": "zhaojue"
},
{
"city": "喜德",
"district": "凉山彝族自治州",
"prov": "四川省",
"py": "xide"
},
{
"city": "冕宁",
"district": "凉山彝族自治州",
"prov": "四川省",
"py": "mianning"
},
{
"city": "越西",
"district": "凉山彝族自治州",
"prov": "四川省",
"py": "yuexi"
},
{
"city": "甘洛",
"district": "凉山彝族自治州",
"prov": "四川省",
"py": "ganluo"
},
{
"city": "美姑",
"district": "凉山彝族自治州",
"prov": "四川省",
"py": "meigu"
},
{
"city": "雷波",
"district": "凉山彝族自治州",
"prov": "四川省",
"py": "leibo"
},
{
"city": "贵阳",
"district": "贵阳市",
"prov": "贵州省",
"py": "guiyang"
},
{
"city": "南明",
"district": "贵阳市",
"prov": "贵州省",
"py": "nanming"
},
{
"city": "云岩",
"district": "贵阳市",
"prov": "贵州省",
"py": "yunyan"
},
{
"city": "花溪",
"district": "贵阳市",
"prov": "贵州省",
"py": "huaxi"
},
{
"city": "乌当",
"district": "贵阳市",
"prov": "贵州省",
"py": "wudang"
},
{
"city": "白云区",
"district": "贵阳市",
"prov": "贵州省",
"py": "baiyunqu"
},
{
"city": "观山湖",
"district": "贵阳市",
"prov": "贵州省",
"py": "guanshanhu"
},
{
"city": "开阳",
"district": "贵阳市",
"prov": "贵州省",
"py": "kaiyang"
},
{
"city": "息烽",
"district": "贵阳市",
"prov": "贵州省",
"py": "xifeng"
},
{
"city": "修文",
"district": "贵阳市",
"prov": "贵州省",
"py": "xiuwen"
},
{
"city": "清镇",
"district": "贵阳市",
"prov": "贵州省",
"py": "qingzhen"
},
{
"city": "六盘水",
"district": "六盘水市",
"prov": "贵州省",
"py": "liupanshui"
},
{
"city": "钟山区",
"district": "六盘水市",
"prov": "贵州省",
"py": "zhongshanqu"
},
{
"city": "六枝",
"district": "六盘水市",
"prov": "贵州省",
"py": "liuzhi"
},
{
"city": "水城",
"district": "六盘水市",
"prov": "贵州省",
"py": "shuicheng"
},
{
"city": "盘州",
"district": "六盘水市",
"prov": "贵州省",
"py": "panzhou"
},
{
"city": "遵义",
"district": "遵义市",
"prov": "贵州省",
"py": "zunyi"
},
{
"city": "红花岗",
"district": "遵义市",
"prov": "贵州省",
"py": "honghuagang"
},
{
"city": "汇川",
"district": "遵义市",
"prov": "贵州省",
"py": "huichuan"
},
{
"city": "播州",
"district": "遵义市",
"prov": "贵州省",
"py": "bozhou"
},
{
"city": "桐梓",
"district": "遵义市",
"prov": "贵州省",
"py": "tongzi"
},
{
"city": "绥阳",
"district": "遵义市",
"prov": "贵州省",
"py": "suiyang"
},
{
"city": "正安",
"district": "遵义市",
"prov": "贵州省",
"py": "zhengan"
},
{
"city": "道真",
"district": "遵义市",
"prov": "贵州省",
"py": "daozhen"
},
{
"city": "务川",
"district": "遵义市",
"prov": "贵州省",
"py": "wuchuan"
},
{
"city": "凤冈",
"district": "遵义市",
"prov": "贵州省",
"py": "fenggang"
},
{
"city": "湄潭",
"district": "遵义市",
"prov": "贵州省",
"py": "meitan"
},
{
"city": "余庆",
"district": "遵义市",
"prov": "贵州省",
"py": "yuqing"
},
{
"city": "习水",
"district": "遵义市",
"prov": "贵州省",
"py": "xishui"
},
{
"city": "赤水",
"district": "遵义市",
"prov": "贵州省",
"py": "chishui"
},
{
"city": "仁怀",
"district": "遵义市",
"prov": "贵州省",
"py": "renhuai"
},
{
"city": "安顺",
"district": "安顺市",
"prov": "贵州省",
"py": "anshun"
},
{
"city": "西秀",
"district": "安顺市",
"prov": "贵州省",
"py": "xixiu"
},
{
"city": "平坝",
"district": "安顺市",
"prov": "贵州省",
"py": "pingba"
},
{
"city": "普定",
"district": "安顺市",
"prov": "贵州省",
"py": "puding"
},
{
"city": "镇宁",
"district": "安顺市",
"prov": "贵州省",
"py": "zhenning"
},
{
"city": "关岭",
"district": "安顺市",
"prov": "贵州省",
"py": "guanling"
},
{
"city": "紫云",
"district": "安顺市",
"prov": "贵州省",
"py": "ziyun"
},
{
"city": "毕节",
"district": "毕节市",
"prov": "贵州省",
"py": "bijie"
},
{
"city": "七星关",
"district": "毕节市",
"prov": "贵州省",
"py": "qixingguan"
},
{
"city": "大方",
"district": "毕节市",
"prov": "贵州省",
"py": "dafang"
},
{
"city": "黔西",
"district": "毕节市",
"prov": "贵州省",
"py": "qianxi"
},
{
"city": "金沙",
"district": "毕节市",
"prov": "贵州省",
"py": "jinsha"
},
{
"city": "织金",
"district": "毕节市",
"prov": "贵州省",
"py": "zhijin"
},
{
"city": "纳雍",
"district": "毕节市",
"prov": "贵州省",
"py": "nayong"
},
{
"city": "威宁",
"district": "毕节市",
"prov": "贵州省",
"py": "weining"
},
{
"city": "赫章",
"district": "毕节市",
"prov": "贵州省",
"py": "hezhang"
},
{
"city": "铜仁",
"district": "铜仁市",
"prov": "贵州省",
"py": "tongren"
},
{
"city": "碧江",
"district": "铜仁市",
"prov": "贵州省",
"py": "bijiang"
},
{
"city": "万山",
"district": "铜仁市",
"prov": "贵州省",
"py": "wanshan"
},
{
"city": "江口",
"district": "铜仁市",
"prov": "贵州省",
"py": "jiangkou"
},
{
"city": "玉屏",
"district": "铜仁市",
"prov": "贵州省",
"py": "yuping"
},
{
"city": "石阡",
"district": "铜仁市",
"prov": "贵州省",
"py": "shiqian"
},
{
"city": "思南",
"district": "铜仁市",
"prov": "贵州省",
"py": "sinan"
},
{
"city": "印江",
"district": "铜仁市",
"prov": "贵州省",
"py": "yinjiang"
},
{
"city": "德江",
"district": "铜仁市",
"prov": "贵州省",
"py": "dejiang"
},
{
"city": "沿河",
"district": "铜仁市",
"prov": "贵州省",
"py": "yanhe"
},
{
"city": "松桃",
"district": "铜仁市",
"prov": "贵州省",
"py": "songtao"
},
{
"city": "黔西南",
"district": "黔西南布依族苗族自治州",
"prov": "贵州省",
"py": "qianxinan"
},
{
"city": "兴义",
"district": "黔西南布依族苗族自治州",
"prov": "贵州省",
"py": "xingyi"
},
{
"city": "兴仁",
"district": "黔西南布依族苗族自治州",
"prov": "贵州省",
"py": "xingren"
},
{
"city": "普安",
"district": "黔西南布依族苗族自治州",
"prov": "贵州省",
"py": "puan"
},
{
"city": "晴隆",
"district": "黔西南布依族苗族自治州",
"prov": "贵州省",
"py": "qinglong"
},
{
"city": "贞丰",
"district": "黔西南布依族苗族自治州",
"prov": "贵州省",
"py": "zhenfeng"
},
{
"city": "望谟",
"district": "黔西南布依族苗族自治州",
"prov": "贵州省",
"py": "wangmo"
},
{
"city": "册亨",
"district": "黔西南布依族苗族自治州",
"prov": "贵州省",
"py": "ceheng"
},
{
"city": "安龙",
"district": "黔西南布依族苗族自治州",
"prov": "贵州省",
"py": "anlong"
},
{
"city": "黔东南",
"district": "黔东南苗族侗族自治州",
"prov": "贵州省",
"py": "qiandongnan"
},
{
"city": "凯里",
"district": "黔东南苗族侗族自治州",
"prov": "贵州省",
"py": "kaili"
},
{
"city": "黄平",
"district": "黔东南苗族侗族自治州",
"prov": "贵州省",
"py": "huangping"
},
{
"city": "施秉",
"district": "黔东南苗族侗族自治州",
"prov": "贵州省",
"py": "shibing"
},
{
"city": "三穗",
"district": "黔东南苗族侗族自治州",
"prov": "贵州省",
"py": "sansui"
},
{
"city": "镇远",
"district": "黔东南苗族侗族自治州",
"prov": "贵州省",
"py": "zhenyuan"
},
{
"city": "岑巩",
"district": "黔东南苗族侗族自治州",
"prov": "贵州省",
"py": "cengong"
},
{
"city": "天柱",
"district": "黔东南苗族侗族自治州",
"prov": "贵州省",
"py": "tianzhu"
},
{
"city": "锦屏",
"district": "黔东南苗族侗族自治州",
"prov": "贵州省",
"py": "jinping"
},
{
"city": "剑河",
"district": "黔东南苗族侗族自治州",
"prov": "贵州省",
"py": "jianhe"
},
{
"city": "台江",
"district": "黔东南苗族侗族自治州",
"prov": "贵州省",
"py": "taijiang"
},
{
"city": "黎平",
"district": "黔东南苗族侗族自治州",
"prov": "贵州省",
"py": "liping"
},
{
"city": "榕江",
"district": "黔东南苗族侗族自治州",
"prov": "贵州省",
"py": "rongjiang"
},
{
"city": "从江",
"district": "黔东南苗族侗族自治州",
"prov": "贵州省",
"py": "congjiang"
},
{
"city": "雷山",
"district": "黔东南苗族侗族自治州",
"prov": "贵州省",
"py": "leishan"
},
{
"city": "麻江",
"district": "黔东南苗族侗族自治州",
"prov": "贵州省",
"py": "majiang"
},
{
"city": "丹寨",
"district": "黔东南苗族侗族自治州",
"prov": "贵州省",
"py": "danzhai"
},
{
"city": "黔南",
"district": "黔南布依族苗族自治州",
"prov": "贵州省",
"py": "qiannan"
},
{
"city": "都匀",
"district": "黔南布依族苗族自治州",
"prov": "贵州省",
"py": "duyun"
},
{
"city": "福泉",
"district": "黔南布依族苗族自治州",
"prov": "贵州省",
"py": "fuquan"
},
{
"city": "荔波",
"district": "黔南布依族苗族自治州",
"prov": "贵州省",
"py": "libo"
},
{
"city": "贵定",
"district": "黔南布依族苗族自治州",
"prov": "贵州省",
"py": "guiding"
},
{
"city": "瓮安",
"district": "黔南布依族苗族自治州",
"prov": "贵州省",
"py": "wengan"
},
{
"city": "独山",
"district": "黔南布依族苗族自治州",
"prov": "贵州省",
"py": "dushan"
},
{
"city": "平塘",
"district": "黔南布依族苗族自治州",
"prov": "贵州省",
"py": "pingtang"
},
{
"city": "罗甸",
"district": "黔南布依族苗族自治州",
"prov": "贵州省",
"py": "luodian"
},
{
"city": "长顺",
"district": "黔南布依族苗族自治州",
"prov": "贵州省",
"py": "changshun"
},
{
"city": "龙里",
"district": "黔南布依族苗族自治州",
"prov": "贵州省",
"py": "longli"
},
{
"city": "惠水",
"district": "黔南布依族苗族自治州",
"prov": "贵州省",
"py": "huishui"
},
{
"city": "三都",
"district": "黔南布依族苗族自治州",
"prov": "贵州省",
"py": "sandu"
},
{
"city": "昆明",
"district": "昆明市",
"prov": "云南省",
"py": "kunming"
},
{
"city": "五华区",
"district": "昆明市",
"prov": "云南省",
"py": "wuhuaqu"
},
{
"city": "盘龙",
"district": "昆明市",
"prov": "云南省",
"py": "panlong"
},
{
"city": "官渡",
"district": "昆明市",
"prov": "云南省",
"py": "guandu"
},
{
"city": "西山",
"district": "昆明市",
"prov": "云南省",
"py": "xishan"
},
{
"city": "东川",
"district": "昆明市",
"prov": "云南省",
"py": "dongchuan"
},
{
"city": "呈贡",
"district": "昆明市",
"prov": "云南省",
"py": "chenggong"
},
{
"city": "晋宁",
"district": "昆明市",
"prov": "云南省",
"py": "jinning"
},
{
"city": "富民",
"district": "昆明市",
"prov": "云南省",
"py": "fumin"
},
{
"city": "宜良",
"district": "昆明市",
"prov": "云南省",
"py": "yiliang"
},
{
"city": "石林",
"district": "昆明市",
"prov": "云南省",
"py": "shilin"
},
{
"city": "嵩明",
"district": "昆明市",
"prov": "云南省",
"py": "songming"
},
{
"city": "禄劝",
"district": "昆明市",
"prov": "云南省",
"py": "luquan"
},
{
"city": "寻甸",
"district": "昆明市",
"prov": "云南省",
"py": "xundian"
},
{
"city": "安宁",
"district": "昆明市",
"prov": "云南省",
"py": "anning"
},
{
"city": "曲靖",
"district": "曲靖市",
"prov": "云南省",
"py": "qujing"
},
{
"city": "麒麟",
"district": "曲靖市",
"prov": "云南省",
"py": "qilin"
},
{
"city": "沾益",
"district": "曲靖市",
"prov": "云南省",
"py": "zhanyi"
},
{
"city": "马龙",
"district": "曲靖市",
"prov": "云南省",
"py": "malong"
},
{
"city": "陆良",
"district": "曲靖市",
"prov": "云南省",
"py": "luliang"
},
{
"city": "师宗",
"district": "曲靖市",
"prov": "云南省",
"py": "shizong"
},
{
"city": "罗平",
"district": "曲靖市",
"prov": "云南省",
"py": "luoping"
},
{
"city": "富源",
"district": "曲靖市",
"prov": "云南省",
"py": "fuyuan"
},
{
"city": "会泽",
"district": "曲靖市",
"prov": "云南省",
"py": "huize"
},
{
"city": "宣威",
"district": "曲靖市",
"prov": "云南省",
"py": "xuanwei"
},
{
"city": "玉溪",
"district": "玉溪市",
"prov": "云南省",
"py": "yuxi"
},
{
"city": "红塔",
"district": "玉溪市",
"prov": "云南省",
"py": "hongta"
},
{
"city": "江川",
"district": "玉溪市",
"prov": "云南省",
"py": "jiangchuan"
},
{
"city": "澄江",
"district": "玉溪市",
"prov": "云南省",
"py": "chengjiang"
},
{
"city": "通海",
"district": "玉溪市",
"prov": "云南省",
"py": "tonghai"
},
{
"city": "华宁",
"district": "玉溪市",
"prov": "云南省",
"py": "huaning"
},
{
"city": "易门",
"district": "玉溪市",
"prov": "云南省",
"py": "yimen"
},
{
"city": "峨山",
"district": "玉溪市",
"prov": "云南省",
"py": "eshan"
},
{
"city": "新平",
"district": "玉溪市",
"prov": "云南省",
"py": "xinping"
},
{
"city": "元江",
"district": "玉溪市",
"prov": "云南省",
"py": "yuanjiang"
},
{
"city": "保山",
"district": "保山市",
"prov": "云南省",
"py": "baoshan"
},
{
"city": "隆阳",
"district": "保山市",
"prov": "云南省",
"py": "longyang"
},
{
"city": "施甸",
"district": "保山市",
"prov": "云南省",
"py": "shidian"
},
{
"city": "龙陵",
"district": "保山市",
"prov": "云南省",
"py": "longling"
},
{
"city": "昌宁",
"district": "保山市",
"prov": "云南省",
"py": "changning"
},
{
"city": "腾冲",
"district": "保山市",
"prov": "云南省",
"py": "tengchong"
},
{
"city": "昭通",
"district": "昭通市",
"prov": "云南省",
"py": "zhaotong"
},
{
"city": "昭阳",
"district": "昭通市",
"prov": "云南省",
"py": "zhaoyang"
},
{
"city": "鲁甸",
"district": "昭通市",
"prov": "云南省",
"py": "ludian"
},
{
"city": "巧家",
"district": "昭通市",
"prov": "云南省",
"py": "qiaojia"
},
{
"city": "盐津",
"district": "昭通市",
"prov": "云南省",
"py": "yanjin"
},
{
"city": "大关",
"district": "昭通市",
"prov": "云南省",
"py": "daguan"
},
{
"city": "永善",
"district": "昭通市",
"prov": "云南省",
"py": "yongshan"
},
{
"city": "绥江",
"district": "昭通市",
"prov": "云南省",
"py": "suijiang"
},
{
"city": "镇雄",
"district": "昭通市",
"prov": "云南省",
"py": "zhenxiong"
},
{
"city": "彝良",
"district": "昭通市",
"prov": "云南省",
"py": "yiliang"
},
{
"city": "威信",
"district": "昭通市",
"prov": "云南省",
"py": "weixin"
},
{
"city": "水富",
"district": "昭通市",
"prov": "云南省",
"py": "shuifu"
},
{
"city": "丽江",
"district": "丽江市",
"prov": "云南省",
"py": "lijiang"
},
{
"city": "古城区",
"district": "丽江市",
"prov": "云南省",
"py": "guchengqu"
},
{
"city": "玉龙",
"district": "丽江市",
"prov": "云南省",
"py": "yulong"
},
{
"city": "永胜",
"district": "丽江市",
"prov": "云南省",
"py": "yongsheng"
},
{
"city": "华坪",
"district": "丽江市",
"prov": "云南省",
"py": "huaping"
},
{
"city": "宁蒗",
"district": "丽江市",
"prov": "云南省",
"py": "ninglang"
},
{
"city": "普洱",
"district": "普洱市",
"prov": "云南省",
"py": "puer"
},
{
"city": "思茅",
"district": "普洱市",
"prov": "云南省",
"py": "simao"
},
{
"city": "宁洱",
"district": "普洱市",
"prov": "云南省",
"py": "ninger"
},
{
"city": "墨江",
"district": "普洱市",
"prov": "云南省",
"py": "mojiang"
},
{
"city": "景东",
"district": "普洱市",
"prov": "云南省",
"py": "jingdong"
},
{
"city": "景谷",
"district": "普洱市",
"prov": "云南省",
"py": "jinggu"
},
{
"city": "镇沅",
"district": "普洱市",
"prov": "云南省",
"py": "zhenyuan"
},
{
"city": "江城",
"district": "普洱市",
"prov": "云南省",
"py": "jiangcheng"
},
{
"city": "孟连",
"district": "普洱市",
"prov": "云南省",
"py": "menglian"
},
{
"city": "澜沧",
"district": "普洱市",
"prov": "云南省",
"py": "lancang"
},
{
"city": "西盟",
"district": "普洱市",
"prov": "云南省",
"py": "ximeng"
},
{
"city": "临沧",
"district": "临沧市",
"prov": "云南省",
"py": "lincang"
},
{
"city": "临翔",
"district": "临沧市",
"prov": "云南省",
"py": "linxiang"
},
{
"city": "凤庆",
"district": "临沧市",
"prov": "云南省",
"py": "fengqing"
},
{
"city": "云县",
"district": "临沧市",
"prov": "云南省",
"py": "yunxian"
},
{
"city": "永德",
"district": "临沧市",
"prov": "云南省",
"py": "yongde"
},
{
"city": "镇康",
"district": "临沧市",
"prov": "云南省",
"py": "zhenkang"
},
{
"city": "双江",
"district": "临沧市",
"prov": "云南省",
"py": "shuangjiang"
},
{
"city": "耿马",
"district": "临沧市",
"prov": "云南省",
"py": "gengma"
},
{
"city": "沧源",
"district": "临沧市",
"prov": "云南省",
"py": "cangyuan"
},
{
"city": "楚雄",
"district": "楚雄彝族自治州",
"prov": "云南省",
"py": "chuxiong"
},
{
"city": "楚雄市",
"district": "楚雄彝族自治州",
"prov": "云南省",
"py": "chuxiongshi"
},
{
"city": "双柏",
"district": "楚雄彝族自治州",
"prov": "云南省",
"py": "shuangbai"
},
{
"city": "牟定",
"district": "楚雄彝族自治州",
"prov": "云南省",
"py": "mouding"
},
{
"city": "南华",
"district": "楚雄彝族自治州",
"prov": "云南省",
"py": "nanhua"
},
{
"city": "姚安",
"district": "楚雄彝族自治州",
"prov": "云南省",
"py": "yaoan"
},
{
"city": "大姚",
"district": "楚雄彝族自治州",
"prov": "云南省",
"py": "dayao"
},
{
"city": "永仁",
"district": "楚雄彝族自治州",
"prov": "云南省",
"py": "yongren"
},
{
"city": "元谋",
"district": "楚雄彝族自治州",
"prov": "云南省",
"py": "yuanmou"
},
{
"city": "武定",
"district": "楚雄彝族自治州",
"prov": "云南省",
"py": "wuding"
},
{
"city": "禄丰",
"district": "楚雄彝族自治州",
"prov": "云南省",
"py": "lufeng"
},
{
"city": "红河",
"district": "红河哈尼族彝族自治州",
"prov": "云南省",
"py": "honghe"
},
{
"city": "个旧",
"district": "红河哈尼族彝族自治州",
"prov": "云南省",
"py": "gejiu"
},
{
"city": "开远",
"district": "红河哈尼族彝族自治州",
"prov": "云南省",
"py": "kaiyuan"
},
{
"city": "蒙自",
"district": "红河哈尼族彝族自治州",
"prov": "云南省",
"py": "mengzi"
},
{
"city": "弥勒",
"district": "红河哈尼族彝族自治州",
"prov": "云南省",
"py": "mile"
},
{
"city": "屏边",
"district": "红河哈尼族彝族自治州",
"prov": "云南省",
"py": "pingbian"
},
{
"city": "建水",
"district": "红河哈尼族彝族自治州",
"prov": "云南省",
"py": "jianshui"
},
{
"city": "石屏",
"district": "红河哈尼族彝族自治州",
"prov": "云南省",
"py": "shiping"
},
{
"city": "泸西",
"district": "红河哈尼族彝族自治州",
"prov": "云南省",
"py": "luxi"
},
{
"city": "元阳",
"district": "红河哈尼族彝族自治州",
"prov": "云南省",
"py": "yuanyang"
},
{
"city": "红河县",
"district": "红河哈尼族彝族自治州",
"prov": "云南省",
"py": "honghexian"
},
{
"city": "金平",
"district": "红河哈尼族彝族自治州",
"prov": "云南省",
"py": "jinping"
},
{
"city": "绿春",
"district": "红河哈尼族彝族自治州",
"prov": "云南省",
"py": "lvchun"
},
{
"city": "河口",
"district": "红河哈尼族彝族自治州",
"prov": "云南省",
"py": "hekou"
},
{
"city": "文山",
"district": "文山壮族苗族自治州",
"prov": "云南省",
"py": "wenshan"
},
{
"city": "文山市",
"district": "文山壮族苗族自治州",
"prov": "云南省",
"py": "wenshanshi"
},
{
"city": "砚山",
"district": "文山壮族苗族自治州",
"prov": "云南省",
"py": "yanshan"
},
{
"city": "西畴",
"district": "文山壮族苗族自治州",
"prov": "云南省",
"py": "xichou"
},
{
"city": "麻栗坡",
"district": "文山壮族苗族自治州",
"prov": "云南省",
"py": "malipo"
},
{
"city": "马关",
"district": "文山壮族苗族自治州",
"prov": "云南省",
"py": "maguan"
},
{
"city": "丘北",
"district": "文山壮族苗族自治州",
"prov": "云南省",
"py": "qiubei"
},
{
"city": "广南",
"district": "文山壮族苗族自治州",
"prov": "云南省",
"py": "guangnan"
},
{
"city": "富宁",
"district": "文山壮族苗族自治州",
"prov": "云南省",
"py": "funing"
},
{
"city": "西双版纳",
"district": "西双版纳傣族自治州",
"prov": "云南省",
"py": "xishuangbanna"
},
{
"city": "景洪",
"district": "西双版纳傣族自治州",
"prov": "云南省",
"py": "jinghong"
},
{
"city": "勐海",
"district": "西双版纳傣族自治州",
"prov": "云南省",
"py": "menghai"
},
{
"city": "勐腊",
"district": "西双版纳傣族自治州",
"prov": "云南省",
"py": "mengla"
},
{
"city": "大理",
"district": "大理白族自治州",
"prov": "云南省",
"py": "dali"
},
{
"city": "大理市",
"district": "大理白族自治州",
"prov": "云南省",
"py": "dalishi"
},
{
"city": "漾濞",
"district": "大理白族自治州",
"prov": "云南省",
"py": "yangbi"
},
{
"city": "祥云",
"district": "大理白族自治州",
"prov": "云南省",
"py": "xiangyun"
},
{
"city": "宾川",
"district": "大理白族自治州",
"prov": "云南省",
"py": "binchuan"
},
{
"city": "弥渡",
"district": "大理白族自治州",
"prov": "云南省",
"py": "midu"
},
{
"city": "南涧",
"district": "大理白族自治州",
"prov": "云南省",
"py": "nanjian"
},
{
"city": "巍山",
"district": "大理白族自治州",
"prov": "云南省",
"py": "weishan"
},
{
"city": "永平",
"district": "大理白族自治州",
"prov": "云南省",
"py": "yongping"
},
{
"city": "云龙",
"district": "大理白族自治州",
"prov": "云南省",
"py": "yunlong"
},
{
"city": "洱源",
"district": "大理白族自治州",
"prov": "云南省",
"py": "eryuan"
},
{
"city": "剑川",
"district": "大理白族自治州",
"prov": "云南省",
"py": "jianchuan"
},
{
"city": "鹤庆",
"district": "大理白族自治州",
"prov": "云南省",
"py": "heqing"
},
{
"city": "德宏",
"district": "德宏傣族景颇族自治州",
"prov": "云南省",
"py": "dehong"
},
{
"city": "瑞丽",
"district": "德宏傣族景颇族自治州",
"prov": "云南省",
"py": "ruili"
},
{
"city": "芒市",
"district": "德宏傣族景颇族自治州",
"prov": "云南省",
"py": "mangshi"
},
{
"city": "梁河",
"district": "德宏傣族景颇族自治州",
"prov": "云南省",
"py": "lianghe"
},
{
"city": "盈江",
"district": "德宏傣族景颇族自治州",
"prov": "云南省",
"py": "yingjiang"
},
{
"city": "陇川",
"district": "德宏傣族景颇族自治州",
"prov": "云南省",
"py": "longchuan"
},
{
"city": "怒江",
"district": "怒江傈僳族自治州",
"prov": "云南省",
"py": "nujiang"
},
{
"city": "泸水",
"district": "怒江傈僳族自治州",
"prov": "云南省",
"py": "lushui"
},
{
"city": "福贡",
"district": "怒江傈僳族自治州",
"prov": "云南省",
"py": "fugong"
},
{
"city": "贡山",
"district": "怒江傈僳族自治州",
"prov": "云南省",
"py": "gongshan"
},
{
"city": "兰坪",
"district": "怒江傈僳族自治州",
"prov": "云南省",
"py": "lanping"
},
{
"city": "迪庆",
"district": "迪庆藏族自治州",
"prov": "云南省",
"py": "diqing"
},
{
"city": "香格里拉",
"district": "迪庆藏族自治州",
"prov": "云南省",
"py": "xianggelila"
},
{
"city": "德钦",
"district": "迪庆藏族自治州",
"prov": "云南省",
"py": "deqin"
},
{
"city": "维西",
"district": "迪庆藏族自治州",
"prov": "云南省",
"py": "weixi"
},
{
"city": "拉萨",
"district": "拉萨市",
"prov": "西藏自治区",
"py": "lasa"
},
{
"city": "城关区",
"district": "拉萨市",
"prov": "西藏自治区",
"py": "chengguanqu"
},
{
"city": "堆龙德庆",
"district": "拉萨市",
"prov": "西藏自治区",
"py": "duilongdeqing"
},
{
"city": "达孜",
"district": "拉萨市",
"prov": "西藏自治区",
"py": "dazi"
},
{
"city": "林周",
"district": "拉萨市",
"prov": "西藏自治区",
"py": "linzhou"
},
{
"city": "当雄",
"district": "拉萨市",
"prov": "西藏自治区",
"py": "dangxiong"
},
{
"city": "尼木",
"district": "拉萨市",
"prov": "西藏自治区",
"py": "nimu"
},
{
"city": "曲水",
"district": "拉萨市",
"prov": "西藏自治区",
"py": "qushui"
},
{
"city": "墨竹工卡",
"district": "拉萨市",
"prov": "西藏自治区",
"py": "mozhugongka"
},
{
"city": "日喀则",
"district": "日喀则市",
"prov": "西藏自治区",
"py": "rikaze"
},
{
"city": "桑珠孜",
"district": "日喀则市",
"prov": "西藏自治区",
"py": "sangzhuzi"
},
{
"city": "南木林",
"district": "日喀则市",
"prov": "西藏自治区",
"py": "nanmulin"
},
{
"city": "江孜",
"district": "日喀则市",
"prov": "西藏自治区",
"py": "jiangzi"
},
{
"city": "定日",
"district": "日喀则市",
"prov": "西藏自治区",
"py": "dingri"
},
{
"city": "萨迦",
"district": "日喀则市",
"prov": "西藏自治区",
"py": "sajia"
},
{
"city": "拉孜",
"district": "日喀则市",
"prov": "西藏自治区",
"py": "lazi"
},
{
"city": "昂仁",
"district": "日喀则市",
"prov": "西藏自治区",
"py": "angren"
},
{
"city": "谢通门",
"district": "日喀则市",
"prov": "西藏自治区",
"py": "xietongmen"
},
{
"city": "白朗",
"district": "日喀则市",
"prov": "西藏自治区",
"py": "bailang"
},
{
"city": "仁布",
"district": "日喀则市",
"prov": "西藏自治区",
"py": "renbu"
},
{
"city": "康马",
"district": "日喀则市",
"prov": "西藏自治区",
"py": "kangma"
},
{
"city": "定结",
"district": "日喀则市",
"prov": "西藏自治区",
"py": "dingjie"
},
{
"city": "仲巴",
"district": "日喀则市",
"prov": "西藏自治区",
"py": "zhongba"
},
{
"city": "亚东",
"district": "日喀则市",
"prov": "西藏自治区",
"py": "yadong"
},
{
"city": "吉隆",
"district": "日喀则市",
"prov": "西藏自治区",
"py": "jilong"
},
{
"city": "聂拉木",
"district": "日喀则市",
"prov": "西藏自治区",
"py": "nielamu"
},
{
"city": "萨嘎",
"district": "日喀则市",
"prov": "西藏自治区",
"py": "saga"
},
{
"city": "岗巴",
"district": "日喀则市",
"prov": "西藏自治区",
"py": "gangba"
},
{
"city": "昌都",
"district": "昌都市",
"prov": "西藏自治区",
"py": "changdu"
},
{
"city": "卡若",
"district": "昌都市",
"prov": "西藏自治区",
"py": "karuo"
},
{
"city": "江达",
"district": "昌都市",
"prov": "西藏自治区",
"py": "jiangda"
},
{
"city": "贡觉",
"district": "昌都市",
"prov": "西藏自治区",
"py": "gongjue"
},
{
"city": "类乌齐",
"district": "昌都市",
"prov": "西藏自治区",
"py": "leiwuqi"
},
{
"city": "丁青",
"district": "昌都市",
"prov": "西藏自治区",
"py": "dingqing"
},
{
"city": "察雅",
"district": "昌都市",
"prov": "西藏自治区",
"py": "chaya"
},
{
"city": "八宿",
"district": "昌都市",
"prov": "西藏自治区",
"py": "baxiu"
},
{
"city": "左贡",
"district": "昌都市",
"prov": "西藏自治区",
"py": "zuogong"
},
{
"city": "芒康",
"district": "昌都市",
"prov": "西藏自治区",
"py": "mangkang"
},
{
"city": "洛隆",
"district": "昌都市",
"prov": "西藏自治区",
"py": "luolong"
},
{
"city": "边坝",
"district": "昌都市",
"prov": "西藏自治区",
"py": "bianba"
},
{
"city": "林芝",
"district": "林芝市",
"prov": "西藏自治区",
"py": "linzhi"
},
{
"city": "巴宜",
"district": "林芝市",
"prov": "西藏自治区",
"py": "bayi"
},
{
"city": "工布江达",
"district": "林芝市",
"prov": "西藏自治区",
"py": "gongbujiangda"
},
{
"city": "米林",
"district": "林芝市",
"prov": "西藏自治区",
"py": "milin"
},
{
"city": "墨脱",
"district": "林芝市",
"prov": "西藏自治区",
"py": "motuo"
},
{
"city": "波密",
"district": "林芝市",
"prov": "西藏自治区",
"py": "bomi"
},
{
"city": "察隅",
"district": "林芝市",
"prov": "西藏自治区",
"py": "chayu"
},
{
"city": "朗县",
"district": "林芝市",
"prov": "西藏自治区",
"py": "langxian"
},
{
"city": "山南",
"district": "山南市",
"prov": "西藏自治区",
"py": "shannan"
},
{
"city": "乃东",
"district": "山南市",
"prov": "西藏自治区",
"py": "naidong"
},
{
"city": "扎囊",
"district": "山南市",
"prov": "西藏自治区",
"py": "zhanang"
},
{
"city": "贡嘎",
"district": "山南市",
"prov": "西藏自治区",
"py": "gongga"
},
{
"city": "桑日",
"district": "山南市",
"prov": "西藏自治区",
"py": "sangri"
},
{
"city": "琼结",
"district": "山南市",
"prov": "西藏自治区",
"py": "qiongjie"
},
{
"city": "曲松",
"district": "山南市",
"prov": "西藏自治区",
"py": "qusong"
},
{
"city": "措美",
"district": "山南市",
"prov": "西藏自治区",
"py": "cuomei"
},
{
"city": "洛扎",
"district": "山南市",
"prov": "西藏自治区",
"py": "luozha"
},
{
"city": "加查",
"district": "山南市",
"prov": "西藏自治区",
"py": "jiacha"
},
{
"city": "隆子",
"district": "山南市",
"prov": "西藏自治区",
"py": "longzi"
},
{
"city": "错那",
"district": "山南市",
"prov": "西藏自治区",
"py": "cuona"
},
{
"city": "浪卡子",
"district": "山南市",
"prov": "西藏自治区",
"py": "langkazi"
},
{
"city": "那曲",
"district": "那曲市",
"prov": "西藏自治区",
"py": "naqu"
},
{
"city": "色尼",
"district": "那曲市",
"prov": "西藏自治区",
"py": "seni"
},
{
"city": "嘉黎",
"district": "那曲市",
"prov": "西藏自治区",
"py": "jiali"
},
{
"city": "比如",
"district": "那曲市",
"prov": "西藏自治区",
"py": "biru"
},
{
"city": "聂荣",
"district": "那曲市",
"prov": "西藏自治区",
"py": "nierong"
},
{
"city": "安多",
"district": "那曲市",
"prov": "西藏自治区",
"py": "anduo"
},
{
"city": "申扎",
"district": "那曲市",
"prov": "西藏自治区",
"py": "shenzha"
},
{
"city": "索县",
"district": "那曲市",
"prov": "西藏自治区",
"py": "suoxian"
},
{
"city": "班戈",
"district": "那曲市",
"prov": "西藏自治区",
"py": "bange"
},
{
"city": "巴青",
"district": "那曲市",
"prov": "西藏自治区",
"py": "baqing"
},
{
"city": "尼玛",
"district": "那曲市",
"prov": "西藏自治区",
"py": "nima"
},
{
"city": "双湖",
"district": "那曲市",
"prov": "西藏自治区",
"py": "shuanghu"
},
{
"city": "阿里地区",
"district": "阿里地区",
"prov": "西藏自治区",
"py": "alidiqu"
},
{
"city": "普兰",
"district": "阿里地区",
"prov": "西藏自治区",
"py": "pulan"
},
{
"city": "札达",
"district": "阿里地区",
"prov": "西藏自治区",
"py": "zhada"
},
{
"city": "噶尔",
"district": "阿里地区",
"prov": "西藏自治区",
"py": "gaer"
},
{
"city": "日土",
"district": "阿里地区",
"prov": "西藏自治区",
"py": "ritu"
},
{
"city": "革吉",
"district": "阿里地区",
"prov": "西藏自治区",
"py": "geji"
},
{
"city": "改则",
"district": "阿里地区",
"prov": "西藏自治区",
"py": "gaize"
},
{
"city": "措勤",
"district": "阿里地区",
"prov": "西藏自治区",
"py": "cuoqin"
},
{
"city": "西安",
"district": "西安市",
"prov": "陕西省",
"py": "xian"
},
{
"city": "新城区",
"district": "西安市",
"prov": "陕西省",
"py": "xinchengqu"
},
{
"city": "碑林",
"district": "西安市",
"prov": "陕西省",
"py": "beilin"
},
{
"city": "莲湖",
"district": "西安市",
"prov": "陕西省",
"py": "lianhu"
},
{
"city": "灞桥",
"district": "西安市",
"prov": "陕西省",
"py": "baqiao"
},
{
"city": "未央",
"district": "西安市",
"prov": "陕西省",
"py": "weiyang"
},
{
"city": "雁塔",
"district": "西安市",
"prov": "陕西省",
"py": "yanta"
},
{
"city": "阎良",
"district": "西安市",
"prov": "陕西省",
"py": "yanliang"
},
{
"city": "临潼",
"district": "西安市",
"prov": "陕西省",
"py": "lintong"
},
{
"city": "长安",
"district": "西安市",
"prov": "陕西省",
"py": "changan"
},
{
"city": "高陵",
"district": "西安市",
"prov": "陕西省",
"py": "gaoling"
},
{
"city": "鄠邑",
"district": "西安市",
"prov": "陕西省",
"py": "huyi"
},
{
"city": "蓝田",
"district": "西安市",
"prov": "陕西省",
"py": "lantian"
},
{
"city": "周至",
"district": "西安市",
"prov": "陕西省",
"py": "zhouzhi"
},
{
"city": "铜川",
"district": "铜川市",
"prov": "陕西省",
"py": "tongchuan"
},
{
"city": "王益",
"district": "铜川市",
"prov": "陕西省",
"py": "wangyi"
},
{
"city": "印台",
"district": "铜川市",
"prov": "陕西省",
"py": "yintai"
},
{
"city": "耀州",
"district": "铜川市",
"prov": "陕西省",
"py": "yaozhou"
},
{
"city": "宜君",
"district": "铜川市",
"prov": "陕西省",
"py": "yijun"
},
{
"city": "宝鸡",
"district": "宝鸡市",
"prov": "陕西省",
"py": "baoji"
},
{
"city": "渭滨",
"district": "宝鸡市",
"prov": "陕西省",
"py": "weibin"
},
{
"city": "金台",
"district": "宝鸡市",
"prov": "陕西省",
"py": "jintai"
},
{
"city": "陈仓",
"district": "宝鸡市",
"prov": "陕西省",
"py": "chencang"
},
{
"city": "凤翔",
"district": "宝鸡市",
"prov": "陕西省",
"py": "fengxiang"
},
{
"city": "岐山",
"district": "宝鸡市",
"prov": "陕西省",
"py": "qishan"
},
{
"city": "扶风",
"district": "宝鸡市",
"prov": "陕西省",
"py": "fufeng"
},
{
"city": "眉县",
"district": "宝鸡市",
"prov": "陕西省",
"py": "meixian"
},
{
"city": "陇县",
"district": "宝鸡市",
"prov": "陕西省",
"py": "longxian"
},
{
"city": "千阳",
"district": "宝鸡市",
"prov": "陕西省",
"py": "qianyang"
},
{
"city": "麟游",
"district": "宝鸡市",
"prov": "陕西省",
"py": "linyou"
},
{
"city": "凤县",
"district": "宝鸡市",
"prov": "陕西省",
"py": "fengxian"
},
{
"city": "太白",
"district": "宝鸡市",
"prov": "陕西省",
"py": "taibai"
},
{
"city": "咸阳",
"district": "咸阳市",
"prov": "陕西省",
"py": "xianyang"
},
{
"city": "秦都",
"district": "咸阳市",
"prov": "陕西省",
"py": "qindu"
},
{
"city": "杨陵",
"district": "咸阳市",
"prov": "陕西省",
"py": "yangling"
},
{
"city": "渭城",
"district": "咸阳市",
"prov": "陕西省",
"py": "weicheng"
},
{
"city": "三原",
"district": "咸阳市",
"prov": "陕西省",
"py": "sanyuan"
},
{
"city": "泾阳",
"district": "咸阳市",
"prov": "陕西省",
"py": "jingyang"
},
{
"city": "乾县",
"district": "咸阳市",
"prov": "陕西省",
"py": "qianxian"
},
{
"city": "礼泉",
"district": "咸阳市",
"prov": "陕西省",
"py": "liquan"
},
{
"city": "永寿",
"district": "咸阳市",
"prov": "陕西省",
"py": "yongshou"
},
{
"city": "长武",
"district": "咸阳市",
"prov": "陕西省",
"py": "changwu"
},
{
"city": "旬邑",
"district": "咸阳市",
"prov": "陕西省",
"py": "xunyi"
},
{
"city": "淳化",
"district": "咸阳市",
"prov": "陕西省",
"py": "chunhua"
},
{
"city": "武功",
"district": "咸阳市",
"prov": "陕西省",
"py": "wugong"
},
{
"city": "兴平",
"district": "咸阳市",
"prov": "陕西省",
"py": "xingping"
},
{
"city": "彬州",
"district": "咸阳市",
"prov": "陕西省",
"py": "binzhou"
},
{
"city": "渭南",
"district": "渭南市",
"prov": "陕西省",
"py": "weinan"
},
{
"city": "临渭",
"district": "渭南市",
"prov": "陕西省",
"py": "linwei"
},
{
"city": "华州",
"district": "渭南市",
"prov": "陕西省",
"py": "huazhou"
},
{
"city": "潼关",
"district": "渭南市",
"prov": "陕西省",
"py": "tongguan"
},
{
"city": "大荔",
"district": "渭南市",
"prov": "陕西省",
"py": "dali"
},
{
"city": "合阳",
"district": "渭南市",
"prov": "陕西省",
"py": "heyang"
},
{
"city": "澄城",
"district": "渭南市",
"prov": "陕西省",
"py": "chengcheng"
},
{
"city": "蒲城",
"district": "渭南市",
"prov": "陕西省",
"py": "pucheng"
},
{
"city": "白水",
"district": "渭南市",
"prov": "陕西省",
"py": "baishui"
},
{
"city": "富平",
"district": "渭南市",
"prov": "陕西省",
"py": "fuping"
},
{
"city": "韩城",
"district": "渭南市",
"prov": "陕西省",
"py": "hancheng"
},
{
"city": "华阴",
"district": "渭南市",
"prov": "陕西省",
"py": "huayin"
},
{
"city": "延安",
"district": "延安市",
"prov": "陕西省",
"py": "yanan"
},
{
"city": "宝塔",
"district": "延安市",
"prov": "陕西省",
"py": "baota"
},
{
"city": "安塞",
"district": "延安市",
"prov": "陕西省",
"py": "ansai"
},
{
"city": "延长",
"district": "延安市",
"prov": "陕西省",
"py": "yanchang"
},
{
"city": "延川",
"district": "延安市",
"prov": "陕西省",
"py": "yanchuan"
},
{
"city": "子长",
"district": "延安市",
"prov": "陕西省",
"py": "zichang"
},
{
"city": "志丹",
"district": "延安市",
"prov": "陕西省",
"py": "zhidan"
},
{
"city": "吴起",
"district": "延安市",
"prov": "陕西省",
"py": "wuqi"
},
{
"city": "甘泉",
"district": "延安市",
"prov": "陕西省",
"py": "ganquan"
},
{
"city": "富县",
"district": "延安市",
"prov": "陕西省",
"py": "fuxian"
},
{
"city": "洛川",
"district": "延安市",
"prov": "陕西省",
"py": "luochuan"
},
{
"city": "宜川",
"district": "延安市",
"prov": "陕西省",
"py": "yichuan"
},
{
"city": "黄龙",
"district": "延安市",
"prov": "陕西省",
"py": "huanglong"
},
{
"city": "黄陵",
"district": "延安市",
"prov": "陕西省",
"py": "huangling"
},
{
"city": "汉中",
"district": "汉中市",
"prov": "陕西省",
"py": "hanzhong"
},
{
"city": "汉台",
"district": "汉中市",
"prov": "陕西省",
"py": "hantai"
},
{
"city": "南郑",
"district": "汉中市",
"prov": "陕西省",
"py": "nanzheng"
},
{
"city": "城固",
"district": "汉中市",
"prov": "陕西省",
"py": "chenggu"
},
{
"city": "洋县",
"district": "汉中市",
"prov": "陕西省",
"py": "yangxian"
},
{
"city": "西乡",
"district": "汉中市",
"prov": "陕西省",
"py": "xixiang"
},
{
"city": "勉县",
"district": "汉中市",
"prov": "陕西省",
"py": "mianxian"
},
{
"city": "宁强",
"district": "汉中市",
"prov": "陕西省",
"py": "ningqiang"
},
{
"city": "略阳",
"district": "汉中市",
"prov": "陕西省",
"py": "lueyang"
},
{
"city": "镇巴",
"district": "汉中市",
"prov": "陕西省",
"py": "zhenba"
},
{
"city": "留坝",
"district": "汉中市",
"prov": "陕西省",
"py": "liuba"
},
{
"city": "佛坪",
"district": "汉中市",
"prov": "陕西省",
"py": "foping"
},
{
"city": "榆林",
"district": "榆林市",
"prov": "陕西省",
"py": "yulin"
},
{
"city": "榆阳",
"district": "榆林市",
"prov": "陕西省",
"py": "yuyang"
},
{
"city": "横山",
"district": "榆林市",
"prov": "陕西省",
"py": "hengshan"
},
{
"city": "府谷",
"district": "榆林市",
"prov": "陕西省",
"py": "fugu"
},
{
"city": "靖边",
"district": "榆林市",
"prov": "陕西省",
"py": "jingbian"
},
{
"city": "定边",
"district": "榆林市",
"prov": "陕西省",
"py": "dingbian"
},
{
"city": "绥德",
"district": "榆林市",
"prov": "陕西省",
"py": "suide"
},
{
"city": "米脂",
"district": "榆林市",
"prov": "陕西省",
"py": "mizhi"
},
{
"city": "佳县",
"district": "榆林市",
"prov": "陕西省",
"py": "jiaxian"
},
{
"city": "吴堡",
"district": "榆林市",
"prov": "陕西省",
"py": "wubu"
},
{
"city": "清涧",
"district": "榆林市",
"prov": "陕西省",
"py": "qingjian"
},
{
"city": "子洲",
"district": "榆林市",
"prov": "陕西省",
"py": "zizhou"
},
{
"city": "神木",
"district": "榆林市",
"prov": "陕西省",
"py": "shenmu"
},
{
"city": "安康",
"district": "安康市",
"prov": "陕西省",
"py": "ankang"
},
{
"city": "汉滨",
"district": "安康市",
"prov": "陕西省",
"py": "hanbin"
},
{
"city": "汉阴",
"district": "安康市",
"prov": "陕西省",
"py": "hanyin"
},
{
"city": "石泉",
"district": "安康市",
"prov": "陕西省",
"py": "shiquan"
},
{
"city": "宁陕",
"district": "安康市",
"prov": "陕西省",
"py": "ningshan"
},
{
"city": "紫阳",
"district": "安康市",
"prov": "陕西省",
"py": "ziyang"
},
{
"city": "岚皋",
"district": "安康市",
"prov": "陕西省",
"py": "langao"
},
{
"city": "平利",
"district": "安康市",
"prov": "陕西省",
"py": "pingli"
},
{
"city": "镇坪",
"district": "安康市",
"prov": "陕西省",
"py": "zhenping"
},
{
"city": "旬阳",
"district": "安康市",
"prov": "陕西省",
"py": "xunyang"
},
{
"city": "白河",
"district": "安康市",
"prov": "陕西省",
"py": "baihe"
},
{
"city": "商洛",
"district": "商洛市",
"prov": "陕西省",
"py": "shangluo"
},
{
"city": "商州",
"district": "商洛市",
"prov": "陕西省",
"py": "shangzhou"
},
{
"city": "洛南",
"district": "商洛市",
"prov": "陕西省",
"py": "luonan"
},
{
"city": "丹凤",
"district": "商洛市",
"prov": "陕西省",
"py": "danfeng"
},
{
"city": "商南",
"district": "商洛市",
"prov": "陕西省",
"py": "shangnan"
},
{
"city": "山阳",
"district": "商洛市",
"prov": "陕西省",
"py": "shanyang"
},
{
"city": "镇安",
"district": "商洛市",
"prov": "陕西省",
"py": "zhenan"
},
{
"city": "柞水",
"district": "商洛市",
"prov": "陕西省",
"py": "zhashui"
},
{
"city": "兰州",
"district": "兰州市",
"prov": "甘肃省",
"py": "lanzhou"
},
{
"city": "城关",
"district": "兰州市",
"prov": "甘肃省",
"py": "chengguan"
},
{
"city": "七里河",
"district": "兰州市",
"prov": "甘肃省",
"py": "qilihe"
},
{
"city": "西固",
"district": "兰州市",
"prov": "甘肃省",
"py": "xigu"
},
{
"city": "安宁区",
"district": "兰州市",
"prov": "甘肃省",
"py": "anningqu"
},
{
"city": "红古",
"district": "兰州市",
"prov": "甘肃省",
"py": "honggu"
},
{
"city": "永登",
"district": "兰州市",
"prov": "甘肃省",
"py": "yongdeng"
},
{
"city": "皋兰",
"district": "兰州市",
"prov": "甘肃省",
"py": "gaolan"
},
{
"city": "榆中",
"district": "兰州市",
"prov": "甘肃省",
"py": "yuzhong"
},
{
"city": "嘉峪关",
"district": "嘉峪关市",
"prov": "甘肃省",
"py": "jiayuguan"
},
{
"city": "金昌",
"district": "金昌市",
"prov": "甘肃省",
"py": "jinchang"
},
{
"city": "金川区",
"district": "金昌市",
"prov": "甘肃省",
"py": "jinchuanqu"
},
{
"city": "永昌",
"district": "金昌市",
"prov": "甘肃省",
"py": "yongchang"
},
{
"city": "白银",
"district": "白银市",
"prov": "甘肃省",
"py": "baiyin"
},
{
"city": "白银区",
"district": "白银市",
"prov": "甘肃省",
"py": "baiyinqu"
},
{
"city": "平川",
"district": "白银市",
"prov": "甘肃省",
"py": "pingchuan"
},
{
"city": "靖远",
"district": "白银市",
"prov": "甘肃省",
"py": "jingyuan"
},
{
"city": "会宁",
"district": "白银市",
"prov": "甘肃省",
"py": "huining"
},
{
"city": "景泰",
"district": "白银市",
"prov": "甘肃省",
"py": "jingtai"
},
{
"city": "天水",
"district": "天水市",
"prov": "甘肃省",
"py": "tianshui"
},
{
"city": "秦州",
"district": "天水市",
"prov": "甘肃省",
"py": "qinzhou"
},
{
"city": "麦积",
"district": "天水市",
"prov": "甘肃省",
"py": "maiji"
},
{
"city": "清水",
"district": "天水市",
"prov": "甘肃省",
"py": "qingshui"
},
{
"city": "秦安",
"district": "天水市",
"prov": "甘肃省",
"py": "qinan"
},
{
"city": "甘谷",
"district": "天水市",
"prov": "甘肃省",
"py": "gangu"
},
{
"city": "武山",
"district": "天水市",
"prov": "甘肃省",
"py": "wushan"
},
{
"city": "张家川",
"district": "天水市",
"prov": "甘肃省",
"py": "zhangjiachuan"
},
{
"city": "武威",
"district": "武威市",
"prov": "甘肃省",
"py": "wuwei"
},
{
"city": "凉州",
"district": "武威市",
"prov": "甘肃省",
"py": "liangzhou"
},
{
"city": "民勤",
"district": "武威市",
"prov": "甘肃省",
"py": "minqin"
},
{
"city": "古浪",
"district": "武威市",
"prov": "甘肃省",
"py": "gulang"
},
{
"city": "天祝",
"district": "武威市",
"prov": "甘肃省",
"py": "tianzhu"
},
{
"city": "张掖",
"district": "张掖市",
"prov": "甘肃省",
"py": "zhangye"
},
{
"city": "甘州",
"district": "张掖市",
"prov": "甘肃省",
"py": "ganzhou"
},
{
"city": "肃南",
"district": "张掖市",
"prov": "甘肃省",
"py": "sunan"
},
{
"city": "民乐",
"district": "张掖市",
"prov": "甘肃省",
"py": "minle"
},
{
"city": "临泽",
"district": "张掖市",
"prov": "甘肃省",
"py": "linze"
},
{
"city": "高台",
"district": "张掖市",
"prov": "甘肃省",
"py": "gaotai"
},
{
"city": "山丹",
"district": "张掖市",
"prov": "甘肃省",
"py": "shandan"
},
{
"city": "平凉",
"district": "平凉市",
"prov": "甘肃省",
"py": "pingliang"
},
{
"city": "崆峒",
"district": "平凉市",
"prov": "甘肃省",
"py": "kongtong"
},
{
"city": "泾川",
"district": "平凉市",
"prov": "甘肃省",
"py": "jingchuan"
},
{
"city": "灵台",
"district": "平凉市",
"prov": "甘肃省",
"py": "lingtai"
},
{
"city": "崇信",
"district": "平凉市",
"prov": "甘肃省",
"py": "chongxin"
},
{
"city": "庄浪",
"district": "平凉市",
"prov": "甘肃省",
"py": "zhuanglang"
},
{
"city": "静宁",
"district": "平凉市",
"prov": "甘肃省",
"py": "jingning"
},
{
"city": "华亭",
"district": "平凉市",
"prov": "甘肃省",
"py": "huating"
},
{
"city": "酒泉",
"district": "酒泉市",
"prov": "甘肃省",
"py": "jiuquan"
},
{
"city": "肃州",
"district": "酒泉市",
"prov": "甘肃省",
"py": "suzhou"
},
{
"city": "金塔",
"district": "酒泉市",
"prov": "甘肃省",
"py": "jinta"
},
{
"city": "瓜州",
"district": "酒泉市",
"prov": "甘肃省",
"py": "guazhou"
},
{
"city": "肃北",
"district": "酒泉市",
"prov": "甘肃省",
"py": "subei"
},
{
"city": "阿克塞",
"district": "酒泉市",
"prov": "甘肃省",
"py": "akesai"
},
{
"city": "玉门",
"district": "酒泉市",
"prov": "甘肃省",
"py": "yumen"
},
{
"city": "敦煌",
"district": "酒泉市",
"prov": "甘肃省",
"py": "dunhuang"
},
{
"city": "庆阳",
"district": "庆阳市",
"prov": "甘肃省",
"py": "qingyang"
},
{
"city": "西峰",
"district": "庆阳市",
"prov": "甘肃省",
"py": "xifeng"
},
{
"city": "庆城",
"district": "庆阳市",
"prov": "甘肃省",
"py": "qingcheng"
},
{
"city": "环县",
"district": "庆阳市",
"prov": "甘肃省",
"py": "huanxian"
},
{
"city": "华池",
"district": "庆阳市",
"prov": "甘肃省",
"py": "huachi"
},
{
"city": "合水",
"district": "庆阳市",
"prov": "甘肃省",
"py": "heshui"
},
{
"city": "正宁",
"district": "庆阳市",
"prov": "甘肃省",
"py": "zhengning"
},
{
"city": "宁县",
"district": "庆阳市",
"prov": "甘肃省",
"py": "ningxian"
},
{
"city": "镇原",
"district": "庆阳市",
"prov": "甘肃省",
"py": "zhenyuan"
},
{
"city": "定西",
"district": "定西市",
"prov": "甘肃省",
"py": "dingxi"
},
{
"city": "安定",
"district": "定西市",
"prov": "甘肃省",
"py": "anding"
},
{
"city": "通渭",
"district": "定西市",
"prov": "甘肃省",
"py": "tongwei"
},
{
"city": "陇西",
"district": "定西市",
"prov": "甘肃省",
"py": "longxi"
},
{
"city": "渭源",
"district": "定西市",
"prov": "甘肃省",
"py": "weiyuan"
},
{
"city": "临洮",
"district": "定西市",
"prov": "甘肃省",
"py": "lintao"
},
{
"city": "漳县",
"district": "定西市",
"prov": "甘肃省",
"py": "zhangxian"
},
{
"city": "岷县",
"district": "定西市",
"prov": "甘肃省",
"py": "minxian"
},
{
"city": "陇南",
"district": "陇南市",
"prov": "甘肃省",
"py": "longnan"
},
{
"city": "武都",
"district": "陇南市",
"prov": "甘肃省",
"py": "wudu"
},
{
"city": "成县",
"district": "陇南市",
"prov": "甘肃省",
"py": "chengxian"
},
{
"city": "文县",
"district": "陇南市",
"prov": "甘肃省",
"py": "wenxian"
},
{
"city": "宕昌",
"district": "陇南市",
"prov": "甘肃省",
"py": "dangchang"
},
{
"city": "康县",
"district": "陇南市",
"prov": "甘肃省",
"py": "kangxian"
},
{
"city": "西和",
"district": "陇南市",
"prov": "甘肃省",
"py": "xihe"
},
{
"city": "礼县",
"district": "陇南市",
"prov": "甘肃省",
"py": "lixian"
},
{
"city": "徽县",
"district": "陇南市",
"prov": "甘肃省",
"py": "huixian"
},
{
"city": "两当",
"district": "陇南市",
"prov": "甘肃省",
"py": "liangdang"
},
{
"city": "临夏",
"district": "临夏回族自治州",
"prov": "甘肃省",
"py": "linxia"
},
{
"city": "临夏市",
"district": "临夏回族自治州",
"prov": "甘肃省",
"py": "linxiashi"
},
{
"city": "临夏县",
"district": "临夏回族自治州",
"prov": "甘肃省",
"py": "linxiaxian"
},
{
"city": "康乐",
"district": "临夏回族自治州",
"prov": "甘肃省",
"py": "kangle"
},
{
"city": "永靖",
"district": "临夏回族自治州",
"prov": "甘肃省",
"py": "yongjing"
},
{
"city": "广河",
"district": "临夏回族自治州",
"prov": "甘肃省",
"py": "guanghe"
},
{
"city": "和政",
"district": "临夏回族自治州",
"prov": "甘肃省",
"py": "hezheng"
},
{
"city": "东乡",
"district": "临夏回族自治州",
"prov": "甘肃省",
"py": "dongxiang"
},
{
"city": "积石山",
"district": "临夏回族自治州",
"prov": "甘肃省",
"py": "jishishan"
},
{
"city": "甘南",
"district": "甘南藏族自治州",
"prov": "甘肃省",
"py": "gannan"
},
{
"city": "合作",
"district": "甘南藏族自治州",
"prov": "甘肃省",
"py": "hezuo"
},
{
"city": "临潭",
"district": "甘南藏族自治州",
"prov": "甘肃省",
"py": "lintan"
},
{
"city": "卓尼",
"district": "甘南藏族自治州",
"prov": "甘肃省",
"py": "zhuoni"
},
{
"city": "舟曲",
"district": "甘南藏族自治州",
"prov": "甘肃省",
"py": "zhouqu"
},
{
"city": "迭部",
"district": "甘南藏族自治州",
"prov": "甘肃省",
"py": "diebu"
},
{
"city": "玛曲",
"district": "甘南藏族自治州",
"prov": "甘肃省",
"py": "maqu"
},
{
"city": "碌曲",
"district": "甘南藏族自治州",
"prov": "甘肃省",
"py": "luqu"
},
{
"city": "夏河",
"district": "甘南藏族自治州",
"prov": "甘肃省",
"py": "xiahe"
},
{
"city": "西宁",
"district": "西宁市",
"prov": "青海省",
"py": "xining"
},
{
"city": "城东区",
"district": "西宁市",
"prov": "青海省",
"py": "chengdongqu"
},
{
"city": "城中区",
"district": "西宁市",
"prov": "青海省",
"py": "chengzhongqu"
},
{
"city": "城西区",
"district": "西宁市",
"prov": "青海省",
"py": "chengxiqu"
},
{
"city": "城北区",
"district": "西宁市",
"prov": "青海省",
"py": "chengbeiqu"
},
{
"city": "大通",
"district": "西宁市",
"prov": "青海省",
"py": "datong"
},
{
"city": "湟中",
"district": "西宁市",
"prov": "青海省",
"py": "huangzhong"
},
{
"city": "湟源",
"district": "西宁市",
"prov": "青海省",
"py": "huangyuan"
},
{
"city": "海东",
"district": "海东市",
"prov": "青海省",
"py": "haidong"
},
{
"city": "乐都",
"district": "海东市",
"prov": "青海省",
"py": "ledu"
},
{
"city": "平安",
"district": "海东市",
"prov": "青海省",
"py": "pingan"
},
{
"city": "民和",
"district": "海东市",
"prov": "青海省",
"py": "minhe"
},
{
"city": "互助",
"district": "海东市",
"prov": "青海省",
"py": "huzhu"
},
{
"city": "化隆",
"district": "海东市",
"prov": "青海省",
"py": "hualong"
},
{
"city": "循化",
"district": "海东市",
"prov": "青海省",
"py": "xunhua"
},
{
"city": "海北",
"district": "海北藏族自治州",
"prov": "青海省",
"py": "haibei"
},
{
"city": "门源",
"district": "海北藏族自治州",
"prov": "青海省",
"py": "menyuan"
},
{
"city": "祁连",
"district": "海北藏族自治州",
"prov": "青海省",
"py": "qilian"
},
{
"city": "海晏",
"district": "海北藏族自治州",
"prov": "青海省",
"py": "haiyan"
},
{
"city": "刚察",
"district": "海北藏族自治州",
"prov": "青海省",
"py": "gangcha"
},
{
"city": "黄南",
"district": "黄南藏族自治州",
"prov": "青海省",
"py": "huangnan"
},
{
"city": "同仁",
"district": "黄南藏族自治州",
"prov": "青海省",
"py": "tongren"
},
{
"city": "尖扎",
"district": "黄南藏族自治州",
"prov": "青海省",
"py": "jianzha"
},
{
"city": "泽库",
"district": "黄南藏族自治州",
"prov": "青海省",
"py": "zeku"
},
{
"city": "河南",
"district": "黄南藏族自治州",
"prov": "青海省",
"py": "henan"
},
{
"city": "海南",
"district": "海南藏族自治州",
"prov": "青海省",
"py": "hainan"
},
{
"city": "共和",
"district": "海南藏族自治州",
"prov": "青海省",
"py": "gonghe"
},
{
"city": "同德",
"district": "海南藏族自治州",
"prov": "青海省",
"py": "tongde"
},
{
"city": "贵德",
"district": "海南藏族自治州",
"prov": "青海省",
"py": "guide"
},
{
"city": "兴海",
"district": "海南藏族自治州",
"prov": "青海省",
"py": "xinghai"
},
{
"city": "贵南",
"district": "海南藏族自治州",
"prov": "青海省",
"py": "guinan"
},
{
"city": "果洛",
"district": "果洛藏族自治州",
"prov": "青海省",
"py": "guoluo"
},
{
"city": "玛沁",
"district": "果洛藏族自治州",
"prov": "青海省",
"py": "maqin"
},
{
"city": "班玛",
"district": "果洛藏族自治州",
"prov": "青海省",
"py": "banma"
},
{
"city": "甘德",
"district": "果洛藏族自治州",
"prov": "青海省",
"py": "gande"
},
{
"city": "达日",
"district": "果洛藏族自治州",
"prov": "青海省",
"py": "dari"
},
{
"city": "久治",
"district": "果洛藏族自治州",
"prov": "青海省",
"py": "jiuzhi"
},
{
"city": "玛多",
"district": "果洛藏族自治州",
"prov": "青海省",
"py": "maduo"
},
{
"city": "玉树",
"district": "玉树藏族自治州",
"prov": "青海省",
"py": "yushu"
},
{
"city": "玉树市",
"district": "玉树藏族自治州",
"prov": "青海省",
"py": "yushushi"
},
{
"city": "杂多",
"district": "玉树藏族自治州",
"prov": "青海省",
"py": "zaduo"
},
{
"city": "称多",
"district": "玉树藏族自治州",
"prov": "青海省",
"py": "chengduo"
},
{
"city": "治多",
"district": "玉树藏族自治州",
"prov": "青海省",
"py": "zhiduo"
},
{
"city": "囊谦",
"district": "玉树藏族自治州",
"prov": "青海省",
"py": "nangqian"
},
{
"city": "曲麻莱",
"district": "玉树藏族自治州",
"prov": "青海省",
"py": "qumalai"
},
{
"city": "海西",
"district": "海西蒙古族藏族自治州",
"prov": "青海省",
"py": "haixi"
},
{
"city": "格尔木",
"district": "海西蒙古族藏族自治州",
"prov": "青海省",
"py": "geermu"
},
{
"city": "德令哈",
"district": "海西蒙古族藏族自治州",
"prov": "青海省",
"py": "delingha"
},
{
"city": "茫崖",
"district": "海西蒙古族藏族自治州",
"prov": "青海省",
"py": "mangya"
},
{
"city": "乌兰",
"district": "海西蒙古族藏族自治州",
"prov": "青海省",
"py": "wulan"
},
{
"city": "都兰",
"district": "海西蒙古族藏族自治州",
"prov": "青海省",
"py": "dulan"
},
{
"city": "天峻",
"district": "海西蒙古族藏族自治州",
"prov": "青海省",
"py": "tianjun"
},
{
"city": "银川",
"district": "银川市",
"prov": "宁夏回族自治区",
"py": "yinchuan"
},
{
"city": "兴庆",
"district": "银川市",
"prov": "宁夏回族自治区",
"py": "xingqing"
},
{
"city": "西夏",
"district": "银川市",
"prov": "宁夏回族自治区",
"py": "xixia"
},
{
"city": "金凤",
"district": "银川市",
"prov": "宁夏回族自治区",
"py": "jinfeng"
},
{
"city": "永宁",
"district": "银川市",
"prov": "宁夏回族自治区",
"py": "yongning"
},
{
"city": "贺兰",
"district": "银川市",
"prov": "宁夏回族自治区",
"py": "helan"
},
{
"city": "灵武",
"district": "银川市",
"prov": "宁夏回族自治区",
"py": "lingwu"
},
{
"city": "石嘴山",
"district": "石嘴山市",
"prov": "宁夏回族自治区",
"py": "shizuishan"
},
{
"city": "大武口",
"district": "石嘴山市",
"prov": "宁夏回族自治区",
"py": "dawukou"
},
{
"city": "惠农",
"district": "石嘴山市",
"prov": "宁夏回族自治区",
"py": "huinong"
},
{
"city": "平罗",
"district": "石嘴山市",
"prov": "宁夏回族自治区",
"py": "pingluo"
},
{
"city": "吴忠",
"district": "吴忠市",
"prov": "宁夏回族自治区",
"py": "wuzhong"
},
{
"city": "利通",
"district": "吴忠市",
"prov": "宁夏回族自治区",
"py": "litong"
},
{
"city": "红寺堡",
"district": "吴忠市",
"prov": "宁夏回族自治区",
"py": "hongsibu"
},
{
"city": "盐池",
"district": "吴忠市",
"prov": "宁夏回族自治区",
"py": "yanchi"
},
{
"city": "同心",
"district": "吴忠市",
"prov": "宁夏回族自治区",
"py": "tongxin"
},
{
"city": "青铜峡",
"district": "吴忠市",
"prov": "宁夏回族自治区",
"py": "qingtongxia"
},
{
"city": "固原",
"district": "固原市",
"prov": "宁夏回族自治区",
"py": "guyuan"
},
{
"city": "原州",
"district": "固原市",
"prov": "宁夏回族自治区",
"py": "yuanzhou"
},
{
"city": "西吉",
"district": "固原市",
"prov": "宁夏回族自治区",
"py": "xiji"
},
{
"city": "隆德",
"district": "固原市",
"prov": "宁夏回族自治区",
"py": "longde"
},
{
"city": "泾源",
"district": "固原市",
"prov": "宁夏回族自治区",
"py": "jingyuan"
},
{
"city": "彭阳",
"district": "固原市",
"prov": "宁夏回族自治区",
"py": "pengyang"
},
{
"city": "中卫",
"district": "中卫市",
"prov": "宁夏回族自治区",
"py": "zhongwei"
},
{
"city": "沙坡头",
"district": "中卫市",
"prov": "宁夏回族自治区",
"py": "shapotou"
},
{
"city": "中宁",
"district": "中卫市",
"prov": "宁夏回族自治区",
"py": "zhongning"
},
{
"city": "海原",
"district": "中卫市",
"prov": "宁夏回族自治区",
"py": "haiyuan"
},
{
"city": "乌鲁木齐",
"district": "乌鲁木齐市",
"prov": "新疆维吾尔自治区",
"py": "wulumuqi"
},
{
"city": "天山",
"district": "乌鲁木齐市",
"prov": "新疆维吾尔自治区",
"py": "tianshan"
},
{
"city": "沙依巴克",
"district": "乌鲁木齐市",
"prov": "新疆维吾尔自治区",
"py": "shayibake"
},
{
"city": "新市区",
"district": "乌鲁木齐市",
"prov": "新疆维吾尔自治区",
"py": "xinshiqu"
},
{
"city": "水磨沟",
"district": "乌鲁木齐市",
"prov": "新疆维吾尔自治区",
"py": "shuimogou"
},
{
"city": "头屯河",
"district": "乌鲁木齐市",
"prov": "新疆维吾尔自治区",
"py": "toutunhe"
},
{
"city": "达坂城",
"district": "乌鲁木齐市",
"prov": "新疆维吾尔自治区",
"py": "dabancheng"
},
{
"city": "米东",
"district": "乌鲁木齐市",
"prov": "新疆维吾尔自治区",
"py": "midong"
},
{
"city": "乌鲁木齐县",
"district": "乌鲁木齐市",
"prov": "新疆维吾尔自治区",
"py": "wulumuqixian"
},
{
"city": "克拉玛依",
"district": "克拉玛依市",
"prov": "新疆维吾尔自治区",
"py": "kelamayi"
},
{
"city": "独山子",
"district": "克拉玛依市",
"prov": "新疆维吾尔自治区",
"py": "dushanzi"
},
{
"city": "克拉玛依区",
"district": "克拉玛依市",
"prov": "新疆维吾尔自治区",
"py": "kelamayiqu"
},
{
"city": "白碱滩",
"district": "克拉玛依市",
"prov": "新疆维吾尔自治区",
"py": "baijiantan"
},
{
"city": "乌尔禾",
"district": "克拉玛依市",
"prov": "新疆维吾尔自治区",
"py": "wuerhe"
},
{
"city": "吐鲁番",
"district": "吐鲁番市",
"prov": "新疆维吾尔自治区",
"py": "tulufan"
},
{
"city": "高昌",
"district": "吐鲁番市",
"prov": "新疆维吾尔自治区",
"py": "gaochang"
},
{
"city": "鄯善",
"district": "吐鲁番市",
"prov": "新疆维吾尔自治区",
"py": "shanshan"
},
{
"city": "托克逊",
"district": "吐鲁番市",
"prov": "新疆维吾尔自治区",
"py": "tuokexun"
},
{
"city": "哈密",
"district": "哈密市",
"prov": "新疆维吾尔自治区",
"py": "hami"
},
{
"city": "伊州",
"district": "哈密市",
"prov": "新疆维吾尔自治区",
"py": "yizhou"
},
{
"city": "巴里坤",
"district": "哈密市",
"prov": "新疆维吾尔自治区",
"py": "balikun"
},
{
"city": "伊吾",
"district": "哈密市",
"prov": "新疆维吾尔自治区",
"py": "yiwu"
},
{
"city": "昌吉",
"district": "昌吉回族自治州",
"prov": "新疆维吾尔自治区",
"py": "changji"
},
{
"city": "昌吉市",
"district": "昌吉回族自治州",
"prov": "新疆维吾尔自治区",
"py": "changjishi"
},
{
"city": "阜康",
"district": "昌吉回族自治州",
"prov": "新疆维吾尔自治区",
"py": "fukang"
},
{
"city": "呼图壁",
"district": "昌吉回族自治州",
"prov": "新疆维吾尔自治区",
"py": "hutubi"
},
{
"city": "玛纳斯",
"district": "昌吉回族自治州",
"prov": "新疆维吾尔自治区",
"py": "manasi"
},
{
"city": "奇台",
"district": "昌吉回族自治州",
"prov": "新疆维吾尔自治区",
"py": "qitai"
},
{
"city": "吉木萨尔",
"district": "昌吉回族自治州",
"prov": "新疆维吾尔自治区",
"py": "jimusaer"
},
{
"city": "木垒",
"district": "昌吉回族自治州",
"prov": "新疆维吾尔自治区",
"py": "mulei"
},
{
"city": "博尔塔拉",
"district": "博尔塔拉蒙古自治州",
"prov": "新疆维吾尔自治区",
"py": "boertala"
},
{
"city": "博乐",
"district": "博尔塔拉蒙古自治州",
"prov": "新疆维吾尔自治区",
"py": "bole"
},
{
"city": "阿拉山口",
"district": "博尔塔拉蒙古自治州",
"prov": "新疆维吾尔自治区",
"py": "alashankou"
},
{
"city": "精河",
"district": "博尔塔拉蒙古自治州",
"prov": "新疆维吾尔自治区",
"py": "jinghe"
},
{
"city": "温泉",
"district": "博尔塔拉蒙古自治州",
"prov": "新疆维吾尔自治区",
"py": "wenquan"
},
{
"city": "巴音郭楞",
"district": "巴音郭楞蒙古自治州",
"prov": "新疆维吾尔自治区",
"py": "bayinguoleng"
},
{
"city": "库尔勒",
"district": "巴音郭楞蒙古自治州",
"prov": "新疆维吾尔自治区",
"py": "kuerle"
},
{
"city": "轮台",
"district": "巴音郭楞蒙古自治州",
"prov": "新疆维吾尔自治区",
"py": "luntai"
},
{
"city": "尉犁",
"district": "巴音郭楞蒙古自治州",
"prov": "新疆维吾尔自治区",
"py": "yuli"
},
{
"city": "若羌",
"district": "巴音郭楞蒙古自治州",
"prov": "新疆维吾尔自治区",
"py": "ruoqiang"
},
{
"city": "且末",
"district": "巴音郭楞蒙古自治州",
"prov": "新疆维吾尔自治区",
"py": "qiemo"
},
{
"city": "焉耆",
"district": "巴音郭楞蒙古自治州",
"prov": "新疆维吾尔自治区",
"py": "yanqi"
},
{
"city": "和静",
"district": "巴音郭楞蒙古自治州",
"prov": "新疆维吾尔自治区",
"py": "hejing"
},
{
"city": "和硕",
"district": "巴音郭楞蒙古自治州",
"prov": "新疆维吾尔自治区",
"py": "heshuo"
},
{
"city": "博湖",
"district": "巴音郭楞蒙古自治州",
"prov": "新疆维吾尔自治区",
"py": "bohu"
},
{
"city": "阿克苏",
"district": "阿克苏地区",
"prov": "新疆维吾尔自治区",
"py": "akesu"
},
{
"city": "阿克苏市",
"district": "阿克苏地区",
"prov": "新疆维吾尔自治区",
"py": "akesushi"
},
{
"city": "温宿",
"district": "阿克苏地区",
"prov": "新疆维吾尔自治区",
"py": "wensu"
},
{
"city": "库车",
"district": "阿克苏地区",
"prov": "新疆维吾尔自治区",
"py": "kuche"
},
{
"city": "沙雅",
"district": "阿克苏地区",
"prov": "新疆维吾尔自治区",
"py": "shaya"
},
{
"city": "新和",
"district": "阿克苏地区",
"prov": "新疆维吾尔自治区",
"py": "xinhe"
},
{
"city": "拜城",
"district": "阿克苏地区",
"prov": "新疆维吾尔自治区",
"py": "baicheng"
},
{
"city": "乌什",
"district": "阿克苏地区",
"prov": "新疆维吾尔自治区",
"py": "wushi"
},
{
"city": "阿瓦提",
"district": "阿克苏地区",
"prov": "新疆维吾尔自治区",
"py": "awati"
},
{
"city": "柯坪",
"district": "阿克苏地区",
"prov": "新疆维吾尔自治区",
"py": "keping"
},
{
"city": "克孜勒苏",
"district": "克孜勒苏柯尔克孜自治州",
"prov": "新疆维吾尔自治区",
"py": "kezilesu"
},
{
"city": "阿图什",
"district": "克孜勒苏柯尔克孜自治州",
"prov": "新疆维吾尔自治区",
"py": "atushi"
},
{
"city": "阿克陶",
"district": "克孜勒苏柯尔克孜自治州",
"prov": "新疆维吾尔自治区",
"py": "aketao"
},
{
"city": "阿合奇",
"district": "克孜勒苏柯尔克孜自治州",
"prov": "新疆维吾尔自治区",
"py": "aheqi"
},
{
"city": "乌恰",
"district": "克孜勒苏柯尔克孜自治州",
"prov": "新疆维吾尔自治区",
"py": "wuqia"
},
{
"city": "喀什",
"district": "喀什地区",
"prov": "新疆维吾尔自治区",
"py": "kashi"
},
{
"city": "喀什市",
"district": "喀什地区",
"prov": "新疆维吾尔自治区",
"py": "kashishi"
},
{
"city": "疏附",
"district": "喀什地区",
"prov": "新疆维吾尔自治区",
"py": "shufu"
},
{
"city": "疏勒",
"district": "喀什地区",
"prov": "新疆维吾尔自治区",
"py": "shule"
},
{
"city": "英吉沙",
"district": "喀什地区",
"prov": "新疆维吾尔自治区",
"py": "yingjisha"
},
{
"city": "泽普",
"district": "喀什地区",
"prov": "新疆维吾尔自治区",
"py": "zepu"
},
{
"city": "莎车",
"district": "喀什地区",
"prov": "新疆维吾尔自治区",
"py": "shache"
},
{
"city": "叶城",
"district": "喀什地区",
"prov": "新疆维吾尔自治区",
"py": "yecheng"
},
{
"city": "麦盖提",
"district": "喀什地区",
"prov": "新疆维吾尔自治区",
"py": "maigaiti"
},
{
"city": "岳普湖",
"district": "喀什地区",
"prov": "新疆维吾尔自治区",
"py": "yuepuhu"
},
{
"city": "伽师",
"district": "喀什地区",
"prov": "新疆维吾尔自治区",
"py": "jiashi"
},
{
"city": "巴楚",
"district": "喀什地区",
"prov": "新疆维吾尔自治区",
"py": "bachu"
},
{
"city": "塔什库尔干",
"district": "喀什地区",
"prov": "新疆维吾尔自治区",
"py": "tashikuergan"
},
{
"city": "和田",
"district": "和田地区",
"prov": "新疆维吾尔自治区",
"py": "hetian"
},
{
"city": "和田市",
"district": "和田地区",
"prov": "新疆维吾尔自治区",
"py": "hetianshi"
},
{
"city": "和田县",
"district": "和田地区",
"prov": "新疆维吾尔自治区",
"py": "hetianxian"
},
{
"city": "墨玉",
"district": "和田地区",
"prov": "新疆维吾尔自治区",
"py": "moyu"
},
{
"city": "皮山",
"district": "和田地区",
"prov": "新疆维吾尔自治区",
"py": "pishan"
},
{
"city": "洛浦",
"district": "和田地区",
"prov": "新疆维吾尔自治区",
"py": "luopu"
},
{
"city": "策勒",
"district": "和田地区",
"prov": "新疆维吾尔自治区",
"py": "cele"
},
{
"city": "于田",
"district": "和田地区",
"prov": "新疆维吾尔自治区",
"py": "yutian"
},
{
"city": "民丰",
"district": "和田地区",
"prov": "新疆维吾尔自治区",
"py": "minfeng"
},
{
"city": "伊犁",
"district": "伊犁哈萨克自治州",
"prov": "新疆维吾尔自治区",
"py": "yili"
},
{
"city": "伊宁",
"district": "伊犁哈萨克自治州",
"prov": "新疆维吾尔自治区",
"py": "yining"
},
{
"city": "奎屯",
"district": "伊犁哈萨克自治州",
"prov": "新疆维吾尔自治区",
"py": "kuitun"
},
{
"city": "霍尔果斯",
"district": "伊犁哈萨克自治州",
"prov": "新疆维吾尔自治区",
"py": "huoerguosi"
},
{
"city": "伊宁县",
"district": "伊犁哈萨克自治州",
"prov": "新疆维吾尔自治区",
"py": "yiningxian"
},
{
"city": "察布查尔",
"district": "伊犁哈萨克自治州",
"prov": "新疆维吾尔自治区",
"py": "chabuchaer"
},
{
"city": "霍城",
"district": "伊犁哈萨克自治州",
"prov": "新疆维吾尔自治区",
"py": "huocheng"
},
{
"city": "巩留",
"district": "伊犁哈萨克自治州",
"prov": "新疆维吾尔自治区",
"py": "gongliu"
},
{
"city": "新源",
"district": "伊犁哈萨克自治州",
"prov": "新疆维吾尔自治区",
"py": "xinyuan"
},
{
"city": "昭苏",
"district": "伊犁哈萨克自治州",
"prov": "新疆维吾尔自治区",
"py": "zhaosu"
},
{
"city": "特克斯",
"district": "伊犁哈萨克自治州",
"prov": "新疆维吾尔自治区",
"py": "tekesi"
},
{
"city": "尼勒克",
"district": "伊犁哈萨克自治州",
"prov": "新疆维吾尔自治区",
"py": "nileke"
},
{
"city": "塔城",
"district": "塔城地区",
"prov": "新疆维吾尔自治区",
"py": "tacheng"
},
{
"city": "塔城市",
"district": "塔城地区",
"prov": "新疆维吾尔自治区",
"py": "tachengshi"
},
{
"city": "乌苏",
"district": "塔城地区",
"prov": "新疆维吾尔自治区",
"py": "wusu"
},
{
"city": "额敏",
"district": "塔城地区",
"prov": "新疆维吾尔自治区",
"py": "emin"
},
{
"city": "沙湾",
"district": "塔城地区",
"prov": "新疆维吾尔自治区",
"py": "shawan"
},
{
"city": "托里",
"district": "塔城地区",
"prov": "新疆维吾尔自治区",
"py": "tuoli"
},
{
"city": "裕民",
"district": "塔城地区",
"prov": "新疆维吾尔自治区",
"py": "yumin"
},
{
"city": "和布克赛尔",
"district": "塔城地区",
"prov": "新疆维吾尔自治区",
"py": "hebukesaier"
},
{
"city": "阿勒泰",
"district": "阿勒泰地区",
"prov": "新疆维吾尔自治区",
"py": "aletai"
},
{
"city": "阿勒泰市",
"district": "阿勒泰地区",
"prov": "新疆维吾尔自治区",
"py": "aletaishi"
},
{
"city": "布尔津",
"district": "阿勒泰地区",
"prov": "新疆维吾尔自治区",
"py": "buerjin"
},
{
"city": "富蕴",
"district": "阿勒泰地区",
"prov": "新疆维吾尔自治区",
"py": "fuyun"
},
{
"city": "福海",
"district": "阿勒泰地区",
"prov": "新疆维吾尔自治区",
"py": "fuhai"
},
{
"city": "哈巴河",
"district": "阿勒泰地区",
"prov": "新疆维吾尔自治区",
"py": "habahe"
},
{
"city": "青河",
"district": "阿勒泰地区",
"prov": "新疆维吾尔自治区",
"py": "qinghe"
},
{
"city": "吉木乃",
"district": "阿勒泰地区",
"prov": "新疆维吾尔自治区",
"py": "jimunai"
},
{
"city": "石河子",
"district": "石河子市",
"prov": "新疆维吾尔自治区",
"py": "shihezi"
},
{
"city": "阿拉尔",
"district": "阿拉尔市",
"prov": "新疆维吾尔自治区",
"py": "alaer"
},
{
"city": "图木舒克",
"district": "图木舒克市",
"prov": "新疆维吾尔自治区",
"py": "tumushuke"
},
{
"city": "五家渠",
"district": "五家渠市",
"prov": "新疆维吾尔自治区",
"py": "wujiaqu"
},
{
"city": "北屯",
"district": "北屯市",
"prov": "新疆维吾尔自治区",
"py": "beitun"
},
{
"city": "铁门关",
"district": "铁门关市",
"prov": "新疆维吾尔自治区",
"py": "tiegenguan"
},
{
"city": "双河",
"district": "双河市",
"prov": "新疆维吾尔自治区",
"py": "shuanghe"
},
{
"city": "可克达拉",
"district": "可克达拉市",
"prov": "新疆维吾尔自治区",
"py": "kekedala"
},
{
"city": "昆玉",
"district": "昆玉市",
"prov": "新疆维吾尔自治区",
"py": "kunyu"
},
{
"city": "胡杨河市",
"district": "胡杨河市",
"prov": "新疆维吾尔自治区",
"py": "huyangheshi"
},
{
"city": "香港",
"district": "香港",
"prov": "香港",
"py": "xianggang"
},
{
"city": "中西区",
"district": "香港",
"prov": "香港",
"py": "zhongxiqu"
},
{
"city": "东区",
"district": "香港",
"prov": "香港",
"py": "dongqu"
},
{
"city": "九龙城区",
"district": "香港",
"prov": "香港",
"py": "jiulongchengqu"
},
{
"city": "观塘区",
"district": "香港",
"prov": "香港",
"py": "guantangqu"
},
{
"city": "南区",
"district": "香港",
"prov": "香港",
"py": "nanqu"
},
{
"city": "深水埗区",
"district": "香港",
"prov": "香港",
"py": "shenshuibuqu"
},
{
"city": "湾仔区",
"district": "香港",
"prov": "香港",
"py": "wanzaiqu"
},
{
"city": "黄大仙区",
"district": "香港",
"prov": "香港",
"py": "huangdaxianqu"
},
{
"city": "油尖旺区",
"district": "香港",
"prov": "香港",
"py": "youjianwangqu"
},
{
"city": "离岛区",
"district": "香港",
"prov": "香港",
"py": "lidaoqu"
},
{
"city": "葵青区",
"district": "香港",
"prov": "香港",
"py": "kuiqingqu"
},
{
"city": "新界",
"district": "香港",
"prov": "香港",
"py": "xinjie"
},
{
"city": "北区",
"district": "香港",
"prov": "香港",
"py": "beiqu"
},
{
"city": "西贡区",
"district": "香港",
"prov": "香港",
"py": "xigongqu"
},
{
"city": "沙田区",
"district": "香港",
"prov": "香港",
"py": "shatianqu"
},
{
"city": "屯门区",
"district": "香港",
"prov": "香港",
"py": "tunmenqu"
},
{
"city": "大埔区",
"district": "香港",
"prov": "香港",
"py": "dapuqu"
},
{
"city": "荃湾区",
"district": "香港",
"prov": "香港",
"py": "quanwanqu"
},
{
"city": "元朗区",
"district": "香港",
"prov": "香港",
"py": "yuanlangqu"
},
{
"city": "花王堂区",
"district": "澳门",
"prov": "澳门",
"py": "huawangtangqu"
},
{
"city": "望德堂区",
"district": "澳门",
"prov": "澳门",
"py": "wangdetangqu"
},
{
"city": "风顺堂区",
"district": "澳门",
"prov": "澳门",
"py": "fengshuntangqu"
},
{
"city": "圣方济各堂区",
"district": "澳门",
"prov": "澳门",
"py": "shengfangjigetangqu"
},
{
"city": "嘉模堂区",
"district": "澳门",
"prov": "澳门",
"py": "jiamotangqu"
},
{
"city": "大堂区",
"district": "澳门",
"prov": "澳门",
"py": "datangqu"
},
{
"city": "路氹填海区",
"district": "澳门",
"prov": "澳门",
"py": "ludangtianhaiqu"
},
{
"city": "花地玛堂区",
"district": "澳门",
"prov": "澳门",
"py": "huadimatangqu"
},
{
"city": "澳门",
"district": "澳门",
"prov": "澳门",
"py": "aomen"
},
{
"city": "台北",
"district": "台北市",
"prov": "台湾省",
"py": "taibei"
},
{
"city": "北投区",
"district": "台北市",
"prov": "台湾省",
"py": "beitouqu"
},
{
"city": "松山区",
"district": "台北市",
"prov": "台湾省",
"py": "songshanqu"
},
{
"city": "大同区",
"district": "台北市",
"prov": "台湾省",
"py": "datongqu"
},
{
"city": "文山区",
"district": "台北市",
"prov": "台湾省",
"py": "wenshanqu"
},
{
"city": "信义区",
"district": "台北市",
"prov": "台湾省",
"py": "xinyiqu"
},
{
"city": "内湖区",
"district": "台北市",
"prov": "台湾省",
"py": "neihuqu"
},
{
"city": "中正区",
"district": "台北市",
"prov": "台湾省",
"py": "zhongzhengqu"
},
{
"city": "万华区",
"district": "台北市",
"prov": "台湾省",
"py": "wanhuaqu"
},
{
"city": "中山区",
"district": "台北市",
"prov": "台湾省",
"py": "zhongshanqu"
},
{
"city": "士林区",
"district": "台北市",
"prov": "台湾省",
"py": "shilinqu"
},
{
"city": "南港区",
"district": "台北市",
"prov": "台湾省",
"py": "nangangqu"
},
{
"city": "大安区",
"district": "台北市",
"prov": "台湾省",
"py": "daanqu"
},
{
"city": "高雄",
"district": "高雄市",
"prov": "台湾省",
"py": "gaoxiong"
},
{
"city": "小港区",
"district": "高雄市",
"prov": "台湾省",
"py": "xiaogangqu"
},
{
"city": "左营区",
"district": "高雄市",
"prov": "台湾省",
"py": "zuoyingqu"
},
{
"city": "大寮区",
"district": "高雄市",
"prov": "台湾省",
"py": "daliaoqu"
},
{
"city": "那玛夏区",
"district": "高雄市",
"prov": "台湾省",
"py": "namaxiaqu"
},
{
"city": "旗津区",
"district": "高雄市",
"prov": "台湾省",
"py": "qijinqu"
},
{
"city": "弥陀区",
"district": "高雄市",
"prov": "台湾省",
"py": "mituoqu"
},
{
"city": "燕巢区",
"district": "高雄市",
"prov": "台湾省",
"py": "yanchaoqu"
},
{
"city": "大树区",
"district": "高雄市",
"prov": "台湾省",
"py": "dashuqu"
},
{
"city": "阿莲区",
"district": "高雄市",
"prov": "台湾省",
"py": "alianqu"
},
{
"city": "楠梓区",
"district": "高雄市",
"prov": "台湾省",
"py": "nanziqu"
},
{
"city": "鸟松区",
"district": "高雄市",
"prov": "台湾省",
"py": "niaosongqu"
},
{
"city": "苓雅区",
"district": "高雄市",
"prov": "台湾省",
"py": "lingyaqu"
},
{
"city": "桥头区",
"district": "高雄市",
"prov": "台湾省",
"py": "qiaotouqu"
},
{
"city": "梓官区",
"district": "高雄市",
"prov": "台湾省",
"py": "ziguanqu"
},
{
"city": "美浓区",
"district": "高雄市",
"prov": "台湾省",
"py": "meinongqu"
},
{
"city": "仁武区",
"district": "高雄市",
"prov": "台湾省",
"py": "renwuqu"
},
{
"city": "凤山区",
"district": "高雄市",
"prov": "台湾省",
"py": "fengshanqu"
},
{
"city": "甲仙区",
"district": "高雄市",
"prov": "台湾省",
"py": "jiaxianqu"
},
{
"city": "茄萣区",
"district": "高雄市",
"prov": "台湾省",
"py": "jiadingqu"
},
{
"city": "大社区",
"district": "高雄市",
"prov": "台湾省",
"py": "dashequ"
},
{
"city": "前镇区",
"district": "高雄市",
"prov": "台湾省",
"py": "qianzhenqu"
},
{
"city": "茂林区",
"district": "高雄市",
"prov": "台湾省",
"py": "maolinqu"
},
{
"city": "湖内区",
"district": "高雄市",
"prov": "台湾省",
"py": "huneiqu"
},
{
"city": "六龟区",
"district": "高雄市",
"prov": "台湾省",
"py": "liuguiqu"
},
{
"city": "林园区",
"district": "高雄市",
"prov": "台湾省",
"py": "linyuanqu"
},
{
"city": "内门区",
"district": "高雄市",
"prov": "台湾省",
"py": "neimenqu"
},
{
"city": "鼓山区",
"district": "高雄市",
"prov": "台湾省",
"py": "gushanqu"
},
{
"city": "杉林区",
"district": "高雄市",
"prov": "台湾省",
"py": "shanlinqu"
},
{
"city": "三民区",
"district": "高雄市",
"prov": "台湾省",
"py": "sanminqu"
},
{
"city": "前金区",
"district": "高雄市",
"prov": "台湾省",
"py": "qianjinqu"
},
{
"city": "冈山区",
"district": "高雄市",
"prov": "台湾省",
"py": "gangshanqu"
},
{
"city": "田寮区",
"district": "高雄市",
"prov": "台湾省",
"py": "tianliaoqu"
},
{
"city": "桃源区",
"district": "高雄市",
"prov": "台湾省",
"py": "taoyuanqu"
},
{
"city": "盐埕区",
"district": "高雄市",
"prov": "台湾省",
"py": "yanchengqu"
},
{
"city": "旗山区",
"district": "高雄市",
"prov": "台湾省",
"py": "qishanqu"
},
{
"city": "永安区",
"district": "高雄市",
"prov": "台湾省",
"py": "yonganqu"
},
{
"city": "路竹区",
"district": "高雄市",
"prov": "台湾省",
"py": "luzhuqu"
},
{
"city": "新兴区",
"district": "高雄市",
"prov": "台湾省",
"py": "xinxingqu"
},
{
"city": "新北市",
"district": "新北市",
"prov": "台湾省",
"py": "xinbeishi"
},
{
"city": "八里区",
"district": "新北市",
"prov": "台湾省",
"py": "baliqu"
},
{
"city": "三峡区",
"district": "新北市",
"prov": "台湾省",
"py": "sanxiaqu"
},
{
"city": "新庄区",
"district": "新北市",
"prov": "台湾省",
"py": "xinzhuangqu"
},
{
"city": "坪林区",
"district": "新北市",
"prov": "台湾省",
"py": "pinglinqu"
},
{
"city": "莺歌区",
"district": "新北市",
"prov": "台湾省",
"py": "yinggequ"
},
{
"city": "汐止区",
"district": "新北市",
"prov": "台湾省",
"py": "xizhiqu"
},
{
"city": "深坑区",
"district": "新北市",
"prov": "台湾省",
"py": "shenkengqu"
},
{
"city": "芦洲区",
"district": "新北市",
"prov": "台湾省",
"py": "luzhouqu"
},
{
"city": "三芝区",
"district": "新北市",
"prov": "台湾省",
"py": "sanzhiqu"
},
{
"city": "三重区",
"district": "新北市",
"prov": "台湾省",
"py": "sanchongqu"
},
{
"city": "平溪区",
"district": "新北市",
"prov": "台湾省",
"py": "pingxiqu"
},
{
"city": "中和区",
"district": "新北市",
"prov": "台湾省",
"py": "zhonghequ"
},
{
"city": "永和区",
"district": "新北市",
"prov": "台湾省",
"py": "yonghequ"
},
{
"city": "泰山区",
"district": "新北市",
"prov": "台湾省",
"py": "taishanqu"
},
{
"city": "土城区",
"district": "新北市",
"prov": "台湾省",
"py": "tuchengqu"
},
{
"city": "石碇区",
"district": "新北市",
"prov": "台湾省",
"py": "shidingqu"
},
{
"city": "五股区",
"district": "新北市",
"prov": "台湾省",
"py": "wuguqu"
},
{
"city": "林口区",
"district": "新北市",
"prov": "台湾省",
"py": "linkouqu"
},
{
"city": "双溪区",
"district": "新北市",
"prov": "台湾省",
"py": "shuangxiqu"
},
{
"city": "树林区",
"district": "新北市",
"prov": "台湾省",
"py": "shulinqu"
},
{
"city": "板桥区",
"district": "新北市",
"prov": "台湾省",
"py": "banqiaoqu"
},
{
"city": "新店区",
"district": "新北市",
"prov": "台湾省",
"py": "xindianqu"
},
{
"city": "乌来区",
"district": "新北市",
"prov": "台湾省",
"py": "wulaiqu"
},
{
"city": "贡寮区",
"district": "新北市",
"prov": "台湾省",
"py": "gongliaoqu"
},
{
"city": "金山区",
"district": "新北市",
"prov": "台湾省",
"py": "jinshanqu"
},
{
"city": "万里区",
"district": "新北市",
"prov": "台湾省",
"py": "wanliqu"
},
{
"city": "淡水区",
"district": "新北市",
"prov": "台湾省",
"py": "danshuiqu"
},
{
"city": "瑞芳区",
"district": "新北市",
"prov": "台湾省",
"py": "ruifangqu"
},
{
"city": "石门区",
"district": "新北市",
"prov": "台湾省",
"py": "shimenqu"
},
{
"city": "台中市",
"district": "台中市",
"prov": "台湾省",
"py": "taizhongshi"
},
{
"city": "东区",
"district": "台中市",
"prov": "台湾省",
"py": "dongqu"
},
{
"city": "新社区",
"district": "台中市",
"prov": "台湾省",
"py": "xinshequ"
},
{
"city": "中区",
"district": "台中市",
"prov": "台湾省",
"py": "zhongqu"
},
{
"city": "南屯区",
"district": "台中市",
"prov": "台湾省",
"py": "nantunqu"
},
{
"city": "神冈区",
"district": "台中市",
"prov": "台湾省",
"py": "shengangqu"
},
{
"city": "沙鹿区",
"district": "台中市",
"prov": "台湾省",
"py": "shaluqu"
},
{
"city": "丰原区",
"district": "台中市",
"prov": "台湾省",
"py": "fengyuanqu"
},
{
"city": "大里区",
"district": "台中市",
"prov": "台湾省",
"py": "daliqu"
},
{
"city": "龙井区",
"district": "台中市",
"prov": "台湾省",
"py": "longjingqu"
},
{
"city": "西区",
"district": "台中市",
"prov": "台湾省",
"py": "xiqu"
},
{
"city": "南区",
"district": "台中市",
"prov": "台湾省",
"py": "nanqu"
},
{
"city": "西屯区",
"district": "台中市",
"prov": "台湾省",
"py": "xitunqu"
},
{
"city": "太平区",
"district": "台中市",
"prov": "台湾省",
"py": "taipingqu"
},
{
"city": "北屯区",
"district": "台中市",
"prov": "台湾省",
"py": "beitunqu"
},
{
"city": "大雅区",
"district": "台中市",
"prov": "台湾省",
"py": "dayaqu"
},
{
"city": "石冈区",
"district": "台中市",
"prov": "台湾省",
"py": "shigangqu"
},
{
"city": "北区",
"district": "台中市",
"prov": "台湾省",
"py": "beiqu"
},
{
"city": "大甲区",
"district": "台中市",
"prov": "台湾省",
"py": "dajiaqu"
},
{
"city": "梧栖区",
"district": "台中市",
"prov": "台湾省",
"py": "wuqiqu"
},
{
"city": "东势区",
"district": "台中市",
"prov": "台湾省",
"py": "dongshiqu"
},
{
"city": "和平区",
"district": "台中市",
"prov": "台湾省",
"py": "hepingqu"
},
{
"city": "雾峰区",
"district": "台中市",
"prov": "台湾省",
"py": "wufengqu"
},
{
"city": "乌日区",
"district": "台中市",
"prov": "台湾省",
"py": "wuriqu"
},
{
"city": "后里区",
"district": "台中市",
"prov": "台湾省",
"py": "houliqu"
},
{
"city": "潭子区",
"district": "台中市",
"prov": "台湾省",
"py": "tanziqu"
},
{
"city": "大肚区",
"district": "台中市",
"prov": "台湾省",
"py": "daduqu"
},
{
"city": "外埔区",
"district": "台中市",
"prov": "台湾省",
"py": "waipuqu"
},
{
"city": "清水区",
"district": "台中市",
"prov": "台湾省",
"py": "qingshuiqu"
},
{
"city": "大安区",
"district": "台中市",
"prov": "台湾省",
"py": "daanqu"
},
{
"city": "台南市",
"district": "台南市",
"prov": "台湾省",
"py": "tainanshi"
},
{
"city": "安定区",
"district": "台南市",
"prov": "台湾省",
"py": "andingqu"
},
{
"city": "大内区",
"district": "台南市",
"prov": "台湾省",
"py": "daneiqu"
},
{
"city": "东山区",
"district": "台南市",
"prov": "台湾省",
"py": "dongshanqu"
},
{
"city": "下营区",
"district": "台南市",
"prov": "台湾省",
"py": "xiayingqu"
},
{
"city": "山上区",
"district": "台南市",
"prov": "台湾省",
"py": "shanshangqu"
},
{
"city": "永康区",
"district": "台南市",
"prov": "台湾省",
"py": "yongkangqu"
},
{
"city": "新营区",
"district": "台南市",
"prov": "台湾省",
"py": "xinyingqu"
},
{
"city": "白河区",
"district": "台南市",
"prov": "台湾省",
"py": "baihequ"
},
{
"city": "盐水区",
"district": "台南市",
"prov": "台湾省",
"py": "yanshuiqu"
},
{
"city": "归仁区",
"district": "台南市",
"prov": "台湾省",
"py": "guirenqu"
},
{
"city": "龙崎区",
"district": "台南市",
"prov": "台湾省",
"py": "longqiqu"
},
{
"city": "关庙区",
"district": "台南市",
"prov": "台湾省",
"py": "guanmiaoqu"
},
{
"city": "仁德区",
"district": "台南市",
"prov": "台湾省",
"py": "rendequ"
},
{
"city": "学甲区",
"district": "台南市",
"prov": "台湾省",
"py": "xuejiaqu"
},
{
"city": "善化区",
"district": "台南市",
"prov": "台湾省",
"py": "shanhuaqu"
},
{
"city": "新市区",
"district": "台南市",
"prov": "台湾省",
"py": "xinshiqu"
},
{
"city": "佳里区",
"district": "台南市",
"prov": "台湾省",
"py": "jialiqu"
},
{
"city": "新化区",
"district": "台南市",
"prov": "台湾省",
"py": "xinhuaqu"
},
{
"city": "西港区",
"district": "台南市",
"prov": "台湾省",
"py": "xigangqu"
},
{
"city": "麻豆区",
"district": "台南市",
"prov": "台湾省",
"py": "madouqu"
},
{
"city": "安南区",
"district": "台南市",
"prov": "台湾省",
"py": "annanqu"
},
{
"city": "后壁区",
"district": "台南市",
"prov": "台湾省",
"py": "houbiqu"
},
{
"city": "柳营区",
"district": "台南市",
"prov": "台湾省",
"py": "liuyingqu"
},
{
"city": "玉井区",
"district": "台南市",
"prov": "台湾省",
"py": "yujingqu"
},
{
"city": "官田区",
"district": "台南市",
"prov": "台湾省",
"py": "guantianqu"
},
{
"city": "东区",
"district": "台南市",
"prov": "台湾省",
"py": "dongqu"
},
{
"city": "六甲区",
"district": "台南市",
"prov": "台湾省",
"py": "liujiaqu"
},
{
"city": "中西区",
"district": "台南市",
"prov": "台湾省",
"py": "zhongxiqu"
},
{
"city": "北区",
"district": "台南市",
"prov": "台湾省",
"py": "beiqu"
},
{
"city": "楠西区",
"district": "台南市",
"prov": "台湾省",
"py": "nanxiqu"
},
{
"city": "南化区",
"district": "台南市",
"prov": "台湾省",
"py": "nanhuaqu"
},
{
"city": "左镇区",
"district": "台南市",
"prov": "台湾省",
"py": "zuozhenqu"
},
{
"city": "南区",
"district": "台南市",
"prov": "台湾省",
"py": "nanqu"
},
{
"city": "安平区",
"district": "台南市",
"prov": "台湾省",
"py": "anpingqu"
},
{
"city": "北门区",
"district": "台南市",
"prov": "台湾省",
"py": "beimenqu"
},
{
"city": "七股区",
"district": "台南市",
"prov": "台湾省",
"py": "qiguqu"
},
{
"city": "将军区",
"district": "台南市",
"prov": "台湾省",
"py": "jiangjunqu"
},
{
"city": "桃园市",
"district": "桃园市",
"prov": "台湾省",
"py": "taoyuanshi"
},
{
"city": "平镇市",
"district": "桃园市",
"prov": "台湾省",
"py": "pingzhenqu"
},
{
"city": "杨梅市",
"district": "桃园市",
"prov": "台湾省",
"py": "yangmeishi"
},
{
"city": "八德市",
"district": "桃园市",
"prov": "台湾省",
"py": "badeshi"
},
{
"city": "桃园区",
"district": "桃园市",
"prov": "台湾省",
"py": "taoyuanqu"
},
{
"city": "龟山乡",
"district": "桃园市",
"prov": "台湾省",
"py": "guishanxiang"
},
{
"city": "复兴乡",
"district": "桃园市",
"prov": "台湾省",
"py": "fuxingxiang"
},
{
"city": "芦竹乡",
"district": "桃园市",
"prov": "台湾省",
"py": "luzhuxiang"
},
{
"city": "观音乡",
"district": "桃园市",
"prov": "台湾省",
"py": "guanyinxiang"
},
{
"city": "龙潭乡",
"district": "桃园市",
"prov": "台湾省",
"py": "longtanxiang"
},
{
"city": "大溪镇",
"district": "桃园市",
"prov": "台湾省",
"py": "daxizhen"
},
{
"city": "大园乡",
"district": "桃园市",
"prov": "台湾省",
"py": "dayuanxiang"
},
{
"city": "新屋乡",
"district": "桃园市",
"prov": "台湾省",
"py": "xinwuxiang"
},
{
"city": "中坜市",
"district": "桃园市",
"prov": "台湾省",
"py": "zhonglishi"
},
{
"city": "基隆",
"district": "基隆市",
"prov": "台湾省",
"py": "jilong"
},
{
"city": "新竹市",
"district": "新竹市",
"prov": "台湾省",
"py": "xinzhushi"
},
{
"city": "嘉义市",
"district": "嘉义市",
"prov": "台湾省",
"py": "jiayishi"
},
{
"city": "新竹县",
"district": "新竹县",
"prov": "台湾省",
"py": "xinzhuxian"
},
{
"city": "宜兰县",
"district": "宜兰县",
"prov": "台湾省",
"py": "yilanxian"
},
{
"city": "苗栗县",
"district": "苗栗县",
"prov": "台湾省",
"py": "miaolixian"
},
{
"city": "彰化县",
"district": "彰化县",
"prov": "台湾省",
"py": "zhanghuaxian"
},
{
"city": "云林县",
"district": "云林县",
"prov": "台湾省",
"py": "yunlinxian"
},
{
"city": "南投县",
"district": "南投县",
"prov": "台湾省",
"py": "nantouxian"
},
{
"city": "嘉义县",
"district": "嘉义县",
"prov": "台湾省",
"py": "jiayixian"
},
{
"city": "屏东县",
"district": "屏东县",
"prov": "台湾省",
"py": "pingdongxian"
},
{
"city": "台东县",
"district": "台东县",
"prov": "台湾省",
"py": "taidongxian"
},
{
"city": "花莲县",
"district": "花莲县",
"prov": "台湾省",
"py": "hualianxian"
},
{
"city": "澎湖县",
"district": "澎湖县",
"prov": "台湾省",
"py": "penghuxian"
},
{
"city": "万盛",
"district": "重庆",
"prov": "重庆",
"py": "wansheng"
},
{
"city": "开县",
"district": "重庆",
"prov": "重庆",
"py": "kaxian"
},
{
"city": "呼中",
"district": "大兴安岭",
"prov": "黑龙江",
"py": "huzhong"
},
{
"city": "新林",
"district": "大兴安岭",
"prov": "黑龙江",
"py": "xinlin"
},
{
"city": "加格达奇",
"district": "大兴安岭",
"prov": "黑龙江",
"py": "jiagedaqi"
},
{
"city": "东岗",
"district": "白山",
"prov": "吉林",
"py": "donggang"
},
{
"city": "章党",
"district": "抚顺",
"prov": "辽宁",
"py": "zhangdang"
},
{
"city": "满都拉",
"district": "包头",
"prov": "内蒙古",
"py": "mandula"
},
{
"city": "舍伯吐",
"district": "通辽",
"prov": "内蒙古",
"py": "shebotu"
},
{
"city": "青龙山",
"district": "通辽",
"prov": "内蒙古",
"py": "qinglongshan"
},
{
"city": "巴雅尔吐胡硕",
"district": "通辽",
"prov": "内蒙古",
"py": "bayaertuhushuo"
},
{
"city": "浩尔吐",
"district": "赤峰",
"prov": "内蒙古",
"py": "haoertu"
},
{
"city": "岗子",
"district": "赤峰",
"prov": "内蒙古",
"py": "gangzi"
},
{
"city": "八里罕",
"district": "赤峰",
"prov": "内蒙古",
"py": "balihan"
},
{
"city": "宝国吐",
"district": "赤峰",
"prov": "内蒙古",
"py": "baoguotu"
},
{
"city": "河南",
"district": "鄂尔多斯",
"prov": "内蒙古",
"py": "henan"
},
{
"city": "伊克乌素",
"district": "鄂尔多斯",
"prov": "内蒙古",
"py": "yikewusu"
},
{
"city": "乌审召",
"district": "鄂尔多斯",
"prov": "内蒙古",
"py": "wushenzhao"
},
{
"city": "大佘太",
"district": "巴彦淖尔",
"prov": "内蒙古",
"py": "dashetai"
},
{
"city": "海力素",
"district": "巴彦淖尔",
"prov": "内蒙古",
"py": "hailisu"
},
{
"city": "那仁宝力格",
"district": "巴彦淖尔",
"prov": "内蒙古",
"py": "narenbaolige"
},
{
"city": "朱日和",
"district": "锡林郭勒",
"prov": "内蒙古",
"py": "zhurihe"
},
{
"city": "博克图",
"district": "锡林郭勒",
"prov": "内蒙古",
"py": "boketu"
},
{
"city": "乌拉盖",
"district": "锡林郭勒",
"prov": "内蒙古",
"py": "wulagai"
},
{
"city": "小二沟",
"district": "呼伦贝尔",
"prov": "内蒙古",
"py": "xiaoergou"
},
{
"city": "图里河",
"district": "呼伦贝尔",
"prov": "内蒙古",
"py": "tulihe"
},
{
"city": "胡尔勒",
"district": "兴安盟",
"prov": "内蒙古",
"py": "huerle"
},
{
"city": "索伦",
"district": "兴安盟",
"prov": "内蒙古",
"py": "suolun"
},
{
"city": "拐子湖",
"district": "阿拉善盟",
"prov": "内蒙古",
"py": "guaizihu"
},
{
"city": "吉兰太",
"district": "阿拉善盟",
"prov": "内蒙古",
"py": "jilantai"
},
{
"city": "锡林高勒",
"district": "阿拉善盟",
"prov": "内蒙古",
"py": "xilingaole"
},
{
"city": "头道湖",
"district": "阿拉善盟",
"prov": "内蒙古",
"py": "toudaohu"
},
{
"city": "中泉子",
"district": "阿拉善盟",
"prov": "内蒙古",
"py": "zhongquanzi"
},
{
"city": "诺尔公",
"district": "阿拉善盟",
"prov": "内蒙古",
"py": "nuoergong"
},
{
"city": "雅布赖",
"district": "阿拉善盟",
"prov": "内蒙古",
"py": "yabulai"
},
{
"city": "乌斯泰",
"district": "阿拉善盟",
"prov": "内蒙古",
"py": "wusitai"
},
{
"city": "孪井滩",
"district": "阿拉善盟",
"prov": "内蒙古",
"py": "luanjingtan"
},
{
"city": "容城",
"district": "保定",
"prov": "河北",
"py": "rongcheng"
},
{
"city": "安新",
"district": "保定",
"prov": "河北",
"py": "anxin"
},
{
"city": "雄县",
"district": "保定",
"prov": "河北",
"py": "xiongxian"
},
{
"city": "滦县",
"district": "唐山",
"prov": "河北",
"py": "luanxian"
},
{
"city": "曹妃甸",
"district": "唐山",
"prov": "河北",
"py": "caofeidian"
},
{
"city": "大同县",
"district": "大同",
"prov": "山西",
"py": "datongxian"
},
{
"city": "五台山",
"district": "忻州",
"prov": "山西",
"py": "wutaishan"
},
{
"city": "彬县",
"district": "咸阳",
"prov": "陕西",
"py": "binxian"
},
{
"city": "华县",
"district": "渭南",
"prov": "陕西",
"py": "huaxian"
},
{
"city": "耀县",
"district": "铜川",
"prov": "陕西",
"py": "yaoxian"
},
{
"city": "杨凌",
"district": "杨凌",
"prov": "陕西",
"py": "yangling"
},
{
"city": "陵县",
"district": "德州",
"prov": "山东",
"py": "lingxian"
},
{
"city": "成山头",
"district": "威海",
"prov": "山东",
"py": "chengshantou"
},
{
"city": "石岛",
"district": "威海",
"prov": "山东",
"py": "shidao"
},
{
"city": "莱芜",
"district": "莱芜",
"prov": "山东",
"py": "laiwu"
},
{
"city": "小渠子",
"district": "乌鲁木齐",
"prov": "新疆",
"py": "xiaoquzi"
},
{
"city": "乌鲁木齐牧试站",
"district": "乌鲁木齐",
"prov": "新疆",
"py": "wulumuqimushizhan"
},
{
"city": "天池",
"district": "乌鲁木齐",
"prov": "新疆",
"py": "tianchi"
},
{
"city": "白杨沟",
"district": "乌鲁木齐",
"prov": "新疆",
"py": "baiyanggou"
},
{
"city": "炮台",
"district": "石河子",
"prov": "新疆",
"py": "paotai"
},
{
"city": "莫索湾",
"district": "石河子",
"prov": "新疆",
"py": "mosuowan"
},
{
"city": "米泉",
"district": "昌吉",
"prov": "新疆",
"py": "miquan"
},
{
"city": "蔡家湖",
"district": "昌吉",
"prov": "新疆",
"py": "caijiahu"
},
{
"city": "巴音布鲁克",
"district": "巴音郭楞",
"prov": "新疆",
"py": "bayinbuluke"
},
{
"city": "铁干里克",
"district": "巴音郭楞",
"prov": "新疆",
"py": "tieganlike"
},
{
"city": "塔中",
"district": "巴音郭楞",
"prov": "新疆",
"py": "tazhong"
},
{
"city": "帕里",
"district": "日喀则",
"prov": "西藏",
"py": "pali"
},
{
"city": "泽当",
"district": "山南",
"prov": "西藏",
"py": "zedang"
},
{
"city": "申扎",
"district": "阿里",
"prov": "西藏",
"py": "shenzha"
},
{
"city": "狮泉河",
"district": "阿里",
"prov": "西藏",
"py": "shiquanhe"
},
{
"city": "平安",
"district": "海东",
"prov": "青海",
"py": "pingan"
},
{
"city": "共和",
"district": "海南",
"prov": "青海",
"py": "gonghe"
},
{
"city": "玛沁",
"district": "果洛",
"prov": "青海",
"py": "maqin"
},
{
"city": "大柴旦",
"district": "海西",
"prov": "青海",
"py": "dachaidan"
},
{
"city": "德令哈",
"district": "海西",
"prov": "青海",
"py": "delingha"
},
{
"city": "格尔木",
"district": "格尔木",
"prov": "青海",
"py": "geermu"
},
{
"city": "都兰",
"district": "格尔木",
"prov": "青海",
"py": "dulan"
},
{
"city": "陶乐",
"district": "石嘴山",
"prov": "宁夏",
"py": "taole"
},
{
"city": "陕县",
"district": "三门峡",
"prov": "河南",
"py": "shanxian"
},
{
"city": "江浦",
"district": "南京",
"prov": "江苏",
"py": "jiangpu"
},
{
"city": "三峡",
"district": "宜昌",
"prov": "湖北",
"py": "sanxia"
},
{
"city": "洪家",
"district": "台州",
"prov": "浙江",
"py": "hongjia"
},
{
"city": "枞阳",
"district": "安庆",
"prov": "安徽",
"py": "zongyang"
},
{
"city": "黄山风景区",
"district": "黄山",
"prov": "安徽",
"py": "huangshanfengjingqu"
},
{
"city": "寿县",
"district": "六安",
"prov": "安徽",
"py": "shouxian"
},
{
"city": "九华山",
"district": "池州",
"prov": "安徽",
"py": "jiuhuashan"
},
{
"city": "秀屿港",
"district": "莆田",
"prov": "福建",
"py": "xiuyugang"
},
{
"city": "崇武",
"district": "泉州",
"prov": "福建",
"py": "chongwu"
},
{
"city": "钓鱼岛",
"district": "钓鱼岛",
"prov": "福建",
"py": "diaoyudao"
},
{
"city": "星子",
"district": "九江",
"prov": "江西",
"py": "xingzi"
},
{
"city": "宁冈",
"district": "吉安",
"prov": "江西",
"py": "ninggang"
},
{
"city": "马坡岭",
"district": "长沙",
"prov": "湖南",
"py": "mapoling"
},
{
"city": "小河",
"district": "贵阳",
"prov": "贵州",
"py": "xiaohe"
},
{
"city": "安县",
"district": "绵阳",
"prov": "四川",
"py": "anxian"
},
{
"city": "宜宾县",
"district": "宜宾",
"prov": "四川",
"py": "yibinxian"
},
{
"city": "简阳",
"district": "资阳",
"prov": "四川",
"py": "jianyang"
},
{
"city": "峨眉",
"district": "乐山",
"prov": "四川",
"py": "emei"
},
{
"city": "茂港",
"district": "茂名",
"prov": "广东",
"py": "maogang"
},
{
"city": "太华山",
"district": "昆明",
"prov": "云南",
"py": "taihuashan"
},
{
"city": "六库",
"district": "怒江",
"prov": "云南",
"py": "liuku"
},
{
"city": "中甸",
"district": "迪庆",
"prov": "云南",
"py": "zhongdian"
},
{
"city": "涠洲岛",
"district": "北海",
"prov": "广西",
"py": "weizhoudao"
},
{
"city": "西沙",
"district": "西沙",
"prov": "海南",
"py": "xisha"
},
{
"city": "南沙",
"district": "南沙",
"prov": "海南",
"py": "nansha"
},
{
"city": "延边",
"district": "延边",
"prov": "吉林",
"py": "yanbian"
},
{
"city": "希拉穆仁",
"district": "包头",
"prov": "内蒙古",
"py": "xilamuren"
},
{
"city": "呼伦贝尔",
"district": "呼伦贝尔",
"prov": "内蒙古",
"py": "hulunbeier"
},
{
"city": "和丰",
"district": "塔城",
"prov": "新疆",
"py": "hefeng"
},
{
"city": "大武口",
"district": "石嘴山",
"prov": "宁夏",
"py": "dawukou"
},
{
"city": "含山",
"district": "巢湖",
"prov": "安徽",
"py": "hanshan"
},
{
"city": "遵义县",
"district": "遵义",
"prov": "贵州",
"py": "zunyixian"
},
{
"city": "南坪",
"district": "阿坝",
"prov": "四川",
"py": "nanping"
},
{
"city": "巢湖",
"district": "巢湖",
"prov": "安徽",
"py": "chaohu"
},
{
"city": "金门",
"district": "泉州",
"prov": "福建",
"py": "jinmen"
},
{
"city": "金门",
"district": "台湾",
"prov": "台湾",
"py": "jinmen"
},
{
"city": "东陵",
"district": "沈阳",
"prov": "辽宁",
"py": "dongling"
},
{
"city": "南市",
"district": "保定",
"prov": "河北",
"py": "nanshi"
},
{
"city": "矿",
"district": "大同",
"prov": "山西",
"py": "kuangqu"
},
{
"city": "钢城",
"district": "莱芜",
"prov": "山东",
"py": "gangcheng"
},
{
"city": "莱城",
"district": "莱芜",
"prov": "山东",
"py": "laicheng"
},
{
"city": "南郊",
"district": "大同",
"prov": "山西",
"py": "nanjiao"
},
{
"city": "金家庄",
"district": "马鞍山",
"prov": "安徽",
"py": "jinjiazhuang"
},
{
"city": "狮子山",
"district": "铜陵",
"prov": "安徽",
"py": "shizishan"
},
{
"city": "新芜",
"district": "芜湖",
"prov": "安徽",
"py": "xinwu"
},
{
"city": "铜官山",
"district": "铜陵",
"prov": "安徽",
"py": "tongguanshan"
},
{
"city": "芳村",
"district": "广州",
"prov": "广东",
"py": "fangcun"
},
{
"city": "萝岗",
"district": "广州",
"prov": "广东",
"py": "luogang"
},
{
"city": "蝶山",
"district": "梧州",
"prov": "广西",
"py": "dieshan"
},
{
"city": "桥东",
"district": "石家庄",
"prov": "河北",
"py": "qiaodong"
},
{
"city": "北市",
"district": "保定",
"prov": "河北",
"py": "beishi"
},
{
"city": "渤海新",
"district": "沧州",
"prov": "河北",
"py": "bohaixin"
},
{
"city": "永红",
"district": "佳木斯",
"prov": "黑龙江",
"py": "yonghong"
},
{
"city": "动力",
"district": "哈尔滨",
"prov": "黑龙江",
"py": "dongli"
},
{
"city": "白下",
"district": "南京",
"prov": "江苏",
"py": "baixia"
},
{
"city": "沧浪",
"district": "苏州",
"prov": "江苏",
"py": "canglang"
},
{
"city": "崇安",
"district": "无锡",
"prov": "江苏",
"py": "chongan"
},
{
"city": "九里",
"district": "徐州",
"prov": "江苏",
"py": "jiuli"
},
{
"city": "新浦",
"district": "连云港",
"prov": "江苏",
"py": "xinpu"
},
{
"city": "清浦",
"district": "淮安",
"prov": "江苏",
"py": "qingpu"
},
{
"city": "戚墅堰",
"district": "常州",
"prov": "江苏",
"py": "qishuyan"
},
{
"city": "四方",
"district": "青岛",
"prov": "山东",
"py": "sifang"
},
{
"city": "闸北",
"district": "上海",
"prov": "上海",
"py": "zhabei"
},
{
"city": "安州",
"district": "绵阳",
"prov": "四川",
"py": "anzhou"
},
{
"city": "郫都",
"district": "成都",
"prov": "四川",
"py": "pidu"
},
{
"city": "天府新",
"district": "成都",
"prov": "四川",
"py": "tianfuxin"
},
{
"city": "江东",
"district": "宁波",
"prov": "浙江",
"py": "jiangdong"
},
{
"city": "开州区",
"district": "重庆",
"prov": "重庆",
"py": "kaizhouqu"
},
{
"city": "东京",
"district": "日本",
"prov": "亚洲热门",
"py": "dongjing"
},
{
"city": "横滨",
"district": "日本",
"prov": "亚洲热门",
"py": "hengbin"
},
{
"city": "大阪",
"district": "日本",
"prov": "亚洲热门",
"py": "daban"
},
{
"city": "名古屋",
"district": "日本",
"prov": "亚洲热门",
"py": "mingguwu"
},
{
"city": "札幌",
"district": "日本",
"prov": "亚洲热门",
"py": "zhahuang"
},
{
"city": "神户",
"district": "日本",
"prov": "亚洲热门",
"py": "shenhu"
},
{
"city": "京都",
"district": "日本",
"prov": "亚洲热门",
"py": "jingdu"
},
{
"city": "福冈",
"district": "日本",
"prov": "亚洲热门",
"py": "fugang"
},
{
"city": "川崎",
"district": "日本",
"prov": "亚洲热门",
"py": "chuanqi"
},
{
"city": "广岛",
"district": "日本",
"prov": "亚洲热门",
"py": "guangdao"
},
{
"city": "仙台",
"district": "日本",
"prov": "亚洲热门",
"py": "xiantai"
},
{
"city": "吉隆坡",
"district": "马来西亚",
"prov": "亚洲热门",
"py": "jilongpo"
},
{
"city": "马六甲",
"district": "马来西亚",
"prov": "亚洲热门",
"py": "maliujia"
},
{
"city": "雪兰莪 ",
"district": "马来西亚",
"prov": "亚洲热门",
"py": "xuelane"
},
{
"city": "怡保",
"district": "马来西亚",
"prov": "亚洲热门",
"py": "yibao"
},
{
"city": "乔治市",
"district": "马来西亚",
"prov": "亚洲热门",
"py": "qiaozhishi"
},
{
"city": "新山",
"district": "马来西亚",
"prov": "亚洲热门",
"py": "xinshan"
},
{
"city": "首尔",
"district": "韩国",
"prov": "亚洲热门",
"py": "shouer"
},
{
"city": "釜山",
"district": "韩国",
"prov": "亚洲热门",
"py": "fushan"
},
{
"city": "济州",
"district": "韩国",
"prov": "亚洲热门",
"py": "jizhou"
},
{
"city": "仁川",
"district": "韩国",
"prov": "亚洲热门",
"py": "renchuan"
},
{
"city": "大邱",
"district": "韩国",
"prov": "亚洲热门",
"py": "daqiu"
},
{
"city": "曼谷",
"district": "泰国",
"prov": "亚洲热门",
"py": "mangu"
},
{
"city": "芭堤雅",
"district": "泰国",
"prov": "亚洲热门",
"py": "badiya"
},
{
"city": "清迈",
"district": "泰国",
"prov": "亚洲热门",
"py": "qingmai"
},
{
"city": "普吉岛",
"district": "泰国",
"prov": "亚洲热门",
"py": "pujidao"
},
{
"city": "胡志明市",
"district": "越南",
"prov": "亚洲热门",
"py": "huzhimingshi"
},
{
"city": "河內",
"district": "越南",
"prov": "亚洲热门",
"py": "henei"
},
{
"city": "海防市",
"district": "越南",
"prov": "亚洲热门",
"py": "haifangshi"
},
{
"city": "岘港市",
"district": "越南",
"prov": "亚洲热门",
"py": "xiangangshi"
},
{
"city": "新加坡",
"district": "其他",
"prov": "亚洲热门",
"py": "xinjiapo"
},
{
"city": "马尼拉",
"district": "其他",
"prov": "亚洲热门",
"py": "manila"
},
{
"city": "巴厘岛",
"district": "其他",
"prov": "亚洲热门",
"py": "balidao"
},
{
"city": "雅加达",
"district": "其他",
"prov": "亚洲热门",
"py": "yajiada"
},
{
"city": "新德里",
"district": "其他",
"prov": "亚洲热门",
"py": "xindeli"
},
{
"city": "孟买",
"district": "其他",
"prov": "亚洲热门",
"py": "mengmai"
},
{
"city": "金边",
"district": "其他",
"prov": "亚洲热门",
"py": "jinbian"
},
{
"city": "加德满都",
"district": "其他",
"prov": "亚洲热门",
"py": "jiademandu"
},
{
"city": "万象",
"district": "其他",
"prov": "亚洲热门",
"py": "wanxiang"
},
{
"city": "乌兰巴托",
"district": "其他",
"prov": "亚洲热门",
"py": "wulanbatuo"
},
{
"city": "仰光",
"district": "其他",
"prov": "亚洲热门",
"py": "yangguang"
},
{
"city": "内比都",
"district": "其他",
"prov": "亚洲热门",
"py": "neibidu"
},
{
"city": "迪拜",
"district": "其他",
"prov": "亚洲热门",
"py": "dibai"
},
{
"city": "多哈",
"district": "其他",
"prov": "亚洲热门",
"py": "duoha"
},
{
"city": "耶路撒冷",
"district": "其他",
"prov": "亚洲热门",
"py": "yelusaleng"
},
{
"city": "巴格达",
"district": "其他",
"prov": "亚洲热门",
"py": "bageda"
},
{
"city": "德黑兰",
"district": "其他",
"prov": "亚洲热门",
"py": "deheilan"
},
{
"city": "利雅得",
"district": "其他",
"prov": "亚洲热门",
"py": "liyade"
},
{
"city": "阿布扎比",
"district": "其他",
"prov": "亚洲热门",
"py": "abuzhabi"
},
{
"city": "马尔代夫",
"district": "其他",
"prov": "亚洲热门",
"py": "maerdaifu"
},
{
"city": "大马士革",
"district": "其他",
"prov": "亚洲热门",
"py": "damashige"
},
{
"city": "纽约",
"district": "美国",
"prov": "欧美热门",
"py": "niuyue"
},
{
"city": "洛杉矶",
"district": "美国",
"prov": "欧美热门",
"py": "luoshanji"
},
{
"city": "华盛顿",
"district": "美国",
"prov": "欧美热门",
"py": "huashengdun"
},
{
"city": "休斯敦",
"district": "美国",
"prov": "欧美热门",
"py": "xiusidun"
},
{
"city": "拉斯维加斯",
"district": "美国",
"prov": "欧美热门",
"py": "lasiweijiasi"
},
{
"city": "芝加哥",
"district": "美国",
"prov": "欧美热门",
"py": "zhijiage"
},
{
"city": "费城",
"district": "美国",
"prov": "欧美热门",
"py": "feicheng"
},
{
"city": "波士顿",
"district": "美国",
"prov": "欧美热门",
"py": "boshidun"
},
{
"city": "旧金山",
"district": "美国",
"prov": "欧美热门",
"py": "jiujinshan"
},
{
"city": "亚特兰大",
"district": "美国",
"prov": "欧美热门",
"py": "yatelanda"
},
{
"city": "达拉斯",
"district": "美国",
"prov": "欧美热门",
"py": "dalasi"
},
{
"city": "底特律",
"district": "美国",
"prov": "欧美热门",
"py": "ditelv"
},
{
"city": "夏威夷",
"district": "美国",
"prov": "欧美热门",
"py": "xiaweiyi"
},
{
"city": "小石城",
"district": "美国",
"prov": "欧美热门",
"py": "xiaoshicheng"
},
{
"city": "孟菲斯",
"district": "美国",
"prov": "欧美热门",
"py": "mengfeisi"
},
{
"city": "新奥尔良",
"district": "美国",
"prov": "欧美热门",
"py": "xinaoerliang"
},
{
"city": "黄石公园",
"district": "美国",
"prov": "欧美热门",
"py": "huangshigongyuan"
},
{
"city": "西雅图",
"district": "美国",
"prov": "欧美热门",
"py": "xiyatu"
},
{
"city": "迈阿密",
"district": "美国",
"prov": "欧美热门",
"py": "maiami"
},
{
"city": "罗马",
"district": "意大利",
"prov": "欧美热门",
"py": "luoma"
},
{
"city": "佛罗伦萨",
"district": "意大利",
"prov": "欧美热门",
"py": "foluolunsa"
},
{
"city": "热那亚",
"district": "意大利",
"prov": "欧美热门",
"py": "renaya"
},
{
"city": "米兰",
"district": "意大利",
"prov": "欧美热门",
"py": "milan"
},
{
"city": "威尼斯",
"district": "意大利",
"prov": "欧美热门",
"py": "weinisi"
},
{
"city": "多伦多",
"district": "加拿大",
"prov": "欧美热门",
"py": "duolunduo"
},
{
"city": "温哥华",
"district": "加拿大",
"prov": "欧美热门",
"py": "wengehua"
},
{
"city": "渥太华",
"district": "加拿大",
"prov": "欧美热门",
"py": "wotaihua"
},
{
"city": "魁北克",
"district": "加拿大",
"prov": "欧美热门",
"py": "kuibeike"
},
{
"city": "蒙特利尔",
"district": "加拿大",
"prov": "欧美热门",
"py": "mengtelier"
},
{
"city": "伦敦",
"district": "英国",
"prov": "欧美热门",
"py": "lundun"
},
{
"city": "南安普敦",
"district": "英国",
"prov": "欧美热门",
"py": "nananpudun"
},
{
"city": "利物浦",
"district": "英国",
"prov": "欧美热门",
"py": "liwupu"
},
{
"city": "爱丁堡",
"district": "英国",
"prov": "欧美热门",
"py": "aidingbao"
},
{
"city": "曼切斯特",
"district": "英国",
"prov": "欧美热门",
"py": "manqiesite"
},
{
"city": "剑桥",
"district": "英国",
"prov": "欧美热门",
"py": "jianqiao"
},
{
"city": "牛津",
"district": "英国",
"prov": "欧美热门",
"py": "niujin"
},
{
"city": "巴黎",
"district": "法国",
"prov": "欧美热门",
"py": "bali"
},
{
"city": "里昂",
"district": "法国",
"prov": "欧美热门",
"py": "liang"
},
{
"city": "马赛",
"district": "法国",
"prov": "欧美热门",
"py": "masai"
},
{
"city": "波尔多",
"district": "法国",
"prov": "欧美热门",
"py": "boerduo"
},
{
"city": "戛纳",
"district": "法国",
"prov": "欧美热门",
"py": "jiana"
},
{
"city": "柏林",
"district": "德国",
"prov": "欧美热门",
"py": "bolin"
},
{
"city": "慕尼黑",
"district": "德国",
"prov": "欧美热门",
"py": "munihei"
},
{
"city": "法兰克福",
"district": "德国",
"prov": "欧美热门",
"py": "falankefu"
},
{
"city": "汉堡",
"district": "德国",
"prov": "欧美热门",
"py": "hanbao"
},
{
"city": "巴西利亚",
"district": "巴西",
"prov": "欧美热门",
"py": "baxiliya"
},
{
"city": "圣保罗",
"district": "巴西",
"prov": "欧美热门",
"py": "shengbaoluo"
},
{
"city": "里约热内卢",
"district": "巴西",
"prov": "欧美热门",
"py": "liyuereneilu"
},
{
"city": "阿姆斯特丹",
"district": "荷兰",
"prov": "欧美热门",
"py": "amusitedan"
},
{
"city": "鹿特丹",
"district": "荷兰",
"prov": "欧美热门",
"py": "lutedan"
},
{
"city": "海牙",
"district": "荷兰",
"prov": "欧美热门",
"py": "haiya"
},
{
"city": "里斯本",
"district": "葡萄牙",
"prov": "欧美热门",
"py": "lisiben"
},
{
"city": "波尔图",
"district": "葡萄牙",
"prov": "欧美热门",
"py": "boertu"
},
{
"city": "马德里",
"district": "西班牙",
"prov": "欧美热门",
"py": "madeli"
},
{
"city": "巴塞罗那",
"district": "西班牙",
"prov": "欧美热门",
"py": "basailuona"
},
{
"city": "莫斯科",
"district": "俄罗斯",
"prov": "欧美热门",
"py": "mosike"
},
{
"city": "圣彼得堡",
"district": "俄罗斯",
"prov": "欧美热门",
"py": "shengbidebao"
},
{
"city": "索契",
"district": "俄罗斯",
"prov": "欧美热门",
"py": "suoqi"
},
{
"city": "墨西哥城",
"district": "其他",
"prov": "欧美热门",
"py": "moxigecheng"
},
{
"city": "布宜诺斯艾利斯",
"district": "其他",
"prov": "欧美热门",
"py": "buyinuosiailisi"
},
{
"city": "安卡拉",
"district": "其他",
"prov": "欧美热门",
"py": "ankala"
},
{
"city": "伊斯坦布尔",
"district": "其他",
"prov": "欧美热门",
"py": "yisitanbuer"
},
{
"city": "雅典",
"district": "其他",
"prov": "欧美热门",
"py": "yadian"
},
{
"city": "基辅",
"district": "其他",
"prov": "欧美热门",
"py": "jifu"
},
{
"city": "明斯克",
"district": "其他",
"prov": "欧美热门",
"py": "mingsike"
},
{
"city": "华沙",
"district": "其他",
"prov": "欧美热门",
"py": "huasha"
},
{
"city": "赫尔辛基",
"district": "其他",
"prov": "欧美热门",
"py": "heerxinji"
},
{
"city": "斯德哥尔摩",
"district": "其他",
"prov": "欧美热门",
"py": "sidegeermo"
},
{
"city": "奥斯陆",
"district": "其他",
"prov": "欧美热门",
"py": "aosilu"
},
{
"city": "布鲁塞尔",
"district": "其他",
"prov": "欧美热门",
"py": "bulusaier"
},
{
"city": "伯尔尼",
"district": "其他",
"prov": "欧美热门",
"py": "boerni"
},
{
"city": "洛桑",
"district": "其他",
"prov": "欧美热门",
"py": "luosang"
},
{
"city": "日内瓦",
"district": "其他",
"prov": "欧美热门",
"py": "rineiwa"
},
{
"city": "苏黎世",
"district": "其他",
"prov": "欧美热门",
"py": "sulishi"
},
{
"city": "维也纳",
"district": "其他",
"prov": "欧美热门",
"py": "weiyena"
},
{
"city": "贝尔格莱德",
"district": "其他",
"prov": "欧美热门",
"py": "beiergelaide"
},
{
"city": "萨拉热窝",
"district": "其他",
"prov": "欧美热门",
"py": "salarewo"
},
{
"city": "布拉格",
"district": "其他",
"prov": "欧美热门",
"py": "bulage"
},
{
"city": "卢森堡",
"district": "其他",
"prov": "欧美热门",
"py": "lusenbao"
},
{
"city": "哥本哈根",
"district": "其他",
"prov": "欧美热门",
"py": "gebenhagen"
},
{
"city": "都柏林",
"district": "其他",
"prov": "欧美热门",
"py": "dubaiolin"
},
{
"city": "安道尔",
"district": "其他",
"prov": "欧美热门",
"py": "andaoer"
},
{
"city": "梵蒂冈",
"district": "其他",
"prov": "欧美热门",
"py": "fandigang"
},
{
"city": "摩纳哥",
"district": "其他",
"prov": "欧美热门",
"py": "monage"
},
{
"city": "巴拿马城",
"district": "其他",
"prov": "欧美热门",
"py": "banamacheng"
},
{
"city": "布加勒斯特",
"district": "其他",
"prov": "欧美热门",
"py": "bujialesite"
},
{
"city": "圣菲波哥大",
"district": "其他",
"prov": "欧美热门",
"py": "shengfeibogeda"
},
{
"city": "加拉加斯",
"district": "其他",
"prov": "欧美热门",
"py": "jialajiasi"
},
{
"city": "利马",
"district": "其他",
"prov": "欧美热门",
"py": "lima"
},
{
"city": "圣地亚哥",
"district": "其他",
"prov": "欧美热门",
"py": "shengdiyage"
},
{
"city": "约翰内斯堡",
"district": "非洲",
"prov": "非洲",
"py": "yueohanneisibao"
},
{
"city": "开普敦",
"district": "非洲",
"prov": "非洲",
"py": "kaipudun"
},
{
"city": "开罗",
"district": "非洲",
"prov": "非洲",
"py": "kailuo"
},
{
"city": "亚历山大港",
"district": "非洲",
"prov": "非洲",
"py": "yalishandagang"
},
{
"city": "苏伊士",
"district": "非洲",
"prov": "非洲",
"py": "suyishi"
},
{
"city": "阿斯旺",
"district": "非洲",
"prov": "非洲",
"py": "asiwang"
},
{
"city": "的黎波里",
"district": "非洲",
"prov": "非洲",
"py": "diliboli"
},
{
"city": "班加西",
"district": "非洲",
"prov": "非洲",
"py": "banjiaxi"
},
{
"city": "突尼斯",
"district": "非洲",
"prov": "非洲",
"py": "tunisi"
},
{
"city": "堪培拉",
"district": "澳大利亚",
"prov": "大洋洲",
"py": "kanpeila"
},
{
"city": "悉尼",
"district": "澳大利亚",
"prov": "大洋洲",
"py": "xini"
},
{
"city": "墨尔本",
"district": "澳大利亚",
"prov": "大洋洲",
"py": "moerben"
},
{
"city": "珀斯",
"district": "澳大利亚",
"prov": "大洋洲",
"py": "posi"
},
{
"city": "布里斯班",
"district": "澳大利亚",
"prov": "大洋洲",
"py": "bulisiban"
},
{
"city": "黄金海岸",
"district": "澳大利亚",
"prov": "大洋洲",
"py": "huangjinhaian"
},
{
"city": "阿德莱德",
"district": "澳大利亚",
"prov": "大洋洲",
"py": "adelaide"
},
{
"city": "惠灵顿",
"district": "其他",
"prov": "大洋洲",
"py": "huilingdun"
},
{
"city": "奥克兰",
"district": "其他",
"prov": "大洋洲",
"py": "aokelan"
},
{
"city": "斐济",
"district": "其他",
"prov": "大洋洲",
"py": "feiji"
},
{
"city": "塞班",
"district": "其他",
"prov": "大洋洲",
"py": "saiban"
},
{
"city": "两江新区",
"district": "重庆市",
"prov": "重庆市",
"py": "liangjiangxinqu"
}
];
export function findGeo(name){ return GEO.filter(g=>(g.city||'').includes(name)||(g.district||'').includes(name)); }
