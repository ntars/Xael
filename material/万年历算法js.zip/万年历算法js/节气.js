// 廿四节气 —— 算法模块（自包含，不依赖任何外部库）
// 算法：公开「寿星公式」（21 世纪 C 值表，适用 2000–2099，精确到日）
// 原理（大白话）：每年每个节气落在该月某日，由「年份尾数 × 系数 + 常数 − 闰年修正」算出。
// 准确性（如实标注，不美化）：适用范围 2000–2099，绝大多数年份精确到日；
//   个别闰年边界年份（如 2020 立春）按此公式会偏 1 天，属"寿星公式"公开算法的已知 ±1 日局限。
//   要分钟级/逐日绝对精确，需改用天文黄经算法（不在本模块）。立春/年干支切换边界以 干支.js 锚定口径为准。

// 节气名（按月份顺序：1月小寒/大寒 … 12月大雪/冬至）
const TERMS = ['小寒','大寒','立春','雨水','惊蛰','春分','清明','谷雨',
  '立夏','小满','芒种','夏至','小暑','大暑','立秋','处暑','白露','秋分','寒露','霜降','立冬','小雪','大雪','冬至'];
// 每个节气对应的「月份」(1–12) 与 21 世纪常数 C（日，decimal 表示可能在月末偏移）
const C_TABLE = {
  小寒:[1,5.4055], 大寒:[1,20.12], 立春:[2,3.87], 雨水:[2,18.73], 惊蛰:[3,5.63], 春分:[3,20.646],
  清明:[4,4.81], 谷雨:[4,20.1], 立夏:[5,5.52], 小满:[5,21.04], 芒种:[6,5.678], 夏至:[6,21.37],
  小暑:[7,7.108], 大暑:[7,22.83], 立秋:[8,7.5], 处暑:[8,23.13], 白露:[9,7.646], 秋分:[9,23.042],
  寒露:[10,8.318], 霜降:[10,23.438], 立冬:[11,7.438], 小雪:[11,22.36], 大雪:[12,7.18], 冬至:[12,21.94]
};

// 算某年某月某节气是几号（寿星公式，Y=年份后两位）
function termDay(year, termName) {
  const [month, C] = C_TABLE[termName];
  const Y = year % 100;
  const D = Math.floor(Y * 0.2422 + C) - Math.floor(Y / 4);
  return { year, month, day: D, term: termName };
}

// 取某年全部 24 个节气（返回 [{term, year, month, day}]）
export function yearTerms(year) {
  return TERMS.map(t => termDay(year, t)).sort((a, b) =>
    a.month - b.month || a.day - b.day);
}

// 取某公历年月日所在的节气信息（是否交节日 + 当前/邻近节气）
export function jieqiOf(y, m, d) {
  const all = yearTerms(y);
  const today = all.find(t => t.month === m && t.day === d);
  // 前一个 / 后一个节气
  let prev = null, next = null;
  for (let i = 0; i < all.length; i++) {
    const t = all[i];
    const tOrd = t.month * 100 + t.day;
    const cur = m * 100 + d;
    if (tOrd < cur) prev = t;
    if (tOrd > cur && !next) next = t;
  }
  return { 是否交节日: !!today, 当日节气: today ? today.term : null, 前一节气: prev, 后一节气: next, 全年节气表: all };
}

export const JIEQI = { TERMS, C_TABLE };
